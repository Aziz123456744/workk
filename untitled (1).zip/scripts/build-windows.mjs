import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const extraArgs = process.argv.slice(2);
const pkg = JSON.parse(fs.readFileSync(path.resolve('package.json'), 'utf-8'));
const electronVersion = String(pkg.devDependencies?.electron || '45.3.2').replace(/^[^\d]*/, '');
const expectedZipName = `electron-v${electronVersion}-win32-x64.zip`;

function resolveLocalElectronDist() {
  if (process.platform === 'win32') {
    const unpackedExe = path.resolve('node_modules', 'electron', 'dist', 'electron.exe');
    if (fs.existsSync(unpackedExe)) {
      return path.resolve('node_modules', 'electron', 'dist');
    }
  }

  const candidateDirs = [
    path.join(os.homedir(), 'Downloads'),
    path.join(os.homedir(), 'AppData', 'Local', 'electron', 'Cache'),
    path.join(os.homedir(), 'AppData', 'Local', 'electron-builder', 'Cache'),
  ];

  for (const dir of candidateDirs) {
    const candidateZip = path.join(dir, expectedZipName);
    if (fs.existsSync(candidateZip)) {
      return candidateZip;
    }
  }

  return null;
}

function runBuilder(args, envOverrides = {}) {
  const cliPath = path.resolve('node_modules', 'electron-builder', 'cli.js');
  return spawnSync(process.execPath, [cliPath, '--win', ...args], {
    stdio: 'inherit',
    shell: false,
    env: { ...process.env, ...envOverrides },
  });
}

const builderArgs = [...extraArgs];
const localDist = resolveLocalElectronDist();
if (localDist && !builderArgs.some((a) => a.includes('electronDist'))) {
  console.log(`[build-windows] Using local Electron distribution: ${localDist}`);
  builderArgs.push(`-c.electronDist=${localDist}`);
}

let result = runBuilder(builderArgs);

if (result.status !== 0 && !process.env.ELECTRON_MIRROR && !localDist) {
  console.log('\n[build-windows] Retrying electron-builder with ELECTRON_MIRROR fallback...\n');
  result = runBuilder(builderArgs, {
    ELECTRON_MIRROR: 'https://cdn.npmmirror.com/binaries/electron/',
  });
}

process.exit(result.status ?? 1);
