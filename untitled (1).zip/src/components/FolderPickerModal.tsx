import { useEffect, useState } from 'react';
import { ArrowUp, Check, Cpu, Folder, FolderOpen, X } from 'lucide-react';
import {
  browseDirectoryApi,
  isTauriDesktopRuntime,
  pickNativeFolderApi,
  type DirectoryListing,
} from '../utils/api';

interface FolderPickerModalProps {
  isOpen: boolean;
  title: string;
  initialPath: string;
  mcPath?: string;
  onSelect: (selectedPath: string) => void;
  onClose: () => void;
}

export function FolderPickerModal({
  isOpen,
  title,
  initialPath,
  mcPath,
  onSelect,
  onClose,
}: FolderPickerModalProps) {
  const [listing, setListing] = useState<DirectoryListing | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isTauri = isTauriDesktopRuntime();

  const loadPath = async (targetPath?: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await browseDirectoryApi(targetPath, mcPath);
      setListing(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to open directory');
      // Fallback to default launcher data directory if the user typed a nonexistent path
      if (targetPath) {
        try {
          const fallback = await browseDirectoryApi(undefined, mcPath);
          setListing(fallback);
        } catch {
          // keep error visible
        }
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      void loadPath(initialPath);
    }
  }, [isOpen, initialPath]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleNativeBrowse = async () => {
    try {
      const chosen = await pickNativeFolderApi();
      if (chosen) {
        onSelect(chosen);
        onClose();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to open system folder dialog');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="folder-picker-title"
    >
      <div className="w-full max-w-2xl rounded-lg border border-[#2d3239] bg-[#191c20] shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-[#2d3239] px-5 py-4">
          <div>
            <h2 id="folder-picker-title" className="text-base font-semibold text-stone-100">
              {title}
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Select a directory on disk for your launcher runtime configuration.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close folder picker"
            className="rounded-md p-2 text-stone-400 hover:bg-[#22262b] hover:text-stone-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {listing?.presets && listing.presets.length > 0 && (
            <div>
              <div className="text-xs font-medium text-stone-400 mb-2">
                Detected Environments
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {listing.presets.map((preset) => (
                  <button
                    key={preset.path}
                    type="button"
                    onClick={() => void loadPath(preset.path)}
                    className={`flex flex-col items-start rounded-md border px-3 py-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1cb5f6] ${
                      listing.currentPath === preset.path
                        ? 'border-[#1cb5f6] bg-[#142029] text-stone-100'
                        : 'border-[#2d3239] bg-[#121316] text-stone-300 hover:border-stone-600 hover:bg-[#1e2227]'
                    }`}
                  >
                    <span className="text-xs font-medium text-stone-100 truncate w-full">
                      {preset.label}
                    </span>
                    <span className="text-[11px] text-stone-400 mt-0.5 line-clamp-1">
                      {preset.description}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 rounded-md border border-[#2d3239] bg-[#111315] px-3 py-2">
            <button
              type="button"
              disabled={!listing?.parentPath || loading}
              onClick={() => listing?.parentPath && void loadPath(listing.parentPath)}
              aria-label="Go to parent directory"
              className="rounded p-1.5 text-stone-300 hover:bg-[#22262b] disabled:opacity-40 disabled:pointer-events-none transition-colors"
            >
              <ArrowUp className="h-4 w-4" />
            </button>
            <FolderOpen className="h-4 w-4 text-stone-400 shrink-0" />
            <span className="font-mono text-xs text-stone-200 truncate">
              {listing?.currentPath ?? initialPath}
            </span>
          </div>

          {error && (
            <div className="rounded-md border border-amber-700/50 bg-amber-950/30 px-3 py-2 text-xs text-amber-200">
              {error}
            </div>
          )}

          <div className="h-56 overflow-y-auto rounded-md border border-[#2d3239] bg-[#111315] divide-y divide-[#22262b]">
            {loading ? (
              <div className="p-4 text-xs text-stone-400">Loading directory entries...</div>
            ) : listing && listing.entries.filter((e) => e.isDirectory).length > 0 ? (
              listing.entries
                .filter((e) => e.isDirectory)
                .map((entry) => (
                  <button
                    key={entry.path}
                    type="button"
                    onClick={() => void loadPath(entry.path)}
                    className="flex w-full items-center justify-between px-3.5 py-2.5 text-left text-sm text-stone-200 hover:bg-[#1c2025] transition-colors focus-visible:outline-none focus-visible:bg-[#1c2025]"
                  >
                    <span className="flex items-center gap-2.5 min-w-0">
                      <Folder className="h-4 w-4 text-stone-400 shrink-0" />
                      <span className="truncate font-mono text-xs">{entry.name}</span>
                    </span>
                    {entry.hint && (
                      <span className="flex items-center gap-1.5 text-[11px] text-emerald-400 shrink-0 ml-3">
                        <Cpu className="h-3.5 w-3.5" />
                        <span>{entry.hint}</span>
                      </span>
                    )}
                  </button>
                ))
            ) : (
              <div className="p-4 text-xs text-stone-500">
                No subdirectories inside this folder.
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#2d3239] bg-[#15181c] px-5 py-3.5">
          <span className="text-xs text-stone-400 truncate font-mono max-w-[260px]">
            {listing?.currentPath ?? initialPath}
          </span>
          <div className="flex items-center gap-2 shrink-0">
            {isTauri && (
              <button
                type="button"
                onClick={() => void handleNativeBrowse()}
                className="inline-flex items-center gap-1.5 rounded-md border border-[#1cb5f6]/60 bg-[#142029] px-3 py-2 text-xs font-medium text-[#7dd9fc] hover:bg-[#1a2b38] transition-colors whitespace-nowrap shrink-0"
              >
                <FolderOpen className="h-3.5 w-3.5" />
                <span>OS Folder Dialog</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-[#2d3239] bg-[#191c20] px-4 py-2 text-xs font-medium text-stone-300 hover:bg-[#22262b] hover:text-stone-100 transition-colors whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!listing}
              onClick={() => {
                if (listing) {
                  onSelect(listing.currentPath);
                  onClose();
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-semibold text-white hover:bg-[#38c6ff] disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
            >
              <Check className="h-3.5 w-3.5" />
              <span>Select Folder</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
