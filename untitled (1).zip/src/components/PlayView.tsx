import { useState, type FormEvent } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  ChevronDown,
  Download,
  Eye,
  Loader2,
  Play,
  Plus,
  RotateCcw,
  Settings,
  Trash2,
  X,
} from 'lucide-react';
import {
  ARGENTUM_MOD_JARS,
  DEFAULT_SERVER_TILES,
  LAUNCHER_NEWS,
  LOCKED_VERSION_ID,
  getDownloadPhaseBreakdown,
  validateServerTile,
  type LaunchResponse,
  type LauncherSettings,
  type NewsArticle,
  type OrnitheConfig,
  type PreflightStatus,
  type ServerQuickTile,
  type VersionDownloadStatus,
} from '../utils/launcherLogic';

interface PlayViewProps {
  settings: LauncherSettings;
  ornithe: OrnitheConfig;
  servers: ServerQuickTile[];
  preflight: PreflightStatus | null;
  downloadStatus: VersionDownloadStatus | null;
  equippedCloakName: string;
  launching: boolean;
  launchPhase: string | null;
  launchResult: LaunchResponse | null;
  launchError: string | null;
  isDesktop: boolean;
  onChangeSetting: <K extends keyof LauncherSettings>(
    key: K,
    value: LauncherSettings[K]
  ) => void;
  onToggleOrnithe: (enabled: boolean) => void;
  onResetVersionCache: () => void;
  onDownloadMissing: () => void;
  onToggleServerTile: (serverId: string) => void;
  onAddServerTile: (tile: ServerQuickTile) => void;
  onDeleteServerTile: (serverId: string) => void;
  onLaunch: (serverAddress?: string) => void;
  onOpenSettings: (tab?: 'game' | 'launcher' | 'debug') => void;
  onOpenNewsArticle: (article: NewsArticle) => void;
  onOpenCosmetics: () => void;
}

const HERO_ART = 'assets/images/hero_voxel_landscape_1794735515436.jpg';
const DEFAULT_SERVER_IDS = new Set(DEFAULT_SERVER_TILES.map((s) => s.id));
const ACCENT_PALETTE = ['#1cb5f6', '#eab308', '#10b981', '#ec4899', '#f97316'];

export function PlayView({
  settings,
  ornithe,
  servers,
  preflight,
  downloadStatus,
  equippedCloakName,
  launching,
  launchPhase,
  launchResult,
  launchError,
  isDesktop,
  onChangeSetting,
  onToggleOrnithe,
  onResetVersionCache,
  onDownloadMissing,
  onToggleServerTile,
  onAddServerTile,
  onDeleteServerTile,
  onLaunch,
  onOpenSettings,
  onOpenNewsArticle,
  onOpenCosmetics,
}: PlayViewProps) {
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [versionMenuOpen, setVersionMenuOpen] = useState(false);
  const [editServersOpen, setEditServersOpen] = useState(false);

  const [newServerName, setNewServerName] = useState('');
  const [newServerAddress, setNewServerAddress] = useState('');
  const [newServerCode, setNewServerCode] = useState('');
  const [serverFormError, setServerFormError] = useState<string | null>(null);

  const enabledServers = servers.filter((s) => s.enabled);
  const isDownloading = downloadStatus?.state === 'downloading';

  const handleAddServer = (e: FormEvent) => {
    e.preventDefault();
    const result = validateServerTile({
      name: newServerName,
      address: newServerAddress,
      shortCode: newServerCode,
    });
    if (!result.valid || !result.normalized) {
      setServerFormError(result.error ?? 'Invalid server entry.');
      return;
    }
    const accent = ACCENT_PALETTE[servers.length % ACCENT_PALETTE.length];
    onAddServerTile({
      id: `custom-${Date.now()}`,
      name: result.normalized.name,
      address: result.normalized.address,
      shortCode: result.normalized.shortCode,
      accentColor: accent,
      enabled: true,
    });
    setNewServerName('');
    setNewServerAddress('');
    setNewServerCode('');
    setServerFormError(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Hero Banner */}
      <section className="relative overflow-hidden rounded-xl border border-[#26282e] bg-[#181a1f]">
        <div className="relative h-56 sm:h-64 w-full">
          {!heroImgFailed ? (
            <img
              src={HERO_ART}
              alt="Minecraft 1.8.9 Voxel Horizon"
              loading="eager"
              decoding="async"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="h-full w-full object-cover object-center transform-gpu"
            />
          ) : (
            <div className="h-full w-full bg-gradient-to-br from-[#16222c] via-[#15181e] to-[#121316]" />
          )}
          <div className="absolute inset-0 bg-gradient-to-r from-[#121316]/95 via-[#121316]/65 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#121316]/80 via-transparent to-black/20" />

          {/* Small preview play badge in top-left matching reference */}
          <button
            type="button"
            onClick={() => onOpenCosmetics()}
            aria-label="Preview cloak cosmetics"
            className="absolute left-3.5 top-3.5 flex h-7 w-7 items-center justify-center rounded bg-black/55 text-white hover:bg-black/80 transition-colors"
          >
            <Play className="h-3.5 w-3.5 fill-current" />
          </button>

          <div className="absolute inset-y-0 left-0 flex flex-col justify-end sm:justify-center px-5 pb-5 pt-12 sm:p-6 sm:px-10 max-w-xl">
            <h1 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white">
              Exclusive Free Cloak
            </h1>
            <p className="mt-2 text-sm text-stone-200 leading-relaxed max-w-md">
              Launch Minecraft 1.8.9 with Ornithe Loader for an exclusive cloak and tuned Agretium performance.
            </p>
            <div className="mt-4">
              <button
                type="button"
                onClick={onOpenCosmetics}
                className="inline-flex items-center rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap"
              >
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Centered Version + PLAY Action Hub */}
      <section className="flex flex-col items-center gap-3 pt-1">
        <div className="relative flex items-center gap-2">
          <button
            type="button"
            onClick={() => setVersionMenuOpen((v) => !v)}
            aria-expanded={versionMenuOpen}
            aria-label="Minecraft version 1.8.9 options"
            className="flex h-11 w-64 items-center justify-between rounded-lg border border-[#2f3239] bg-[#181a1f] px-4 text-sm hover:border-[#3e424c] transition-colors"
          >
            <span className="text-xs font-semibold tracking-wide text-stone-400">
              VERSION
            </span>
            <span className="flex items-center gap-2 font-mono text-sm font-semibold text-stone-100 whitespace-nowrap">
              <span>
                {LOCKED_VERSION_ID}
                {ornithe.enabled ? ' · Ornithe' : ''}
              </span>
              <ChevronDown className="h-4 w-4 text-stone-400" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => onOpenSettings('game')}
            aria-label="Open Game Settings"
            className="flex h-11 w-11 items-center justify-center rounded-lg border border-[#2f3239] bg-[#22252b] text-stone-200 hover:bg-[#2a2e36] hover:text-white transition-colors shrink-0"
          >
            <Settings className="h-4 w-4" />
          </button>

          {versionMenuOpen && (
            <div className="absolute left-0 top-12 z-20 w-80 rounded-lg border border-[#2f3239] bg-[#181a1f] p-3.5 shadow-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-stone-100">
                    Minecraft {LOCKED_VERSION_ID}
                  </div>
                  <div className="text-[11px] text-stone-400">
                    {ornithe.enabled
                      ? `Ornithe Loader ${ornithe.loaderVersion} + Calamus`
                      : 'Vanilla 1.8.9 Release'}
                  </div>
                </div>
                <span className="text-[11px] font-medium text-[#1cb5f6]">Active</span>
              </div>

              <div className="space-y-2 border-t border-[#26282e] pt-2.5">
                <label className="flex items-center justify-between text-xs text-stone-200 cursor-pointer">
                  <span>Ornithe 1.8.9 Loader</span>
                  <input
                    type="checkbox"
                    checked={ornithe.enabled}
                    onChange={(e) => onToggleOrnithe(e.target.checked)}
                    className="h-4 w-4 rounded accent-[#1cb5f6]"
                  />
                </label>

                <label className="flex items-center justify-between text-xs text-stone-200 cursor-pointer">
                  <span>Agretium (1.8.9)</span>
                  <input
                    type="checkbox"
                    checked={settings.optifine}
                    onChange={(e) => onChangeSetting('optifine', e.target.checked)}
                    className="h-4 w-4 rounded accent-[#1cb5f6]"
                  />
                </label>
              </div>

              {/* 1.8.9 & Ornithe Runtime Preflight */}
              <div className="border-t border-[#26282e] pt-2.5 space-y-1.5 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">Java Runtime</span>
                  <span
                    className={
                      preflight?.javaOk ? 'text-emerald-400 font-medium' : 'text-red-400 font-medium'
                    }
                  >
                    {preflight ? (preflight.javaOk ? 'Ready' : 'Missing') : 'Checking...'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">1.8.9 Client & Assets</span>
                  <span
                    className={
                      preflight?.jarOk && preflight?.assetsOk
                        ? 'text-emerald-400 font-medium'
                        : 'text-amber-400 font-medium'
                    }
                  >
                    {preflight
                      ? preflight.jarOk && preflight.assetsOk
                        ? 'Ready'
                        : 'Download Needed'
                      : 'Checking...'}
                  </span>
                </div>
                {ornithe.enabled && (
                  <div className="flex items-center justify-between">
                    <span className="text-stone-400">Ornithe {ornithe.loaderVersion}</span>
                    <span
                      className={
                        preflight?.ornitheOk
                          ? 'text-emerald-400 font-medium'
                          : 'text-amber-400 font-medium'
                      }
                    >
                      {preflight
                        ? preflight.ornitheOk
                          ? 'Ready'
                          : 'Download Needed'
                        : 'Checking...'}
                    </span>
                  </div>
                )}
                {settings.optifine && (
                  <div className="flex items-center justify-between">
                    <span className="text-stone-400">Agretium / Argentum 1.0.2</span>
                    <span
                      className={
                        preflight?.argentumOk
                          ? 'text-emerald-400 font-medium'
                          : 'text-amber-400 font-medium'
                      }
                    >
                      {preflight
                        ? preflight.argentumOk
                          ? `Ready (${ARGENTUM_MOD_JARS.length} JARs)`
                          : 'Download Needed'
                        : 'Checking...'}
                    </span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-stone-400">Cloak</span>
                  <span className="text-stone-200 truncate max-w-[160px]">
                    {equippedCloakName}
                  </span>
                </div>
              </div>

              <div className="border-t border-[#26282e] pt-2.5 flex items-center justify-between gap-2">
                <button
                  type="button"
                  disabled={launching || isDownloading}
                  onClick={() => {
                    onResetVersionCache();
                    setVersionMenuOpen(false);
                  }}
                  className="inline-flex items-center gap-1.5 rounded border border-[#2c2f36] bg-[#121316] px-2.5 py-1.5 text-[11px] font-medium text-stone-300 hover:border-[#1cb5f6] hover:text-white disabled:opacity-50 transition-colors"
                >
                  <RotateCcw className="h-3 w-3" />
                  <span>Reset 1.8.9 Files (New Player)</span>
                </button>

                <span className="text-[11px] text-stone-400 font-mono tabular-nums">
                  {settings.ram_mb} MB
                </span>
              </div>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={() => onLaunch()}
          disabled={launching || isDownloading}
          aria-busy={launching || isDownloading}
          data-launching={launching ? 'true' : 'false'}
          className={`relative overflow-hidden h-14 w-[308px] rounded-lg font-display font-bold tracking-wider text-white shadow-lg transition-all flex items-center justify-center gap-2.5 px-4 ${
            launching || isDownloading
              ? 'bg-[#1289bc] shadow-[#1cb5f6]/25 cursor-wait'
              : 'bg-[#1cb5f6] hover:bg-[#38c6ff] active:bg-[#0fa4e3] shadow-[#1cb5f6]/15 text-xl'
          }`}
        >
          {launching && !isDownloading && (
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-transparent via-white/25 to-transparent animate-launch-shimmer"
            />
          )}

          {(launching || isDownloading) && (
            <Loader2 className="relative z-10 h-4 w-4 animate-spin shrink-0 text-white" />
          )}

          <span
            className={`relative z-10 truncate ${
              launching || isDownloading ? 'text-sm tracking-wide font-semibold' : 'text-xl'
            }`}
          >
            {isDownloading
              ? `DOWNLOADING ${downloadStatus.percent}%`
              : launching
              ? launchPhase ?? 'STARTING 1.8.9...'
              : 'PLAY'}
          </span>

          {(launching || isDownloading) && (
            <span
              aria-hidden="true"
              className="pointer-events-none absolute bottom-0 inset-x-0 h-1 bg-black/25 overflow-hidden"
            >
              {isDownloading ? (
                <span
                  className="block h-full bg-white/95 transition-all duration-200"
                  style={{ width: `${Math.max(8, downloadStatus.percent)}%` }}
                />
              ) : (
                <span className="block h-full w-2/5 rounded-full bg-white/95 animate-launch-bar" />
              )}
            </span>
          )}
        </button>

        {preflight?.needsDownload && !isDownloading && !launching && (
          <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-stone-300">
            <div className="inline-flex items-center gap-1.5 text-stone-400">
              <Download className="h-3.5 w-3.5 text-[#1cb5f6]" />
              <span>
                Missing {preflight.missingArtifacts.length} required{' '}
                {ornithe.enabled ? '1.8.9, Ornithe & Argentum' : '1.8.9'} files
              </span>
            </div>
            <button
              type="button"
              onClick={onDownloadMissing}
              className="rounded border border-[#1cb5f6]/50 bg-[#142029] px-2.5 py-1 text-[11px] font-semibold text-[#7dd9fc] hover:bg-[#1a2b38] transition-colors"
            >
              Download Now
            </button>
          </div>
        )}

        {/* Server Quick-Join Tiles Row */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
          {enabledServers.map((srv) => (
            <button
              key={srv.id}
              type="button"
              disabled={launching || isDownloading}
              onClick={() => onLaunch(srv.address)}
              title={`Launch 1.8.9 & connect to ${srv.name} (${srv.address})`}
              aria-label={`Launch 1.8.9 into ${srv.name}`}
              className="group flex h-13 w-13 flex-col items-center justify-center rounded-lg border border-[#2c2f36] bg-[#181a1f] hover:border-[#1cb5f6] hover:bg-[#1e2228] disabled:opacity-50 transition-colors"
            >
              <span
                style={{ color: srv.accentColor }}
                className="font-display text-sm font-bold tracking-tight group-hover:scale-105 transition-transform"
              >
                {srv.shortCode}
              </span>
              <span className="text-[9px] text-stone-500 truncate max-w-[46px]">
                {srv.name.split(' ')[0]}
              </span>
            </button>
          ))}

          <button
            type="button"
            onClick={() => setEditServersOpen(true)}
            aria-label="Edit favorite servers"
            className="flex h-13 w-13 flex-col items-center justify-center gap-0.5 rounded-lg border border-[#2c2f36] bg-[#181a1f] text-stone-300 hover:border-[#1cb5f6] hover:text-white transition-colors"
          >
            <Settings className="h-4 w-4" />
            <span className="text-[10px] font-medium">Edit</span>
          </button>
        </div>
      </section>

      {/* Ornithe 1.8.9 & Argentum Download Manager Smooth Animated Progress Visualizer */}
      <AnimatePresence>
        {downloadStatus &&
          (downloadStatus.state === 'downloading' ||
            (downloadStatus.state === 'complete' && downloadStatus.totalCount > 0)) && (
            <motion.section
              key="version-download-panel"
              data-testid="version-download-panel"
              aria-live="polite"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              className="mx-auto max-w-3xl rounded-lg border border-[#1cb5f6]/50 bg-[#142029] p-4 space-y-3.5"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  {downloadStatus.state === 'downloading' ? (
                    <Loader2 className="h-4 w-4 animate-spin text-[#1cb5f6] shrink-0" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  )}
                  <div className="min-w-0">
                    <h2 className="text-sm font-semibold text-white truncate">
                      {downloadStatus.state === 'downloading'
                        ? `Downloading Minecraft 1.8.9 ${
                            ornithe.enabled ? `& Ornithe ${ornithe.loaderVersion}` : ''
                          }`
                        : `Verified Minecraft 1.8.9 ${
                            ornithe.enabled ? `& Ornithe ${ornithe.loaderVersion}` : ''
                          } Files`}
                    </h2>
                    <p className="text-xs text-stone-300 truncate">
                      {downloadStatus.state === 'downloading'
                        ? downloadStatus.currentArtifact
                          ? `Fetching ${downloadStatus.currentArtifact}...`
                          : 'Finalizing JARs...'
                        : `All ${downloadStatus.totalCount} required files installed in game directory.`}
                    </p>
                  </div>
                </div>
                <div className="text-right font-mono text-xs text-[#7dd9fc] tabular-nums shrink-0">
                  {downloadStatus.percent}% ({downloadStatus.completedCount}/{downloadStatus.totalCount})
                </div>
              </div>

              {/* 3-Stage Phase Stepper: Fetching JARs -> Ornithe Loader -> Argentum & ForgeCompat */}
              <div
                data-testid="download-phase-stepper"
                className="grid grid-cols-1 sm:grid-cols-3 gap-2"
              >
                {getDownloadPhaseBreakdown(downloadStatus).map((phase, index) => {
                  const isActive = phase.state === 'active';
                  const isDone = phase.state === 'done';
                  const isSkipped = phase.state === 'skipped';
                  return (
                    <div
                      key={phase.id}
                      data-testid={`download-phase-${phase.id}`}
                      data-phase-state={phase.state}
                      className={`rounded-md border px-2.5 py-2 transition-colors ${
                        isActive
                          ? 'border-[#1cb5f6]/70 bg-[#172a38]'
                          : isDone
                          ? 'border-emerald-500/40 bg-emerald-950/25'
                          : 'border-[#26282e] bg-[#121316]/75'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px]">
                        <span
                          className={`font-semibold truncate ${
                            isActive
                              ? 'text-white'
                              : isDone
                              ? 'text-emerald-300'
                              : 'text-stone-400'
                          }`}
                        >
                          {index + 1}. {phase.label}
                        </span>
                        <span
                          className={`font-mono tabular-nums shrink-0 ${
                            isActive
                              ? 'text-[#7dd9fc]'
                              : isDone
                              ? 'text-emerald-400'
                              : 'text-stone-500'
                          }`}
                        >
                          {isSkipped
                            ? 'Ready'
                            : isDone
                            ? 'Done'
                            : `${phase.completed}/${phase.total}`}
                        </span>
                      </div>
                      <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-[#121316]">
                        <motion.div
                          initial={false}
                          animate={{
                            width: `${isSkipped || isDone ? 100 : isActive ? Math.max(25, phase.percent) : 0}%`,
                          }}
                          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                          className={`h-full rounded-full ${
                            isDone
                              ? 'bg-emerald-400'
                              : isActive
                              ? 'bg-[#1cb5f6]'
                              : 'bg-stone-600'
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Smooth Animated Overall Progress Bar with Specular Shimmer */}
              <div
                role="progressbar"
                aria-label="Ornithe 1.8.9 loader download progress"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={downloadStatus.percent}
                className="relative h-2.5 w-full overflow-hidden rounded-full bg-[#121316] border border-[#26282e]"
              >
                <motion.div
                  initial={{ width: '0%' }}
                  animate={{ width: `${downloadStatus.percent}%` }}
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  className={`relative h-full overflow-hidden rounded-full ${
                    downloadStatus.state === 'complete' ? 'bg-emerald-400' : 'bg-[#1cb5f6]'
                  }`}
                >
                  {downloadStatus.state === 'downloading' && (
                    <motion.div
                      aria-hidden="true"
                      animate={{ x: ['-100%', '220%'] }}
                      transition={{ repeat: Infinity, duration: 1.35, ease: 'linear' }}
                      className="absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/35 to-transparent"
                    />
                  )}
                </motion.div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px]">
                {downloadStatus.artifacts.map((art) => (
                  <div
                    key={art.id}
                    className="flex items-center justify-between gap-2 rounded bg-[#121316]/70 px-2.5 py-1.5"
                  >
                    <span className="text-stone-200 truncate">{art.label}</span>
                    <span
                      className={
                        art.status === 'done'
                          ? 'text-emerald-400 font-mono shrink-0'
                          : art.status === 'downloading'
                          ? 'text-[#1cb5f6] font-mono shrink-0'
                          : 'text-stone-500 font-mono shrink-0'
                      }
                    >
                      {art.status === 'done'
                        ? 'Done'
                        : art.status === 'downloading'
                        ? art.sizeLabel
                        : 'Queued'}
                    </span>
                  </div>
                ))}
              </div>
            </motion.section>
          )}
      </AnimatePresence>

      {/* Launch Success / Running Banner */}
      {launchResult && !launching && !launchError && (
        <section
          role="status"
          data-testid="launch-status-banner"
          className="mx-auto max-w-3xl rounded-lg border border-[#1cb5f6]/45 bg-[#142029] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
        >
          <div className="flex items-start gap-3 min-w-0">
            <CheckCircle2 className="h-5 w-5 text-[#1cb5f6] shrink-0 mt-0.5" />
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-white">
                {isDesktop ? 'Minecraft 1.8.9 Process Started' : 'Web Preview Launch Verified'}
              </h2>
              <p className="text-xs text-stone-200 mt-0.5 break-words">{launchResult.message}</p>
              {!isDesktop && (
                <p className="text-[11px] text-stone-400 mt-1">
                  Browser previews simulate JVM handoff. To open the real Minecraft 1.8.9 window on Windows, run the downloaded <strong className="text-stone-200">Agretium 1.8.9 Launcher.exe</strong> below.
                </p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={() => onOpenSettings('debug')}
            className="rounded-md border border-[#1cb5f6]/60 bg-[#181a1f] px-3.5 py-2 text-xs font-medium text-[#7dd9fc] hover:bg-[#1e262f] transition-colors whitespace-nowrap shrink-0"
          >
            View Logs
          </button>
        </section>
      )}

      {/* Path Error Banner */}
      {launchError && (
        <section
          role="alert"
          className="mx-auto max-w-3xl rounded-lg border border-red-800/70 bg-red-950/30 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-sm font-semibold text-red-200">Launch Failed</h2>
              <p className="text-xs font-mono text-red-300 mt-0.5 break-all">{launchError}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onOpenSettings('game')}
            className="rounded-md border border-red-700/60 bg-red-950/50 px-3.5 py-2 text-xs font-medium text-red-100 hover:bg-red-900/50 transition-colors whitespace-nowrap shrink-0"
          >
            Fix Paths
          </button>
        </section>
      )}

      {/* Bottom 4-Column News & Updates Row */}
      <section aria-label="Launcher News and Updates" className="pt-2">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {LAUNCHER_NEWS.map((article) => (
            <button
              key={article.id}
              type="button"
              onClick={() => onOpenNewsArticle(article)}
              className="group text-left focus-visible:outline-none"
            >
              <div className="relative h-28 w-full overflow-hidden rounded-lg border border-[#26282e] bg-[#181a1f] group-hover:border-[#1cb5f6]/60 transition-colors">
                <img
                  src={article.image}
                  alt={article.title}
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover transform-gpu group-hover:scale-105 transition-transform duration-200"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/30 to-black/20" />
                <div className="absolute inset-x-2.5 top-2.5 flex items-center justify-between text-[11px] font-semibold">
                  {article.isNew ? (
                    <span className="rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                      New
                    </span>
                  ) : (
                    <span />
                  )}
                  <span className="inline-flex items-center gap-1 rounded bg-black/65 px-1.5 py-0.5 font-mono text-[10px] text-stone-200 tabular-nums">
                    <span>{article.views}</span>
                    <Eye className="h-3 w-3" />
                  </span>
                </div>
                <div className="absolute inset-x-3 bottom-2.5 font-display text-sm font-bold text-white truncate">
                  {article.title}
                </div>
              </div>
              <div className="mt-2">
                <div className="text-sm font-semibold text-stone-100 group-hover:text-[#1cb5f6] transition-colors truncate">
                  {article.title}
                </div>
                <div className="text-xs text-stone-400">{article.date}</div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Edit Quick-Join Servers Modal */}
      {editServersOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-servers-title"
        >
          <div className="w-full max-w-lg rounded-lg border border-[#2c2f36] bg-[#181a1f] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#26282e] px-5 py-4">
              <div>
                <h2 id="edit-servers-title" className="text-base font-semibold text-stone-100">
                  1.8.9 Server Shortcuts
                </h2>
                <p className="text-xs text-stone-400 mt-0.5">
                  Toggle or add custom 1.8.9 servers for quick-launch below Play.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditServersOpen(false)}
                aria-label="Close server shortcuts dialog"
                className="rounded p-1.5 text-stone-400 hover:bg-[#23262d] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto divide-y divide-[#24262c] px-4 py-2">
              {servers.map((srv) => {
                const isCustom = !DEFAULT_SERVER_IDS.has(srv.id);
                return (
                  <div
                    key={srv.id}
                    className="flex items-center justify-between py-2.5 gap-2"
                  >
                    <button
                      type="button"
                      onClick={() => onToggleServerTile(srv.id)}
                      className="flex flex-1 items-center justify-between px-2 py-1 text-left hover:bg-[#1e2128] rounded transition-colors min-w-0"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          style={{ color: srv.accentColor }}
                          className="font-display text-xs font-bold w-9 text-center shrink-0"
                        >
                          {srv.shortCode}
                        </span>
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-stone-100 truncate">
                            {srv.name}
                          </div>
                          <div className="text-xs font-mono text-stone-400 truncate">
                            {srv.address}
                          </div>
                        </div>
                      </div>
                      <div
                        className={`flex h-5 w-5 items-center justify-center rounded border shrink-0 ${
                          srv.enabled
                            ? 'border-[#1cb5f6] bg-[#1cb5f6] text-white'
                            : 'border-[#3a3e47] bg-[#121316]'
                        }`}
                      >
                        {srv.enabled && <Check className="h-3.5 w-3.5" />}
                      </div>
                    </button>

                    {isCustom && (
                      <button
                        type="button"
                        onClick={() => onDeleteServerTile(srv.id)}
                        aria-label={`Remove ${srv.name}`}
                        className="rounded p-1.5 text-stone-500 hover:bg-red-950/50 hover:text-red-300 transition-colors shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            <form
              onSubmit={handleAddServer}
              className="border-t border-[#26282e] bg-[#15171c] p-4 space-y-3"
            >
              <div className="text-xs font-semibold text-stone-200">
                Add Custom 1.8.9 Server
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                <input
                  type="text"
                  value={newServerName}
                  onChange={(e) => setNewServerName(e.target.value)}
                  aria-label="Custom server name"
                  placeholder="Name (e.g. Lunar)"
                  className="sm:col-span-4 rounded-md border border-[#2c2f36] bg-[#121316] px-2.5 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:border-[#1cb5f6] focus:outline-none"
                />
                <input
                  type="text"
                  value={newServerAddress}
                  onChange={(e) => setNewServerAddress(e.target.value)}
                  aria-label="Custom server address"
                  placeholder="Address (e.g. lunar.gg)"
                  className="sm:col-span-5 rounded-md border border-[#2c2f36] bg-[#121316] px-2.5 py-2 text-xs font-mono text-stone-100 placeholder:text-stone-500 focus:border-[#1cb5f6] focus:outline-none"
                />
                <input
                  type="text"
                  maxLength={4}
                  value={newServerCode}
                  onChange={(e) => setNewServerCode(e.target.value)}
                  aria-label="Custom server badge code"
                  placeholder="Tag (LP)"
                  className="sm:col-span-3 rounded-md border border-[#2c2f36] bg-[#121316] px-2.5 py-2 text-xs font-display font-bold uppercase text-stone-100 placeholder:text-stone-500 focus:border-[#1cb5f6] focus:outline-none"
                />
              </div>

              {serverFormError && (
                <p role="alert" className="text-xs text-red-400">
                  {serverFormError}
                </p>
              )}

              <div className="flex items-center justify-between pt-1">
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 rounded-md border border-[#1cb5f6]/60 bg-[#142029] px-3.5 py-2 text-xs font-semibold text-[#7dd9fc] hover:bg-[#1a2b37] transition-colors"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add Server</span>
                </button>

                <button
                  type="button"
                  onClick={() => setEditServersOpen(false)}
                  className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-semibold text-white hover:bg-[#38c6ff]"
                >
                  Done
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

