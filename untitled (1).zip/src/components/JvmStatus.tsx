import { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  Pause,
  Play,
  RefreshCw,
  Square,
  Terminal,
  Trash2,
} from 'lucide-react';
import {
  evaluateMemoryEfficiency,
  formatRamGb,
  formatUptime,
  type JvmStatusSnapshot,
} from '../utils/launcherLogic';
import {
  fetchJvmStatus,
  stopJvmSessionApi,
  triggerJvmGcApi,
} from '../utils/api';

interface JvmStatusProps {
  configuredXmxMb: number;
  configuredNewGc: boolean;
  onQuickLaunch: () => void;
}

interface SamplePoint {
  usedMb: number;
  allocatedMb: number;
  xmxMb: number;
  timeLabel: string;
}

const MAX_SAMPLES = 20;
const POLL_INTERVAL_MS = 1500;

export function JvmStatus({
  configuredXmxMb,
  configuredNewGc,
  onQuickLaunch,
}: JvmStatusProps) {
  const [status, setStatus] = useState<JvmStatusSnapshot | null>(null);
  const [samples, setSamples] = useState<SamplePoint[]>([]);
  const [polling, setPolling] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionBusy, setActionBusy] = useState(false);
  const [logsCopied, setLogsCopied] = useState(false);

  const recordSample = useCallback((snap: JvmStatusSnapshot) => {
    setStatus(snap);
    setError(null);
    setSamples((prev) => {
      const point: SamplePoint = {
        usedMb: snap.used_mb,
        allocatedMb: snap.allocated_mb,
        xmxMb: snap.xmx_mb,
        timeLabel: new Date(snap.timestamp).toLocaleTimeString([], {
          minute: '2-digit',
          second: '2-digit',
        }),
      };
      return [...prev, point].slice(-MAX_SAMPLES);
    });
  }, []);

  const pollOnce = useCallback(async () => {
    try {
      const snap = await fetchJvmStatus();
      recordSample(snap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to poll JVM status');
    } finally {
      setLoading(false);
    }
  }, [recordSample]);

  useEffect(() => {
    void pollOnce();
  }, [pollOnce]);

  useEffect(() => {
    if (!polling) return;
    const timer = window.setInterval(() => {
      void pollOnce();
    }, POLL_INTERVAL_MS);
    return () => window.clearInterval(timer);
  }, [polling, pollOnce]);

  const handleTriggerGc = async () => {
    setActionBusy(true);
    try {
      const snap = await triggerJvmGcApi();
      recordSample(snap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'GC failed');
    } finally {
      setActionBusy(false);
    }
  };

  const handleStopSession = async () => {
    setActionBusy(true);
    try {
      const snap = await stopJvmSessionApi();
      recordSample(snap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to stop JVM');
    } finally {
      setActionBusy(false);
    }
  };

  const logs = status?.logs ?? [];

  const handleCopyLogs = async () => {
    if (logs.length === 0) return;
    const formatted = logs
      .map((entry) => `[${entry.time}] [${entry.thread}/${entry.level}]: ${entry.message}`)
      .join('\n');
    try {
      await navigator.clipboard.writeText(formatted);
      setLogsCopied(true);
      window.setTimeout(() => setLogsCopied(false), 1800);
    } catch {
      setLogsCopied(false);
    }
  };

  const effectiveXmx = status?.xmx_mb ?? configuredXmxMb;
  const usedMb = status?.used_mb ?? 0;
  const allocatedMb = status?.allocated_mb ?? 0;
  const running = status?.running ?? false;
  const efficiency = evaluateMemoryEfficiency(usedMb, allocatedMb, effectiveXmx, running);

  const tierStyles = {
    idle: 'text-stone-300',
    optimal: 'text-[#1cb5f6]',
    moderate: 'text-amber-400',
    high: 'text-orange-400',
    exceeded: 'text-red-400',
  }[efficiency.tier];

  const xmxMatchesConfigured = effectiveXmx === configuredXmxMb;

  // Build SVG polyline coordinates for Used & Allocated against effectiveXmx
  const chartWidth = 560;
  const chartHeight = 110;
  const maxAxisMb = Math.max(1024, effectiveXmx);

  const buildPolyline = (getter: (s: SamplePoint) => number) => {
    if (samples.length < 2) return '';
    return samples
      .map((s, idx) => {
        const x = (idx / (MAX_SAMPLES - 1)) * chartWidth;
        const clamped = Math.max(0, Math.min(maxAxisMb, getter(s)));
        const y = chartHeight - (clamped / maxAxisMb) * (chartHeight - 12) - 6;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const usedLine = buildPolyline((s) => s.usedMb);
  const allocatedLine = buildPolyline((s) => s.allocatedMb);

  return (
    <section
      aria-labelledby="jvm-status-heading"
      className="rounded-lg border border-[#26282e] bg-[#181a1f] p-5 space-y-5"
    >
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2.5">
            <Activity className="h-4 w-4 text-[#1cb5f6] shrink-0" />
            <h2 id="jvm-status-heading" className="text-sm font-bold text-stone-100">
              JVM Status
            </h2>
            <span className="text-xs text-stone-400">·</span>
            <span className="font-mono text-xs text-stone-300 tabular-nums">
              -Xmx{effectiveXmx}M
            </span>
            <span className="text-xs text-stone-400">·</span>
            <span className="inline-flex items-center gap-1 text-xs font-medium text-[#1cb5f6]">
              <CheckCircle2 className="h-3.5 w-3.5" />
              <span>{running ? `PID ${status?.pid}` : 'Standby'}</span>
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            Real-time heap polling ({POLL_INTERVAL_MS / 1000}s interval) ·{' '}
            {status?.gc_algorithm ?? (configuredNewGc ? 'G1GC (-XX:+UseG1GC)' : 'Parallel GC')}
            {running && status ? ` · Uptime ${formatUptime(status.uptime_seconds)}` : ''}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setPolling((p) => !p)}
            className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#121316] px-3 py-1.5 text-xs font-medium text-stone-200 hover:border-[#1cb5f6] transition-colors whitespace-nowrap"
          >
            {polling ? <Pause className="h-3.5 w-3.5" /> : <RefreshCw className="h-3.5 w-3.5" />}
            <span>{polling ? 'Pause Polling' : 'Resume Polling'}</span>
          </button>

          {running ? (
            <>
              <button
                type="button"
                disabled={actionBusy}
                onClick={() => void handleTriggerGc()}
                className="inline-flex items-center gap-1.5 rounded-md border border-[#1cb5f6]/60 bg-[#142029] px-3 py-1.5 text-xs font-medium text-[#7dd9fc] hover:bg-[#1a2b37] disabled:opacity-50 transition-colors whitespace-nowrap"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Run GC</span>
              </button>
              <button
                type="button"
                disabled={actionBusy}
                onClick={() => void handleStopSession()}
                className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#121316] px-3 py-1.5 text-xs font-medium text-stone-300 hover:text-white disabled:opacity-50 transition-colors whitespace-nowrap"
              >
                <Square className="h-3 w-3 fill-current" />
                <span>Stop</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={onQuickLaunch}
              className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-3.5 py-1.5 text-xs font-bold text-white hover:bg-[#38c6ff] transition-colors whitespace-nowrap"
            >
              <Play className="h-3 w-3 fill-current" />
              <span>Launch 1.8.9</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <div
          role="alert"
          className="flex items-center gap-2 rounded-md border border-red-800/70 bg-red-950/30 px-3.5 py-2 text-xs text-red-200"
        >
          <AlertTriangle className="h-4 w-4 text-red-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {!xmxMatchesConfigured && running && (
        <div className="flex items-center justify-between gap-3 border-t border-[#24262c] pt-3 text-xs text-amber-300">
          <span>
            Active JVM launched with <code className="font-mono">-Xmx{effectiveXmx}M</code>, while Game Settings now specifies{' '}
            <code className="font-mono">-Xmx{configuredXmxMb}M</code>. Relaunch 1.8.9 to apply the new ceiling.
          </span>
        </div>
      )}

      {/* Memory Bar: Used vs Allocated vs -Xmx Ceiling */}
      <div className="space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-4">
            <span className="inline-flex items-center gap-1.5 text-stone-200">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#1cb5f6]" aria-hidden="true" />
              <span>Used:</span>
              <strong className="font-mono tabular-nums">{usedMb} MB</strong>
            </span>
            <span className="inline-flex items-center gap-1.5 text-stone-300">
              <span className="h-2.5 w-2.5 rounded-xs bg-[#2c4e66]" aria-hidden="true" />
              <span>Allocated:</span>
              <strong className="font-mono tabular-nums">{allocatedMb} MB</strong>
            </span>
            <span className="text-stone-400">
              Max (-Xmx):{' '}
              <strong className="font-mono text-stone-200 tabular-nums">
                {effectiveXmx} MB
              </strong>
            </span>
          </div>

          <span className={`font-semibold ${tierStyles}`}>
            {efficiency.label} ({efficiency.usedPctOfXmx}%)
          </span>
        </div>

        <div
          role="progressbar"
          aria-label="JVM Heap Usage against -Xmx limit"
          aria-valuemin={0}
          aria-valuemax={effectiveXmx}
          aria-valuenow={usedMb}
          className="relative h-3.5 w-full overflow-hidden rounded-md border border-[#26282e] bg-[#121316]"
        >
          {/* Committed / Allocated bar */}
          <div
            style={{ width: `${efficiency.allocatedPctOfXmx}%` }}
            className="absolute inset-y-0 left-0 bg-[#2c4e66] transition-[width] duration-300"
          />
          {/* Live Used Heap bar */}
          <div
            style={{ width: `${efficiency.usedPctOfXmx}%` }}
            className="absolute inset-y-0 left-0 bg-[#1cb5f6] transition-[width] duration-300"
          />
        </div>

        <p className="text-xs text-stone-400">{efficiency.guidance}</p>
      </div>

      {/* 4 Flat Metric Cells separated by hairline grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#24262c] border-t border-b border-[#24262c] py-3">
        <div className="pr-3 py-1">
          <div className="text-[11px] text-stone-400">Used Heap</div>
          <div className="font-mono text-base font-bold text-stone-100 tabular-nums mt-0.5">
            {loading ? '—' : `${usedMb} MB`}
          </div>
          <div className="font-mono text-[11px] text-stone-500 tabular-nums">
            {efficiency.usedPctOfXmx}% of -Xmx
          </div>
        </div>

        <div className="sm:px-4 py-1">
          <div className="text-[11px] text-stone-400">Allocated (Committed)</div>
          <div className="font-mono text-base font-bold text-stone-100 tabular-nums mt-0.5">
            {loading ? '—' : `${allocatedMb} MB`}
          </div>
          <div className="font-mono text-[11px] text-stone-500 tabular-nums">
            -Xms{status?.xms_mb ?? 1024}M floor
          </div>
        </div>

        <div className="sm:px-4 py-1">
          <div className="text-[11px] text-stone-400">-Xmx Verification</div>
          <div className="font-mono text-base font-bold text-[#1cb5f6] tabular-nums mt-0.5">
            {status?.xmx_verified ? 'Verified' : 'Warning'}
          </div>
          <div className="font-mono text-[11px] text-stone-500 tabular-nums">
            {status?.gc_collections ?? 0} GC sweeps
          </div>
        </div>

        <div className="sm:pl-4 py-1">
          <div className="text-[11px] text-stone-400">Host Free Memory</div>
          <div className="font-mono text-base font-bold text-stone-100 tabular-nums mt-0.5">
            {status ? formatRamGb(status.host_free_ram_mb) : '—'}
          </div>
          <div className="font-mono text-[11px] text-stone-500 tabular-nums">
            of {status ? formatRamGb(status.host_total_ram_mb) : '—'} total
          </div>
        </div>
      </div>

      {/* Live Heap Trend Chart */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-[11px] text-stone-400">
          <span>Heap Telemetry Timeline (Used vs Allocated)</span>
          <span className="font-mono tabular-nums">
            {samples.length} / {MAX_SAMPLES} samples · Cap {effectiveXmx} MB
          </span>
        </div>

        <div
          data-testid="jvm-memory-chart"
          className="rounded-md border border-[#24262c] bg-[#121316] p-2.5"
        >
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="h-24 w-full overflow-visible"
            role="img"
            aria-label="Real-time JVM heap used and allocated memory chart"
          >
            {/* -Xmx ceiling dashed reference line */}
            <line
              x1="0"
              y1="6"
              x2={chartWidth}
              y2="6"
              stroke="#334155"
              strokeDasharray="4 4"
              strokeWidth="1"
            />
            <line
              x1="0"
              y1={chartHeight / 2}
              x2={chartWidth}
              y2={chartHeight / 2}
              stroke="#1f232a"
              strokeWidth="1"
            />

            {allocatedLine && (
              <polyline
                fill="none"
                stroke="#38556b"
                strokeWidth="2"
                points={allocatedLine}
              />
            )}
            {usedLine && (
              <polyline
                fill="none"
                stroke="#1cb5f6"
                strokeWidth="2.5"
                points={usedLine}
              />
            )}
          </svg>
        </div>
      </div>

      {/* Live Game Output Console */}
      <div className="space-y-2 border-t border-[#24262c] pt-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-stone-200">
            <Terminal className="h-3.5 w-3.5 text-[#1cb5f6]" />
            <span>Live Game Output Console</span>
            <span className="font-mono text-[11px] font-normal text-stone-500 tabular-nums">
              {logs.length} lines
            </span>
          </div>

          <button
            type="button"
            disabled={logs.length === 0}
            onClick={() => void handleCopyLogs()}
            className="inline-flex items-center gap-1.5 rounded border border-[#2c2f36] bg-[#121316] px-2.5 py-1 text-[11px] font-medium text-stone-300 hover:border-[#1cb5f6] hover:text-white disabled:opacity-40 transition-colors whitespace-nowrap"
          >
            {logsCopied ? (
              <Check className="h-3 w-3 text-[#1cb5f6]" />
            ) : (
              <Copy className="h-3 w-3" />
            )}
            <span>{logsCopied ? 'Copied' : 'Copy Logs'}</span>
          </button>
        </div>

        <div
          data-testid="jvm-console-output"
          className="max-h-44 overflow-y-auto rounded-md border border-[#24262c] bg-[#121316] p-3 font-mono text-[11px] leading-relaxed"
        >
          {logs.length === 0 ? (
            <div className="text-stone-500">
              No active 1.8.9 client output yet. Launch 1.8.9 to stream Agretium and GC logs.
            </div>
          ) : (
            <div className="space-y-1">
              {logs.map((entry) => (
                <div key={entry.id} className="break-all">
                  <span className="text-stone-500">[{entry.time}]</span>{' '}
                  <span
                    className={
                      entry.level === 'WARN'
                        ? 'text-amber-400'
                        : entry.level === 'DEBUG'
                        ? 'text-stone-400'
                        : 'text-[#1cb5f6]'
                    }
                  >
                    [{entry.thread}/{entry.level}]
                  </span>
                  <span className="text-stone-300">: {entry.message}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

