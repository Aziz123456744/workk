import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Bug,
  Check,
  CheckCircle2,
  Copy,
  Diamond,
  HelpCircle,
  Home,
  Maximize2,
  Menu,
  MessageSquare,
  Minus,
  Newspaper,
  Play,
  Settings,
  ShoppingBag,
  Square,
  User,
  Users,
  X,
} from 'lucide-react';
import {
  CLOAK_CATALOG,
  DEFAULT_ACCOUNTS,
  DEFAULT_FRIENDS,
  DEFAULT_MODS,
  DEFAULT_ORNITHE_CONFIG,
  DEFAULT_PREFERENCES,
  DEFAULT_SERVER_TILES,
  formatFileSize,
  LAUNCHER_NEWS,
  LOCAL_ACCOUNTS_STORAGE_KEY,
  LOCKED_VERSION_ID,
  mergeAccountLists,
  normalizeSettingsTo189,
  type AccountProfile,
  type AgretiumMod,
  type LauncherExtras,
  type LauncherPreferences,
  type LauncherSettings,
  type LaunchHistoryEntry,
  type LaunchResponse,
  type ModJarFile,
  type NewsArticle,
  type OrnitheConfig,
  type PreflightStatus,
  type ServerQuickTile,
  type SystemInfo,
  type VersionDownloadStatus,
} from './utils/launcherLogic';
import {
  addModJarsTauriApi,
  closeWindowApi,
  deleteModJarApi,
  downloadWindowsBuildChunked,
  fetchExtras,
  fetchLaunchHistory,
  fetchModJarsApi,
  fetchPreflight,
  fetchSettings,
  fetchSystemInfo,
  fetchVersionDownloadStatus,
  fetchWindowsBuildInfo,
  isElectronDesktopRuntime,
  isTauriDesktopRuntime,
  launchMinecraftApi,
  minimizeWindowApi,
  openModsFolderApi,
  resetVersionCacheApi,
  saveExtrasApi,
  saveSettingsApi,
  startVersionDownloadApi,
  toggleMaximizeWindowApi,
  toggleModJarApi,
  uploadModJarsWebApi,
  type WindowsBuildInfo,
} from './utils/api';
import { PlayView } from './components/PlayView';
import type { SettingsSubTab } from './components/SettingsView';

const SettingsView = lazy(() =>
  import('./components/SettingsView').then((m) => ({ default: m.SettingsView }))
);
const FolderPickerModal = lazy(() =>
  import('./components/FolderPickerModal').then((m) => ({ default: m.FolderPickerModal }))
);
const AccountModal = lazy(() =>
  import('./components/AccountModal').then((m) => ({ default: m.AccountModal }))
);
const ModsView = lazy(() =>
  import('./components/ModsView').then((m) => ({ default: m.ModsView }))
);
const CosmeticsView = lazy(() =>
  import('./components/CosmeticsView').then((m) => ({ default: m.CosmeticsView }))
);

type LeftSection =
  | 'home'
  | 'news'
  | 'cosmetics'
  | 'store'
  | 'help'
  | 'debug'
  | 'settings';

const AVATAR_URL = 'assets/images/avatar_voxel_player_1794735515902.jpg';

export default function App() {
  const [section, setSection] = useState<LeftSection>('home');
  const [settingsSubTab, setSettingsSubTab] = useState<SettingsSubTab>('game');
  const [selectedNews, setSelectedNews] = useState<NewsArticle | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [systemInfo, setSystemInfo] = useState<SystemInfo>({ total_ram_mb: 16384 });
  const [settings, setSettings] = useState<LauncherSettings | null>(null);
  const [savedSnapshot, setSavedSnapshot] = useState<LauncherSettings | null>(null);
  const [defaults, setDefaults] = useState<LauncherSettings | null>(null);
  const [configPath, setConfigPath] = useState<string>('launcher_config.json');

  const [preferences, setPreferences] = useState<LauncherPreferences>(DEFAULT_PREFERENCES);
  const [ornithe, setOrnithe] = useState<OrnitheConfig>(DEFAULT_ORNITHE_CONFIG);
  const [servers, setServers] = useState<ServerQuickTile[]>(DEFAULT_SERVER_TILES);
  const [mods, setMods] = useState<AgretiumMod[]>(DEFAULT_MODS);
  const [modJars, setModJars] = useState<ModJarFile[]>([]);
  const [modJarBusy, setModJarBusy] = useState(false);
  const [modJarError, setModJarError] = useState<string | null>(null);
  const [equippedCloakId, setEquippedCloakId] = useState<string>('agretium-gold');
  const [preflight, setPreflight] = useState<PreflightStatus | null>(null);
  const [downloadStatus, setDownloadStatus] = useState<VersionDownloadStatus | null>(null);

  const [accounts, setAccounts] = useState<AccountProfile[]>(DEFAULT_ACCOUNTS);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [friendsOpen, setFriendsOpen] = useState(false);
  const [copiedIpId, setCopiedIpId] = useState<string | null>(null);
  const [avatarFailed, setAvatarFailed] = useState(false);

  const [folderPickerField, setFolderPickerField] = useState<'mc_path' | 'java_path' | null>(null);
  const [infoModal, setInfoModal] = useState<{ title: string; body: string } | null>(null);

  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [launching, setLaunching] = useState(false);
  const [launchPhase, setLaunchPhase] = useState<string | null>(null);
  const [launchResult, setLaunchResult] = useState<LaunchResponse | null>(null);
  const [launchError, setLaunchError] = useState<string | null>(null);
  const [minimizedWindow, setMinimizedWindow] = useState(false);
  const [history, setHistory] = useState<LaunchHistoryEntry[]>([]);
  const [windowsBuild, setWindowsBuild] = useState<WindowsBuildInfo | null>(null);
  const [windowsDownloadState, setWindowsDownloadState] = useState<{
    active: boolean;
    percent: number;
    loadedBytes: number;
    totalBytes: number;
    error: string | null;
  }>({ active: false, percent: 0, loadedBytes: 0, totalBytes: 0, error: null });

  const handleDownloadWindowsBuild = useCallback(
    async (kind: 'installer' | 'portable', fileName: string, totalBytes: number) => {
      if (windowsDownloadState.active) return;
      setWindowsDownloadState({
        active: true,
        percent: 0,
        loadedBytes: 0,
        totalBytes,
        error: null,
      });
      try {
        await downloadWindowsBuildChunked(kind, fileName, totalBytes, (loaded, total) => {
          const pct = Math.min(100, Math.round((loaded * 100) / Math.max(1, total)));
          setWindowsDownloadState({
            active: true,
            percent: pct,
            loadedBytes: loaded,
            totalBytes: total,
            error: null,
          });
        });
        setWindowsDownloadState({
          active: false,
          percent: 100,
          loadedBytes: totalBytes,
          totalBytes,
          error: null,
        });
      } catch (err) {
        setWindowsDownloadState({
          active: false,
          percent: 0,
          loadedBytes: 0,
          totalBytes,
          error: err instanceof Error ? err.message : 'Windows build download failed',
        });
      }
    },
    [windowsDownloadState.active]
  );

  useEffect(() => {
    let active = true;
    async function init() {
      try {
        const [sys, cfg, hist, extras, winBuild] = await Promise.all([
          fetchSystemInfo(),
          fetchSettings(),
          fetchLaunchHistory(),
          fetchExtras(),
          fetchWindowsBuildInfo(),
        ]);
        if (!active) return;
        setWindowsBuild(winBuild);

        setSystemInfo(sys);
        const initialSettings = normalizeSettingsTo189(cfg.settings ?? cfg.defaults);
        setSettings(initialSettings);
        setSavedSnapshot(initialSettings);
        setDefaults(normalizeSettingsTo189(cfg.defaults));
        setConfigPath(cfg.configPath);
        setHistory(hist);
        setServers(extras.servers);
        setMods(extras.mods);
        setEquippedCloakId(extras.equippedCloakId);
        setPreferences(extras.preferences);
        setOrnithe(extras.ornithe ?? DEFAULT_ORNITHE_CONFIG);

        const serverAccounts =
          extras.accounts && extras.accounts.length > 0
            ? extras.accounts
            : DEFAULT_ACCOUNTS;

        let localStoredAccounts: AccountProfile[] = [];
        try {
          const rawLocal = window.localStorage.getItem(LOCAL_ACCOUNTS_STORAGE_KEY);
          if (rawLocal) {
            const parsed = JSON.parse(rawLocal);
            if (Array.isArray(parsed)) {
              localStoredAccounts = parsed as AccountProfile[];
            }
          }
        } catch {
          // Ignore malformed localStorage cache
        }

        let combinedAccounts = mergeAccountLists(serverAccounts, localStoredAccounts);
        if (
          initialSettings.account &&
          !combinedAccounts.some(
            (a) => a.username.toLowerCase() === initialSettings.account.toLowerCase()
          )
        ) {
          combinedAccounts = [
            ...combinedAccounts,
            {
              username: initialSettings.account,
              type: 'Offline',
              uuid: '00000000-0000-3000-8000-000000000099',
            },
          ];
        }
        setAccounts(combinedAccounts);
        try {
          window.localStorage.setItem(
            LOCAL_ACCOUNTS_STORAGE_KEY,
            JSON.stringify(combinedAccounts)
          );
        } catch {
          // Ignore storage quota errors
        }
      } catch (err) {
        if (!active) return;
        setLoadError(err instanceof Error ? err.message : 'Unable to initialize launcher');
      } finally {
        if (active) setLoading(false);
      }
    }
    void init();
    const unsubExit = (
      window as {
        electronAPI?: {
          onUnexpectedExit?: (
            cb: (payload: { code: number | null; message: string }) => void
          ) => () => void;
        };
      }
    ).electronAPI?.onUnexpectedExit?.(({ message }) => {
      setMinimizedWindow(false);
      setLaunchResult(null);
      setLaunchError(message);
    });
    return () => {
      active = false;
      unsubExit?.();
    };
  }, []);

  const refreshModJars = useCallback(async (mcPath: string) => {
    try {
      const list = await fetchModJarsApi(mcPath);
      setModJars(list);
      setModJarError(null);
    } catch {
      // Ignore transient folder read issues while typing mc_path
    }
  }, []);

  useEffect(() => {
    if (!settings) return;
    let active = true;
    const timer = window.setTimeout(async () => {
      try {
        const [result, jars] = await Promise.all([
          fetchPreflight(
            settings.mc_path,
            settings.java_path,
            ornithe.enabled,
            settings.optifine
          ),
          fetchModJarsApi(settings.mc_path).catch(() => null),
        ]);
        if (active) {
          setPreflight(result);
          if (jars) setModJars(jars);
        }
      } catch {
        // Ignore transient check failures while typing paths
      }
    }, 180);
    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [settings?.mc_path, settings?.java_path, ornithe.enabled, settings?.optifine]);

  const persistExtras = useCallback(
    (next: Partial<LauncherExtras>) => {
      const payload: LauncherExtras = {
        servers: next.servers ?? servers,
        mods: next.mods ?? mods,
        equippedCloakId: next.equippedCloakId ?? equippedCloakId,
        preferences: next.preferences ?? preferences,
        ornithe: next.ornithe ?? ornithe,
        accounts: next.accounts ?? accounts,
      };
      if (next.accounts) {
        try {
          window.localStorage.setItem(
            LOCAL_ACCOUNTS_STORAGE_KEY,
            JSON.stringify(next.accounts)
          );
        } catch {
          // Ignore storage quota errors
        }
      }
      void saveExtrasApi(payload).catch(() => {
        // Non-blocking background sync
      });
    },
    [servers, mods, equippedCloakId, preferences, ornithe, accounts]
  );

  const dirty = useMemo(() => {
    if (!settings || !savedSnapshot) return false;
    return JSON.stringify(settings) !== JSON.stringify(savedSnapshot);
  }, [settings, savedSnapshot]);

  const equippedCloakName = useMemo(() => {
    return (
      CLOAK_CATALOG.find((c) => c.id === equippedCloakId)?.name ??
      'Agretium Gold Cloak'
    );
  }, [equippedCloakId]);

  const handleChangeSetting = <K extends keyof LauncherSettings>(
    key: K,
    value: LauncherSettings[K]
  ) => {
    setSaveMessage(null);
    setSaveError(null);
    setLaunchError(null);
    setSettings((prev) => {
      if (!prev) return prev;
      return normalizeSettingsTo189({ ...prev, [key]: value });
    });
  };

  const handleChangePreference = <K extends keyof LauncherPreferences>(
    key: K,
    value: LauncherPreferences[K]
  ) => {
    const nextPrefs = { ...preferences, [key]: value };
    setPreferences(nextPrefs);
    persistExtras({ preferences: nextPrefs });
  };

  const handleSaveSettings = async (overrideSettings?: LauncherSettings) => {
    const target = overrideSettings ?? settings;
    if (!target) return;
    const normalized = normalizeSettingsTo189(target);
    setSaving(true);
    setSaveMessage(null);
    setSaveError(null);
    setLaunchError(null);
    try {
      const res = await saveSettingsApi(normalized);
      setSavedSnapshot(res.settings);
      setSettings(res.settings);
      setSaveMessage('Launcher settings saved to launcher_config.json.');
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleOrnithe = (enabled: boolean) => {
    const nextOrnithe: OrnitheConfig = { ...ornithe, enabled };
    setOrnithe(nextOrnithe);
    setLaunchError(null);
    persistExtras({ ornithe: nextOrnithe });
  };

  const handleResetVersionCache = async () => {
    if (!settings) return;
    try {
      const res = await resetVersionCacheApi(settings.mc_path);
      setPreflight(res.preflight);
      setDownloadStatus(null);
      setLaunchResult(null);
      setLaunchError(null);
      await refreshModJars(settings.mc_path);
    } catch (err) {
      setLaunchError(
        err instanceof Error ? err.message : 'Failed to reset 1.8.9 installation'
      );
    }
  };

  const runMissingDownloadSequence = async (targetSettings: LauncherSettings) => {
    let status = await startVersionDownloadApi(
      targetSettings.mc_path,
      ornithe,
      targetSettings.optifine
    );
    setDownloadStatus(status);

    while (status.state === 'downloading') {
      await new Promise((resolve) => window.setTimeout(resolve, 250));
      status = await fetchVersionDownloadStatus();
      setDownloadStatus(status);
    }

    if (status.state === 'error') {
      throw new Error(status.error || 'Version download failed');
    }

    const updatedPf = await fetchPreflight(
      targetSettings.mc_path,
      targetSettings.java_path,
      ornithe.enabled,
      targetSettings.optifine
    );
    setPreflight(updatedPf);
    await refreshModJars(targetSettings.mc_path);
  };

  const handleDownloadMissing = async () => {
    if (!settings || launching) return;
    const normalized = normalizeSettingsTo189(settings);
    setLaunchError(null);
    try {
      await runMissingDownloadSequence(normalized);
    } catch (err) {
      setLaunchError(err instanceof Error ? err.message : 'Failed to download Ornithe 1.8.9 files');
    }
  };

  const handleLaunch = async (serverAddress?: string, skipMinimize = false) => {
    if (!settings) return;
    const normalized = normalizeSettingsTo189(settings);
    const launchStartMs = performance.now();
    setLaunching(true);
    setLaunchError(null);
    setLaunchResult(null);

    try {
      // Fast-path: use cached verified preflight when paths are ready to avoid redundant round-trips
      const needsPreflightCheck = !preflight || !preflight.javaOk || preflight.needsDownload;
      if (needsPreflightCheck) {
        setLaunchPhase(
          ornithe.enabled
            ? 'Checking Java, 1.8.9 & Ornithe Loader...'
            : 'Checking Java & 1.8.9.jar...'
        );
        const pf = await fetchPreflight(
          normalized.mc_path,
          normalized.java_path,
          ornithe.enabled,
          normalized.optifine
        );
        setPreflight(pf);

        if (pf.needsDownload && (pf.javaOk || isTauriDesktopRuntime())) {
          setLaunchPhase(
            ornithe.enabled
              ? `Downloading 1.8.9, Ornithe ${ornithe.loaderVersion} & Argentum...`
              : 'Downloading Minecraft 1.8.9 client & assets...'
          );
          await runMissingDownloadSequence(normalized);
        }
      }

      setLaunchPhase(
        serverAddress
          ? `Connecting to ${serverAddress}...`
          : ornithe.enabled
          ? `Fast-booting Ornithe 1.8.9...`
          : 'Fast-booting 1.8.9 JVM...'
      );
      const enabledModIds = mods.filter((m) => m.enabled).map((m) => m.id);
      const res = await launchMinecraftApi(normalized, ornithe, serverAddress, enabledModIds);
      const clientElapsedMs = Math.max(1, Math.round(performance.now() - launchStartMs));
      const enhancedRes: LaunchResponse = {
        ...res,
        launchDurationMs: clientElapsedMs,
        historyEntry: {
          ...res.historyEntry,
          launchDurationMs: clientElapsedMs,
        },
      };
      setSavedSnapshot(normalized);
      setLaunchResult(enhancedRes);
      setHistory((prev) => [enhancedRes.historyEntry, ...prev].slice(0, 20));
      if (res.minimized && !skipMinimize) {
        setMinimizedWindow(true);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to launch Minecraft';
      setLaunchError(message);
      const updatedHistory = await fetchLaunchHistory();
      setHistory(updatedHistory);
    } finally {
      setLaunching(false);
      setLaunchPhase(null);
    }
  };

  const openSettingsTab = (tab: SettingsSubTab = 'game') => {
    setSettingsSubTab(tab);
    setSection('settings');
    setMobileNavOpen(false);
  };

  const leftNavItems: Array<{
    id: LeftSection;
    label: string;
    icon: typeof Home;
    onClick: () => void;
  }> = [
    { id: 'home', label: 'Home', icon: Home, onClick: () => setSection('home') },
    { id: 'news', label: 'News', icon: Newspaper, onClick: () => setSection('news') },
    {
      id: 'cosmetics',
      label: 'Cosmetics',
      icon: Diamond,
      onClick: () => setSection('cosmetics'),
    },
    { id: 'store', label: 'Mods & Packs', icon: ShoppingBag, onClick: () => setSection('store') },
    { id: 'help', label: 'Help', icon: HelpCircle, onClick: () => setSection('help') },
    {
      id: 'debug',
      label: 'Debug',
      icon: Bug,
      onClick: () => openSettingsTab('debug'),
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
      onClick: () => openSettingsTab('game'),
    },
  ];

  const footerLinks = [
    {
      label: 'About',
      body: 'Dedicated Minecraft 1.8.9 launcher built with persistent JSON profiles, Agretium support, and JVM memory tuning.',
    },
    {
      label: 'Status',
      body: `Runtime ready for Minecraft ${LOCKED_VERSION_ID}. Host memory detected: ${systemInfo.total_ram_mb} MB.`,
    },
    {
      label: 'Rules',
      body: 'Follow fair-play guidelines on 1.8.9 multiplayer servers and use approved performance configurations.',
    },
    {
      label: 'Terms',
      body: 'Launcher settings and logs are persisted locally inside your application config directory.',
    },
    {
      label: 'Privacy',
      body: 'No external telemetry is transmitted; account switching and launch logs stay local.',
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#121316] flex items-center justify-center p-6">
        <div className="w-full max-w-5xl space-y-6">
          <div className="h-60 rounded-xl bg-[#181a1f] border border-[#26282e] animate-pulse" />
          <div className="mx-auto h-28 w-80 rounded-lg bg-[#181a1f] border border-[#26282e] animate-pulse" />
        </div>
      </div>
    );
  }

  if (loadError || !settings || !defaults) {
    return (
      <div className="min-h-screen bg-[#121316] text-stone-100 flex items-center justify-center p-6">
        <div className="max-w-md w-full rounded-lg border border-red-800/70 bg-[#181a1f] p-6 space-y-4">
          <h1 className="font-display text-lg font-bold text-red-200">
            Unable to Connect to Launcher Backend
          </h1>
          <p className="text-sm text-stone-300">
            {loadError ?? 'Launcher configuration could not be initialized.'}
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff]"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (minimizedWindow && launchResult) {
    return (
      <div className="min-h-screen bg-[#121316] text-stone-100 flex items-center justify-center p-6">
        <div className="w-full max-w-lg rounded-xl border border-[#2c2f36] bg-[#181a1f] p-6 space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#1cb5f6]/15 border border-[#1cb5f6]/40 text-[#1cb5f6]">
                <Check className="h-5 w-5" />
              </div>
              <div>
                <h1 className="font-display text-lg font-bold text-white">
                  Launcher Minimized
                </h1>
                <p className="text-xs text-stone-400 mt-0.5">{launchResult.message}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMinimizedWindow(false)}
              className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] whitespace-nowrap shrink-0"
            >
              <Maximize2 className="h-3.5 w-3.5" />
              <span>Restore Launcher</span>
            </button>
          </div>

          <div className="border-t border-[#26282e] pt-4 space-y-2 text-xs">
            <div className="flex justify-between text-stone-400">
              <span>Version</span>
              <span className="font-mono text-stone-100">{LOCKED_VERSION_ID}</span>
            </div>
            <div className="flex justify-between text-stone-400">
              <span>Profile</span>
              <span className="font-medium text-stone-100">{settings.account}</span>
            </div>
            <div className="flex justify-between text-stone-400">
              <span>Resolution</span>
              <span className="font-mono text-stone-100 tabular-nums">{settings.resolution}</span>
            </div>
            {launchResult.launchDurationMs !== undefined && (
              <div className="flex justify-between text-stone-400">
                <span>Fast-Boot Handoff</span>
                <span className="font-mono text-[#7dd9fc] tabular-nums">
                  {(launchResult.launchDurationMs / 1000).toFixed(2)}s (&lt;9s PC target)
                </span>
              </div>
            )}
          </div>

          {!isElectronDesktopRuntime() && (
            <div className="rounded-md border border-[#1cb5f6]/35 bg-[#142029] px-3 py-2 text-xs text-stone-300">
              Web preview mode simulates the JVM handoff. To open the real Minecraft 1.8.9 window on your PC, run the downloaded <strong className="text-white">Agretium 1.8.9 Launcher.exe</strong>.
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen lg:h-screen lg:overflow-hidden bg-[#121316] text-stone-100 flex flex-col lg:flex-row">
      {/* Frameless Electron Window Top Drag Strip */}
      <div
        aria-hidden="true"
        className="hidden lg:block fixed top-0 left-16 right-[68px] h-3.5 z-30 app-drag-region"
      />
      {/* Mobile Header */}
      <header className="lg:hidden flex items-center justify-between border-b border-[#22242a] bg-[#16181c] px-4 py-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileNavOpen((v) => !v)}
            aria-label="Toggle launcher navigation"
            className="rounded p-1.5 text-stone-300 hover:bg-[#23262d]"
          >
            {mobileNavOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <span className="font-display text-base font-bold text-white">
            Client 1.8.9
          </span>
        </div>

        <button
          type="button"
          onClick={() => setAccountModalOpen(true)}
          className="flex items-center gap-2 rounded-md border border-[#2c2f36] bg-[#1c1f24] px-2.5 py-1.5 text-xs text-stone-200"
        >
          <User className="h-3.5 w-3.5 text-[#1cb5f6]" />
          <span>{settings.account}</span>
        </button>
      </header>

      {mobileNavOpen && (
        <nav className="lg:hidden border-b border-[#22242a] bg-[#16181c] px-3 py-2 grid grid-cols-2 gap-1">
          {leftNavItems.map((item) => {
            const Icon = item.icon;
            const active =
              (item.id === 'debug' && section === 'settings' && settingsSubTab === 'debug') ||
              (item.id === 'settings' && section === 'settings' && settingsSubTab !== 'debug') ||
              section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  item.onClick();
                  setMobileNavOpen(false);
                }}
                className={`flex items-center gap-2.5 rounded-md px-3 py-2 text-xs font-medium ${
                  active ? 'bg-[#1cb5f6]/15 text-[#1cb5f6]' : 'text-stone-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      )}

      {/* Left Narrow Rail (Matching Screenshot 1) */}
      <aside className="hidden lg:flex w-[84px] flex-col justify-between border-r border-[#1f2126] bg-[#16181c] py-4 shrink-0">
        <div className="flex flex-col items-center gap-6">
          {/* Hexagonal Client Emblem */}
          <button
            type="button"
            onClick={() => setSection('home')}
            aria-label="Go to Launcher Home"
            className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#1cb5f6]/15 border border-[#1cb5f6]/40 text-[#1cb5f6] hover:bg-[#1cb5f6]/25 transition-colors"
          >
            <svg viewBox="0 0 24 24" className="h-6 w-6 fill-current" aria-hidden="true">
              <path d="M12 2L20.5 7V17L12 22L3.5 17V7L12 2ZM12 6.2L7.5 8.8V15.2L12 17.8L16.5 15.2V8.8L12 6.2Z" />
            </svg>
          </button>

          <nav aria-label="Primary Sidebar Navigation" className="flex w-full flex-col gap-1">
            {leftNavItems.map((item) => {
              const Icon = item.icon;
              const isDebug =
                item.id === 'debug' && section === 'settings' && settingsSubTab === 'debug';
              const isSettings =
                item.id === 'settings' && section === 'settings' && settingsSubTab !== 'debug';
              const active =
                item.id === 'debug'
                  ? isDebug
                  : item.id === 'settings'
                  ? isSettings
                  : section === item.id;

              return (
                <button
                  key={item.id}
                  type="button"
                  title={item.label}
                  aria-label={item.label}
                  aria-current={active ? 'page' : undefined}
                  onClick={item.onClick}
                  className={`relative flex h-11 w-full items-center justify-center transition-colors ${
                    active
                      ? 'text-[#1cb5f6]'
                      : 'text-stone-400 hover:text-stone-100'
                  }`}
                >
                  {active && (
                    <span
                      aria-hidden="true"
                      className="absolute left-0 top-2 bottom-2 w-0.5 rounded-r bg-[#1cb5f6]"
                    />
                  )}
                  <Icon className="h-5 w-5" />
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Legal/Status Links */}
        <div className="flex flex-col items-start gap-1.5 px-3 text-[11px] text-stone-400">
          {footerLinks.map((link) => (
            <button
              key={link.label}
              type="button"
              onClick={() => setInfoModal({ title: link.label, body: link.body })}
              className="hover:text-stone-100 transition-colors text-left"
            >
              {link.label}
            </button>
          ))}
          <span className="pt-1 text-[10px] text-stone-600">© 2026</span>
        </div>
      </aside>

      {/* Main Center Canvas */}
      <main className="flex-1 min-w-0 px-4 sm:px-8 py-6 overflow-y-auto">
        <Suspense
          fallback={
            <div className="mx-auto max-w-5xl py-12">
              <div className="h-44 rounded-xl bg-[#181a1f] border border-[#26282e] animate-pulse" />
            </div>
          }
        >
          <div key={section} className="mx-auto max-w-5xl animate-view-enter">
          {section === 'home' && (
            <>
              <PlayView
                settings={settings}
                ornithe={ornithe}
                servers={servers}
                preflight={preflight}
                downloadStatus={downloadStatus}
                equippedCloakName={equippedCloakName}
                launching={launching}
                launchPhase={launchPhase}
                launchResult={launchResult}
                launchError={launchError}
                isDesktop={isElectronDesktopRuntime()}
                onChangeSetting={handleChangeSetting}
                onToggleOrnithe={handleToggleOrnithe}
                onResetVersionCache={() => void handleResetVersionCache()}
                onDownloadMissing={() => void handleDownloadMissing()}
                onToggleServerTile={(id) => {
                  const nextServers = servers.map((s) =>
                    s.id === id ? { ...s, enabled: !s.enabled } : s
                  );
                  setServers(nextServers);
                  persistExtras({ servers: nextServers });
                }}
                onAddServerTile={(tile) => {
                  const nextServers = [...servers, tile];
                  setServers(nextServers);
                  persistExtras({ servers: nextServers });
                }}
                onDeleteServerTile={(id) => {
                  const nextServers = servers.filter((s) => s.id !== id);
                  setServers(nextServers);
                  persistExtras({ servers: nextServers });
                }}
                onLaunch={(srvAddr) => void handleLaunch(srvAddr)}
                onOpenSettings={(tab = 'game') => openSettingsTab(tab)}
                onOpenNewsArticle={(article) => {
                  setSelectedNews(article);
                  setSection('news');
                }}
                onOpenCosmetics={() => setSection('cosmetics')}
              />

              {windowsBuild?.available && (
                <section className="mt-5 rounded-xl border border-[#1cb5f6]/40 bg-[#142029] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="text-sm font-bold text-white">
                      Windows Desktop Launcher (.exe) Ready
                    </h2>
                    <p className="text-xs text-stone-300 mt-0.5">
                      {windowsDownloadState.error ? (
                        <span className="text-rose-300">{windowsDownloadState.error}</span>
                      ) : windowsDownloadState.active ? (
                        `Downloading in 6 MB chunks: ${windowsDownloadState.percent}% (${formatFileSize(windowsDownloadState.loadedBytes)} / ${formatFileSize(windowsDownloadState.totalBytes)})`
                      ) : windowsDownloadState.percent === 100 ? (
                        'Download complete — extract the .zip and open Agretium 1.8.9 Launcher.exe.'
                      ) : (
                        'Download the native Windows build (.zip containing Agretium 1.8.9 Launcher.exe) to run Minecraft 1.8.9 + Ornithe 0.20.1 + mods on your PC.'
                      )}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {windowsBuild.installerName && (
                      <button
                        type="button"
                        disabled={windowsDownloadState.active}
                        onClick={() =>
                          void handleDownloadWindowsBuild(
                            'installer',
                            windowsBuild.installerName!,
                            windowsBuild.installerSizeBytes
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>
                          {windowsDownloadState.active
                            ? `Downloading ${windowsDownloadState.percent}%...`
                            : windowsBuild.installerName.toLowerCase().endsWith('.zip')
                              ? `Download Windows App (.zip · ${formatFileSize(windowsBuild.installerSizeBytes)})`
                              : `Download Installer .exe (${formatFileSize(windowsBuild.installerSizeBytes)})`}
                        </span>
                      </button>
                    )}
                    {windowsBuild.portableName && (
                      <button
                        type="button"
                        disabled={windowsDownloadState.active}
                        onClick={() =>
                          void handleDownloadWindowsBuild(
                            'portable',
                            windowsBuild.portableName!,
                            windowsBuild.portableSizeBytes
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#181a1f] px-3.5 py-2 text-xs font-semibold text-stone-100 hover:border-[#1cb5f6] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>
                          Portable .exe ({formatFileSize(windowsBuild.portableSizeBytes)})
                        </span>
                      </button>
                    )}
                  </div>
                </section>
              )}
            </>
          )}

          {section === 'settings' && (
            <SettingsView
              activeSubTab={settingsSubTab}
              onChangeSubTab={setSettingsSubTab}
              settings={settings}
              ornithe={ornithe}
              preferences={preferences}
              systemInfo={systemInfo}
              configPath={configPath}
              history={history}
              dirty={dirty}
              saving={saving}
              saveMessage={saveMessage}
              saveError={saveError}
              onChangeSetting={handleChangeSetting}
              onToggleOrnithe={handleToggleOrnithe}
              onChangePreference={handleChangePreference}
              onSave={() => void handleSaveSettings()}
              onResetDefaults={() => {
                setSettings(defaults);
                setPreferences(DEFAULT_PREFERENCES);
                setOrnithe(DEFAULT_ORNITHE_CONFIG);
                persistExtras({
                  preferences: DEFAULT_PREFERENCES,
                  ornithe: DEFAULT_ORNITHE_CONFIG,
                });
                setSaveMessage(null);
                setSaveError(null);
                setLaunchError(null);
              }}
              onPickFolder={(field) => setFolderPickerField(field)}
              onOpenAccounts={() => setAccountModalOpen(true)}
              onQuickLaunch={() => void handleLaunch(undefined, true)}
            />
          )}

          {section === 'news' && (
            <div className="mx-auto max-w-4xl space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="font-display text-2xl font-bold text-white">
                    Minecraft 1.8.9 News & Patch Notes
                  </h1>
                  <p className="text-sm text-stone-400 mt-0.5">
                    Client updates, optimization guides, and server feature announcements.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedNews(null);
                    setSection('home');
                  }}
                  className="rounded-md border border-[#2c2f36] bg-[#181a1f] px-3.5 py-2 text-xs font-medium text-stone-200 hover:bg-[#22252c]"
                >
                  Back to Home
                </button>
              </div>

              <div className="space-y-4">
                {(selectedNews ? [selectedNews, ...LAUNCHER_NEWS.filter((n) => n.id !== selectedNews.id)] : LAUNCHER_NEWS).map(
                  (article) => (
                    <article
                      key={article.id}
                      className="rounded-xl border border-[#26282e] bg-[#181a1f] p-5 space-y-2.5"
                    >
                      <div className="flex items-center justify-between text-xs text-stone-400">
                        <span>{article.date}</span>
                        <span className="font-mono tabular-nums">{article.views} views</span>
                      </div>
                      <h2 className="font-display text-lg font-bold text-white">
                        {article.title}
                      </h2>
                      <p className="text-sm text-stone-300">{article.summary}</p>
                      <ul className="list-disc pl-5 space-y-1 text-xs text-stone-400">
                        {article.body.map((line) => (
                          <li key={line}>{line}</li>
                        ))}
                      </ul>
                    </article>
                  )
                )}
              </div>
            </div>
          )}

          {section === 'cosmetics' && (
            <CosmeticsView
              account={settings.account}
              agretiumEnabled={settings.optifine}
              equippedCloakId={equippedCloakId}
              onSelectCloak={(cloakId) => {
                setEquippedCloakId(cloakId);
                persistExtras({ equippedCloakId: cloakId });
              }}
              onEnableAgretium={() => handleChangeSetting('optifine', true)}
              onBackHome={() => setSection('home')}
            />
          )}

          {section === 'store' && (
            <ModsView
              mods={mods}
              modJars={modJars}
              mcPath={settings.mc_path}
              modJarBusy={modJarBusy}
              modJarError={modJarError}
              agretiumEnabled={settings.optifine}
              newGcEnabled={settings.new_gc}
              argentumOk={preflight?.argentumOk ?? true}
              onToggleMod={(modId) => {
                const nextMods = mods.map((m) =>
                  m.id === modId ? { ...m, enabled: !m.enabled } : m
                );
                setMods(nextMods);
                persistExtras({ mods: nextMods });
              }}
              onToggleAgretium={() => handleChangeSetting('optifine', !settings.optifine)}
              onToggleNewGc={() => handleChangeSetting('new_gc', !settings.new_gc)}
              onInstallArgentumJars={() => {
                void handleDownloadMissing();
                setSection('home');
              }}
              onAddModJarsTauri={() => {
                void (async () => {
                  setModJarBusy(true);
                  setModJarError(null);
                  try {
                    const updated = await addModJarsTauriApi(settings.mc_path);
                    setModJars(updated);
                  } catch (err) {
                    setModJarError(err instanceof Error ? err.message : 'Failed adding .jar mods');
                  } finally {
                    setModJarBusy(false);
                  }
                })();
              }}
              onUploadWebModJars={(files) => {
                void (async () => {
                  setModJarBusy(true);
                  setModJarError(null);
                  try {
                    const updated = await uploadModJarsWebApi(settings.mc_path, files);
                    setModJars(updated);
                  } catch (err) {
                    setModJarError(err instanceof Error ? err.message : 'Failed uploading .jar mods');
                  } finally {
                    setModJarBusy(false);
                  }
                })();
              }}
              onToggleModJar={(fileName, enabled) => {
                void (async () => {
                  setModJarBusy(true);
                  setModJarError(null);
                  try {
                    const updated = await toggleModJarApi(settings.mc_path, fileName, enabled);
                    setModJars(updated);
                  } catch (err) {
                    setModJarError(err instanceof Error ? err.message : 'Failed updating mod state');
                  } finally {
                    setModJarBusy(false);
                  }
                })();
              }}
              onDeleteModJar={(fileName) => {
                void (async () => {
                  setModJarBusy(true);
                  setModJarError(null);
                  try {
                    const updated = await deleteModJarApi(settings.mc_path, fileName);
                    setModJars(updated);
                  } catch (err) {
                    setModJarError(err instanceof Error ? err.message : 'Failed deleting mod file');
                  } finally {
                    setModJarBusy(false);
                  }
                })();
              }}
              onOpenModsFolder={() => {
                void openModsFolderApi(settings.mc_path).catch((err) => {
                  setModJarError(err instanceof Error ? err.message : 'Unable to open mods folder');
                });
              }}
              onResetMods={() => {
                setMods(DEFAULT_MODS);
                persistExtras({ mods: DEFAULT_MODS });
              }}
              onBackHome={() => setSection('home')}
            />
          )}

          {section === 'help' && (
            <div className="mx-auto max-w-3xl space-y-5">
              <div className="flex items-center justify-between">
                <h1 className="font-display text-2xl font-bold text-white">
                  1.8.9 Launcher Diagnostics & PC (.exe) Build
                </h1>
                <button
                  type="button"
                  onClick={() => openSettingsTab('game')}
                  className="rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff]"
                >
                  Open Game Settings
                </button>
              </div>
              <div className="rounded-xl border border-[#26282e] bg-[#181a1f] p-5 space-y-3 text-sm text-stone-300">
                <p>
                  This launcher targets <strong className="text-white">Minecraft 1.8.9 + Ornithe 0.20.1 (Gen2)</strong> exclusively on <strong className="text-white">Java 25</strong>, bundling <strong className="text-white">Argentum 1.0.2</strong> (<code className="text-[#7dd9fc]">argentum-1.0.2.jar</code>, <code className="text-[#7dd9fc]">argentum-extras-1.0.2.jar</code>, <code className="text-[#7dd9fc]">cera-1.0.2.jar</code>), <code className="text-[#7dd9fc]">ornithe-standard-libraries</code>, <code className="text-[#7dd9fc]">pylon</code>, and <code className="text-[#7dd9fc]">forgecompat</code> inside <code className="text-stone-200">&lt;mc_path&gt;/mods/</code>.
                </p>
                <p className="text-xs text-stone-400">
                  Any custom 1.8.9 Ornithe or Forge <code className="text-stone-200">.jar</code> mods added in <strong className="text-stone-200">Mods &amp; Packs</strong> load automatically from <code className="text-stone-200">&lt;mc_path&gt;/mods/</code> on launch.
                </p>
              </div>

              <div className="rounded-xl border border-[#26282e] bg-[#181a1f] p-5 space-y-3">
                <h2 className="text-sm font-bold text-white">
                  Build &amp; Download Windows Desktop Installer (.exe)
                </h2>
                {windowsBuild?.available && (
                  <div className="flex flex-wrap items-center gap-2.5 pb-1">
                    {windowsBuild.installerName && (
                      <button
                        type="button"
                        disabled={windowsDownloadState.active}
                        onClick={() =>
                          void handleDownloadWindowsBuild(
                            'installer',
                            windowsBuild.installerName!,
                            windowsBuild.installerSizeBytes
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-md bg-[#1cb5f6] px-4 py-2 text-xs font-bold text-white hover:bg-[#38c6ff] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>
                          {windowsDownloadState.active
                            ? `Downloading ${windowsDownloadState.percent}% (${formatFileSize(windowsDownloadState.loadedBytes)} / ${formatFileSize(windowsDownloadState.totalBytes)})`
                            : `Download ${windowsBuild.installerName} (${formatFileSize(windowsBuild.installerSizeBytes)})`}
                        </span>
                      </button>
                    )}
                    {windowsBuild.portableName && (
                      <button
                        type="button"
                        disabled={windowsDownloadState.active}
                        onClick={() =>
                          void handleDownloadWindowsBuild(
                            'portable',
                            windowsBuild.portableName!,
                            windowsBuild.portableSizeBytes
                          )
                        }
                        className="inline-flex items-center gap-1.5 rounded-md border border-[#2c2f36] bg-[#121316] px-4 py-2 text-xs font-semibold text-stone-100 hover:border-[#1cb5f6] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>
                          Download Portable .exe ({formatFileSize(windowsBuild.portableSizeBytes)})
                        </span>
                      </button>
                    )}
                  </div>
                )}
                <p className="text-xs text-stone-400 leading-relaxed">
                  The workspace includes a complete <code className="text-stone-200">electron/</code> desktop shell and GitHub Actions workflow (<code className="text-stone-200">.github/workflows/build-windows-exe.yml</code>) to compile a native Windows <code className="text-stone-200">.exe</code> installer:
                </p>
                <pre className="rounded-md border border-[#24262c] bg-[#121316] p-3 font-mono text-xs text-[#8fe0ff] overflow-x-auto">
{`npm install
npm run electron:build`}
                </pre>
                <p className="text-[11px] text-stone-500">
                  Output binary: <code className="text-stone-300">release/Agretium 1.8.9 Launcher Setup 1.0.0.exe</code>
                </p>
              </div>
            </div>
          )}
          </div>
        </Suspense>
      </main>

      {/* Right Narrow Utility Rail (Matching Screenshot 1) */}
      <aside className="hidden lg:flex w-[68px] flex-col justify-between border-l border-[#1f2126] bg-[#16181c] py-3 shrink-0">
        <div className="flex flex-col items-center gap-4">
          {/* Top-right Window Controls */}
          <div className="flex items-center gap-2 text-stone-500 text-xs app-no-drag">
            <button
              type="button"
              onClick={() => {
                if (isElectronDesktopRuntime()) {
                  void minimizeWindowApi();
                } else {
                  setMinimizedWindow(true);
                }
              }}
              disabled={!isElectronDesktopRuntime() && !launchResult}
              title="Minimize Launcher"
              aria-label="Minimize Launcher"
              className="hover:text-stone-200 disabled:opacity-40 transition-colors"
            >
              <Minus className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => void toggleMaximizeWindowApi()}
              disabled={!isElectronDesktopRuntime()}
              title="Maximize / Restore Launcher"
              aria-label="Maximize or Restore Launcher"
              className="hover:text-stone-200 disabled:opacity-40 transition-colors"
            >
              <Square className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={() => void closeWindowApi()}
              disabled={!isElectronDesktopRuntime()}
              title="Close Launcher"
              aria-label="Close Launcher"
              className="hover:text-red-400 disabled:opacity-40 transition-colors"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Player Avatar */}
          <button
            type="button"
            onClick={() => setAccountModalOpen(true)}
            title={`Active profile: ${settings.account}`}
            aria-label={`Switch player account (current: ${settings.account})`}
            className="h-10 w-10 overflow-hidden rounded border border-[#2e3138] bg-[#22252b] hover:border-[#1cb5f6] transition-colors"
          >
            {!avatarFailed ? (
              <img
                src={AVATAR_URL}
                alt={settings.account}
                loading="eager"
                decoding="async"
                referrerPolicy="no-referrer"
                onError={() => setAvatarFailed(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <User className="h-5 w-5 text-stone-300 m-auto" />
            )}
          </button>

          {/* Utility Icons */}
          <div className="flex flex-col items-center gap-3 pt-2">
            <button
              type="button"
              aria-label="Open notifications"
              onClick={() => setNotificationsOpen(true)}
              className="relative rounded-md p-2 text-stone-300 hover:bg-[#22252c] hover:text-white transition-colors"
            >
              <Bell className="h-4.5 w-4.5" />
              {history.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#1cb5f6] px-1 font-mono text-[9px] font-bold text-white tabular-nums">
                  {Math.min(9, history.length)}
                </span>
              )}
            </button>
            <button
              type="button"
              aria-label="Open 1.8.9 friends list"
              onClick={() => setFriendsOpen(true)}
              className="rounded-md p-2 text-stone-300 hover:bg-[#22252c] hover:text-white transition-colors"
            >
              <Users className="h-4.5 w-4.5" />
            </button>
            <button
              type="button"
              aria-label="Open social settings"
              onClick={() => openSettingsTab('social')}
              className="rounded-md p-2 text-stone-300 hover:bg-[#22252c] hover:text-white transition-colors"
            >
              <MessageSquare className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>

        {/* Bottom Rail Settings Shortcut */}
        <div className="flex flex-col items-center gap-3 text-stone-500">
          <button
            type="button"
            aria-label="Open launcher settings"
            onClick={() => openSettingsTab('launcher')}
            className="rounded-md p-2 hover:bg-[#22252c] hover:text-stone-200 transition-colors"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </aside>

      <Suspense fallback={null}>
        <FolderPickerModal
          isOpen={folderPickerField !== null}
          title={
            folderPickerField === 'java_path'
              ? 'Select Java Runtime Directory'
              : 'Select Minecraft Installation Directory'
          }
          initialPath={
            folderPickerField === 'java_path' ? settings.java_path : settings.mc_path
          }
          mcPath={settings.mc_path}
          onSelect={(selectedPath) => {
            if (folderPickerField) {
              handleChangeSetting(folderPickerField, selectedPath);
            }
          }}
          onClose={() => setFolderPickerField(null)}
        />

        <AccountModal
          isOpen={accountModalOpen}
          accounts={accounts}
          activeAccount={settings.account}
          onSelectAccount={(username) => {
            const updated = normalizeSettingsTo189({ ...settings, account: username });
            setSettings(updated);
            void handleSaveSettings(updated);
          }}
          onAddAccount={(profile) => {
            const nextAccounts = [...accounts, profile];
            setAccounts(nextAccounts);
            persistExtras({ accounts: nextAccounts });
          }}
          onDeleteAccount={(username) => {
            const nextAccounts = accounts.filter((a) => a.username !== username);
            setAccounts(nextAccounts);
            persistExtras({ accounts: nextAccounts });
            if (settings.account === username && nextAccounts.length > 0) {
              const fallback = normalizeSettingsTo189({
                ...settings,
                account: nextAccounts[0].username,
              });
              setSettings(fallback);
              void handleSaveSettings(fallback);
            }
          }}
          onClose={() => setAccountModalOpen(false)}
        />
      </Suspense>

      {/* Right-Rail Notifications Modal */}
      {notificationsOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="notifications-modal-title"
        >
          <div className="w-full max-w-md rounded-lg border border-[#2c2f36] bg-[#181a1f] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#26282e] px-5 py-4">
              <div>
                <h2 id="notifications-modal-title" className="text-base font-semibold text-white">
                  Launcher Notifications
                </h2>
                <p className="text-xs text-stone-400 mt-0.5">
                  Runtime preflight status and recent 1.8.9 launch activity.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setNotificationsOpen(false)}
                aria-label="Close notifications dialog"
                className="rounded p-1.5 text-stone-400 hover:bg-[#23262d] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="max-h-80 overflow-y-auto divide-y divide-[#24262c] p-4 space-y-1">
              <div className="pb-3 flex items-start gap-3">
                {preflight?.javaOk && !preflight?.needsDownload ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                )}
                <div className="text-xs space-y-0.5">
                  <div className="font-semibold text-stone-100">
                    {preflight?.javaOk && !preflight?.needsDownload
                      ? ornithe.enabled
                        ? `Ornithe ${ornithe.loaderVersion} + 1.8.9 Ready`
                        : 'Minecraft 1.8.9 Runtime Verified'
                      : preflight?.needsDownload
                      ? 'New Player Download Queued on Play'
                      : '1.8.9 Path Attention Needed'}
                  </div>
                  <div className="text-stone-400">
                    Java: {preflight?.javaOk ? 'Ready' : 'Missing'} · Client:{' '}
                    {preflight?.jarOk && preflight?.assetsOk ? 'Ready' : 'Auto-Download'} ·{' '}
                    Ornithe: {ornithe.enabled ? (preflight?.ornitheOk ? 'Ready' : 'Auto-Download') : 'Off'}
                  </div>
                </div>
              </div>

              {history.length === 0 ? (
                <div className="py-6 text-center text-xs text-stone-500">
                  No recent 1.8.9 launches recorded yet.
                </div>
              ) : (
                history.slice(0, 6).map((item) => (
                  <div key={item.id} className="pt-3 pb-2 text-xs space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={
                          item.status === 'launched'
                            ? 'font-semibold text-[#1cb5f6]'
                            : 'font-semibold text-red-400'
                        }
                      >
                        {item.status === 'launched' ? 'Launched' : 'Launch Failed'}
                      </span>
                      <span className="font-mono text-[11px] text-stone-500 tabular-nums">
                        {new Date(item.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-stone-200">{item.message}</div>
                  </div>
                ))
              )}
            </div>

            <div className="border-t border-[#26282e] px-5 py-3 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setNotificationsOpen(false);
                  openSettingsTab('debug');
                }}
                className="text-xs font-medium text-[#1cb5f6] hover:underline"
              >
                Open JVM Debug Console
              </button>
              <button
                type="button"
                onClick={() => setNotificationsOpen(false)}
                className="rounded-md bg-[#1cb5f6] px-4 py-1.5 text-xs font-semibold text-white hover:bg-[#38c6ff]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Right-Rail 1.8.9 Friends & Party Modal */}
      {friendsOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="friends-modal-title"
        >
          <div className="w-full max-w-md rounded-lg border border-[#2c2f36] bg-[#181a1f] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#26282e] px-5 py-4">
              <div>
                <h2 id="friends-modal-title" className="text-base font-semibold text-white">
                  1.8.9 Friends & Party
                </h2>
                <p className="text-xs text-stone-400 mt-0.5">
                  Join friends currently playing Minecraft 1.8.9 multiplayer.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setFriendsOpen(false)}
                aria-label="Close friends dialog"
                className="rounded p-1.5 text-stone-400 hover:bg-[#23262d] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="divide-y divide-[#24262c] p-4">
              {DEFAULT_FRIENDS.map((friend) => (
                <div
                  key={friend.id}
                  className="flex items-center justify-between gap-3 py-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-stone-100 truncate">
                        {friend.username}
                      </span>
                      <span className="text-[11px] text-stone-400">
                        · {friend.status === 'in-game' ? 'In Game' : 'Online'}
                      </span>
                    </div>
                    <div className="text-xs text-stone-400 truncate mt-0.5">
                      {friend.activity}
                    </div>
                  </div>

                  {friend.serverAddress ? (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        aria-label={`Copy ${friend.serverName} IP`}
                        onClick={() => {
                          void navigator.clipboard.writeText(friend.serverAddress!);
                          setCopiedIpId(friend.id);
                          window.setTimeout(() => setCopiedIpId(null), 1500);
                        }}
                        className="rounded border border-[#2c2f36] bg-[#121316] p-1.5 text-stone-300 hover:border-[#1cb5f6] hover:text-white transition-colors"
                      >
                        {copiedIpId === friend.id ? (
                          <Check className="h-3.5 w-3.5 text-[#1cb5f6]" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setFriendsOpen(false);
                          void handleLaunch(friend.serverAddress);
                        }}
                        className="inline-flex items-center gap-1 rounded bg-[#1cb5f6] px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-[#38c6ff] whitespace-nowrap"
                      >
                        <Play className="h-3 w-3 fill-current" />
                        <span>Join</span>
                      </button>
                    </div>
                  ) : (
                    <span className="text-[11px] text-stone-500 whitespace-nowrap">
                      In Lobby
                    </span>
                  )}
                </div>
              ))}
            </div>

            <div className="border-t border-[#26282e] px-5 py-3 flex justify-end">
              <button
                type="button"
                onClick={() => setFriendsOpen(false)}
                className="rounded-md border border-[#2c2f36] bg-[#121316] px-4 py-1.5 text-xs font-medium text-stone-200 hover:text-white"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {infoModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="info-modal-title"
        >
          <div className="w-full max-w-md rounded-lg border border-[#2c2f36] bg-[#181a1f] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 id="info-modal-title" className="text-base font-bold text-white">
                {infoModal.title}
              </h2>
              <button
                type="button"
                onClick={() => setInfoModal(null)}
                aria-label="Close modal"
                className="rounded p-1 text-stone-400 hover:bg-[#23262d] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-sm text-stone-300 leading-relaxed">{infoModal.body}</p>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setInfoModal(null)}
                className="rounded-md bg-[#1cb5f6] px-4 py-1.5 text-xs font-bold text-white hover:bg-[#38c6ff]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
