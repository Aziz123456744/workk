import {
  DEFAULT_EXTRAS,
  type JvmStatusSnapshot,
  type LauncherExtras,
  type LauncherSettings,
  type LaunchHistoryEntry,
  type LaunchResponse,
  type ModJarFile,
  type OrnitheConfig,
  type PreflightStatus,
  type SystemInfo,
  type VersionDownloadStatus,
} from './launcherLogic';

export interface SettingsPayload {
  settings: LauncherSettings | null;
  defaults: LauncherSettings;
  configPath: string;
}

export interface DirectoryEntry {
  name: string;
  path: string;
  isDirectory: boolean;
  hint?: string;
}

export interface DirectoryListing {
  currentPath: string;
  parentPath: string | null;
  entries: DirectoryEntry[];
  presets: Array<{ label: string; path: string; description: string }>;
}

interface DefaultPathsPayload {
  mc_path: string;
  java_path: string;
  config_path: string;
}

interface ElectronAPI {
  isElectron?: boolean;
  platform?: string;
  invoke: <T = unknown>(cmd: string, args?: Record<string, unknown>) => Promise<T>;
}

interface TauriInternals {
  invoke: <T = unknown>(cmd: string, args?: Record<string, unknown>) => Promise<T>;
}

function getElectronApi(): ElectronAPI | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as { electronAPI?: ElectronAPI }).electronAPI;
}

function getTauriInternals(): TauriInternals | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as { __TAURI_INTERNALS__?: TauriInternals }).__TAURI_INTERNALS__;
}

export function isElectronDesktopRuntime(): boolean {
  return Boolean(getElectronApi()?.invoke);
}

export function isTauriDesktopRuntime(): boolean {
  return Boolean(getElectronApi()?.invoke || getTauriInternals()?.invoke);
}

async function desktopInvoke<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  const electronApi = getElectronApi();
  if (electronApi?.invoke) {
    return electronApi.invoke<T>(cmd, args);
  }
  const internals = getTauriInternals();
  if (internals?.invoke) {
    return internals.invoke<T>(cmd, args);
  }
  throw new Error('Desktop runtime is not active');
}

export async function fetchSystemInfo(): Promise<SystemInfo> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<SystemInfo>('get_system_info');
  }
  const res = await fetch('/api/system-info');
  if (!res.ok) {
    throw new Error('Failed to load host system info');
  }
  return res.json();
}

export async function fetchSettings(): Promise<SettingsPayload> {
  if (isTauriDesktopRuntime()) {
    const [loaded, paths] = await Promise.all([
      desktopInvoke<LauncherSettings | null>('load_settings'),
      desktopInvoke<DefaultPathsPayload>('get_default_paths'),
    ]);
    const defaults: LauncherSettings = {
      version: '1.8.9',
      account: 'AlexBuilder',
      optifine: true,
      beta: false,
      ram_mb: 3072,
      mc_path: paths.mc_path,
      java_path: paths.java_path,
      resolution: '1280x720',
      new_gc: true,
      minimize_on_launch: true,
    };
    return {
      settings: loaded,
      defaults,
      configPath: paths.config_path,
    };
  }
  const res = await fetch('/api/settings');
  if (!res.ok) {
    throw new Error('Failed to load launcher configuration');
  }
  return res.json();
}

export async function saveSettingsApi(
  settings: LauncherSettings
): Promise<{ ok: boolean; settings: LauncherSettings }> {
  if (isTauriDesktopRuntime()) {
    await desktopInvoke('save_settings', { settings });
    return { ok: true, settings };
  }
  const res = await fetch('/api/settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to save launcher settings');
  }
  return data;
}

export async function fetchExtras(): Promise<LauncherExtras> {
  if (isTauriDesktopRuntime()) {
    try {
      const diskExtras = await desktopInvoke<LauncherExtras | null>('load_extras');
      if (diskExtras) {
        return {
          ...DEFAULT_EXTRAS,
          ...diskExtras,
          preferences: {
            ...DEFAULT_EXTRAS.preferences,
            ...(diskExtras.preferences ?? {}),
          },
          ornithe: {
            ...DEFAULT_EXTRAS.ornithe,
            ...(diskExtras.ornithe ?? {}),
          },
        };
      }
    } catch {
      // Fall back to localStorage/defaults cleanly
    }
    const raw = window.localStorage.getItem('agretium_launcher_extras');
    if (raw) {
      try {
        return {
          ...DEFAULT_EXTRAS,
          ...(JSON.parse(raw) as Partial<LauncherExtras>),
        };
      } catch {
        return { ...DEFAULT_EXTRAS };
      }
    }
    return { ...DEFAULT_EXTRAS };
  }
  const res = await fetch('/api/extras');
  if (!res.ok) {
    throw new Error('Failed to load launcher extras');
  }
  return res.json();
}

export async function saveExtrasApi(extras: LauncherExtras): Promise<LauncherExtras> {
  if (isTauriDesktopRuntime()) {
    window.localStorage.setItem('agretium_launcher_extras', JSON.stringify(extras));
    await desktopInvoke('save_extras', { extras });
    return extras;
  }
  const res = await fetch('/api/extras', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(extras),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to save launcher extras');
  }
  return data.extras;
}

export async function fetchPreflight(
  mcPath: string,
  javaPath: string,
  ornitheEnabled: boolean,
  agretiumEnabled: boolean
): Promise<PreflightStatus> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<PreflightStatus>('check_ornithe_preflight', {
      mcPath,
      javaPath,
      ornitheEnabled,
      agretiumEnabled,
    });
  }
  const params = new URLSearchParams({
    mc_path: mcPath,
    java_path: javaPath,
    ornithe: String(ornitheEnabled),
    agretium: String(agretiumEnabled),
  });
  const res = await fetch(`/api/preflight?${params.toString()}`);
  if (!res.ok) {
    throw new Error('Failed to check Minecraft 1.8.9 preflight status');
  }
  return res.json();
}

export async function startVersionDownloadApi(
  mcPath: string,
  ornithe: OrnitheConfig,
  includeArgentum: boolean
): Promise<VersionDownloadStatus> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<VersionDownloadStatus>('download_ornithe_and_mods', {
      mcPath,
      ornithe,
      includeArgentum,
    });
  }
  const res = await fetch('/api/version/download', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mc_path: mcPath, ornithe, includeArgentum }),
  });
  if (!res.ok) {
    throw new Error('Failed to start 1.8.9 version download');
  }
  return res.json();
}

export async function fetchVersionDownloadStatus(): Promise<VersionDownloadStatus> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<VersionDownloadStatus>('get_download_status');
  }
  const res = await fetch('/api/version/download-status');
  if (!res.ok) {
    throw new Error('Failed to read download progress');
  }
  return res.json();
}

export async function resetVersionCacheApi(
  mcPath: string
): Promise<{ ok: boolean; preflight: PreflightStatus }> {
  if (isTauriDesktopRuntime()) {
    const preflight = await desktopInvoke<PreflightStatus>('reset_version_cache', { mcPath });
    return { ok: true, preflight };
  }
  const res = await fetch('/api/version/reset', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mc_path: mcPath }),
  });
  if (!res.ok) {
    throw new Error('Failed to reset 1.8.9 installation');
  }
  return res.json();
}

export async function launchMinecraftApi(
  settings: LauncherSettings,
  ornithe: OrnitheConfig,
  serverAddress?: string,
  enabledMods?: string[]
): Promise<LaunchResponse> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<LaunchResponse>('launch_minecraft', {
      settings,
      ornithe,
      serverAddress: serverAddress ?? null,
      enabledMods: enabledMods ?? [],
    });
  }
  const res = await fetch('/api/launch', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...settings, ornithe, serverAddress, enabledMods }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to launch Minecraft');
  }
  return data;
}

export async function fetchLaunchHistory(): Promise<LaunchHistoryEntry[]> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<LaunchHistoryEntry[]>('load_launch_history');
  }
  const res = await fetch('/api/launch/history');
  if (!res.ok) {
    return [];
  }
  const data = await res.json();
  return data.history ?? [];
}

export async function browseDirectoryApi(
  dirPath?: string,
  mcPath?: string
): Promise<DirectoryListing> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<DirectoryListing>('list_directory', {
      dirPath: dirPath ?? null,
      mcPath: mcPath ?? null,
    });
  }
  const params = dirPath ? `?path=${encodeURIComponent(dirPath)}` : '';
  const res = await fetch(`/api/fs/list${params}`);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Unable to inspect directory');
  }
  return data;
}

export async function pickNativeFolderApi(): Promise<string | null> {
  if (!isTauriDesktopRuntime()) return null;
  return desktopInvoke<string | null>('pick_folder');
}

export async function fetchJvmStatus(): Promise<JvmStatusSnapshot> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<JvmStatusSnapshot>('get_jvm_status');
  }
  const res = await fetch('/api/jvm-status');
  if (!res.ok) {
    throw new Error('Failed to poll JVM status');
  }
  return res.json();
}

export async function triggerJvmGcApi(): Promise<JvmStatusSnapshot> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<JvmStatusSnapshot>('trigger_jvm_gc');
  }
  const res = await fetch('/api/jvm-status/gc', { method: 'POST' });
  if (!res.ok) {
    throw new Error('Failed to trigger JVM garbage collection');
  }
  return res.json();
}

export async function stopJvmSessionApi(): Promise<JvmStatusSnapshot> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<JvmStatusSnapshot>('stop_jvm_session');
  }
  const res = await fetch('/api/jvm-status/stop', { method: 'POST' });
  if (!res.ok) {
    throw new Error('Failed to stop JVM session');
  }
  return res.json();
}

export async function fetchModJarsApi(mcPath: string): Promise<ModJarFile[]> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<ModJarFile[]>('list_mod_jars', { mcPath });
  }
  const res = await fetch(`/api/mods/files?mc_path=${encodeURIComponent(mcPath)}`);
  if (!res.ok) {
    throw new Error('Failed to scan mods folder');
  }
  const data = (await res.json()) as { mods: ModJarFile[] };
  return data.mods ?? [];
}

export async function addModJarsTauriApi(mcPath: string): Promise<ModJarFile[]> {
  return desktopInvoke<ModJarFile[]>('add_mod_jars', { mcPath });
}

export async function uploadModJarsWebApi(
  mcPath: string,
  files: Array<{ fileName: string; base64Data: string }>
): Promise<ModJarFile[]> {
  const res = await fetch('/api/mods/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mc_path: mcPath, files }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to upload .jar mod');
  }
  return data.mods ?? [];
}

export async function toggleModJarApi(
  mcPath: string,
  fileName: string,
  enabled: boolean
): Promise<ModJarFile[]> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<ModJarFile[]>('toggle_mod_jar', { mcPath, fileName, enabled });
  }
  const res = await fetch('/api/mods/toggle', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mc_path: mcPath, fileName, enabled }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to toggle mod JAR');
  }
  return data.mods ?? [];
}

export async function deleteModJarApi(
  mcPath: string,
  fileName: string
): Promise<ModJarFile[]> {
  if (isTauriDesktopRuntime()) {
    return desktopInvoke<ModJarFile[]>('delete_mod_jar', { mcPath, fileName });
  }
  const res = await fetch('/api/mods/file', {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mc_path: mcPath, fileName }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to remove mod JAR');
  }
  return data.mods ?? [];
}

export async function openModsFolderApi(mcPath: string): Promise<void> {
  if (isTauriDesktopRuntime()) {
    await desktopInvoke('open_mods_folder', { mcPath });
  }
}

export interface WindowsBuildInfo {
  available: boolean;
  installerName: string | null;
  installerSizeBytes: number;
  portableName: string | null;
  portableSizeBytes: number;
}

export async function fetchWindowsBuildInfo(): Promise<WindowsBuildInfo> {
  if (isTauriDesktopRuntime()) {
    return {
      available: false,
      installerName: null,
      installerSizeBytes: 0,
      portableName: null,
      portableSizeBytes: 0,
    };
  }
  const res = await fetch('/api/windows-build');
  if (!res.ok) {
    return {
      available: false,
      installerName: null,
      installerSizeBytes: 0,
      portableName: null,
      portableSizeBytes: 0,
    };
  }
  return res.json();
}

export async function downloadWindowsBuildChunked(
  kind: 'installer' | 'portable',
  fileName: string,
  totalBytes: number,
  onProgress?: (loadedBytes: number, totalBytes: number) => void
): Promise<void> {
  const chunkSize = 6 * 1024 * 1024;
  const parts: ArrayBuffer[] = [];
  let loaded = 0;

  while (loaded < totalBytes) {
    const length = Math.min(chunkSize, totalBytes - loaded);
    const resp = await fetch(
      `/api/windows-build/chunk?kind=${encodeURIComponent(kind)}&offset=${loaded}&length=${length}`,
      { cache: 'no-store' }
    );
    if (!resp.ok) {
      throw new Error(`Chunk download failed (HTTP ${resp.status})`);
    }
    const buf = await resp.arrayBuffer();
    if (buf.byteLength === 0) {
      throw new Error('Unexpected empty chunk received');
    }
    parts.push(buf);
    loaded += buf.byteLength;
    onProgress?.(loaded, totalBytes);
  }

  const mimeType = fileName.toLowerCase().endsWith('.zip')
    ? 'application/zip'
    : 'application/octet-stream';
  const blob = new Blob(parts, { type: mimeType });
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(blobUrl), 60_000);
}

export async function minimizeWindowApi(): Promise<void> {
  const electronApi = getElectronApi();
  if (electronApi?.invoke) {
    await electronApi.invoke('window_minimize');
  }
}

export async function toggleMaximizeWindowApi(): Promise<boolean> {
  const electronApi = getElectronApi();
  if (electronApi?.invoke) {
    return electronApi.invoke<boolean>('window_toggle_maximize');
  }
  return false;
}

export async function closeWindowApi(): Promise<void> {
  const electronApi = getElectronApi();
  if (electronApi?.invoke) {
    await electronApi.invoke('window_close');
  }
}
