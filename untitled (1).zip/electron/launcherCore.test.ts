import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  ElectronLauncherBackend,
  buildJavaCompatFlags,
  currentMojangOsName,
  generateOfflineUuid,
  isLibraryAllowedForOs,
  mavenCoordToRelPath,
  mavenGroupArtifactKey,
  normalizeJavaHomeInput,
  parseJavaMajorFromReleaseFile,
  parseJavaMajorFromVersionOutput,
  resolveJavaBin,
  scanModJars,
} from './launcherCore';

test('mavenCoordToRelPath resolves standard and classified coordinates', () => {
  assert.equal(
    mavenCoordToRelPath('net.fabricmc:fabric-loader:0.20.1'),
    'net/fabricmc/fabric-loader/0.20.1/fabric-loader-0.20.1.jar'
  );
  assert.equal(
    mavenCoordToRelPath('org.lwjgl.lwjgl:lwjgl-platform:2.9.4-nightly-20150209:natives-windows'),
    'org/lwjgl/lwjgl/lwjgl-platform/2.9.4-nightly-20150209/lwjgl-platform-2.9.4-nightly-20150209-natives-windows.jar'
  );
  assert.equal(mavenGroupArtifactKey('net.ornithemc:calamus-intermediary-gen2:1.8.9'), 'net.ornithemc:calamus-intermediary-gen2');
});

test('parseJavaMajorFromVersionOutput parses Java 8 and Java 25 version banners', () => {
  assert.equal(
    parseJavaMajorFromVersionOutput('openjdk version "25.0.1" 2025-10-21'),
    25
  );
  assert.equal(
    parseJavaMajorFromVersionOutput('java version "1.8.0_401"'),
    8
  );
  assert.equal(parseJavaMajorFromVersionOutput('not a java output'), null);
});

test('parseJavaMajorFromReleaseFile detects Java 25 from JDK release file', () => {
  const tempJava = fs.mkdtempSync(path.join(os.tmpdir(), 'agretium-java-rel-'));
  fs.writeFileSync(path.join(tempJava, 'release'), 'IMPLEMENTOR="Eclipse Adoptium"\nJAVA_VERSION="25.0.2"\n');
  assert.equal(parseJavaMajorFromReleaseFile(tempJava), 25);
  assert.equal(parseJavaMajorFromReleaseFile(path.join(tempJava, 'bin')), 25);
  fs.rmSync(tempJava, { recursive: true, force: true });
});

test('isLibraryAllowedForOs evaluates Mojang OS rules accurately', () => {
  assert.equal(currentMojangOsName('win32'), 'windows');
  assert.equal(
    isLibraryAllowedForOs({ rules: [{ action: 'allow', os: { name: 'osx' } }] }, 'win32'),
    false
  );
  assert.equal(
    isLibraryAllowedForOs(
      {
        rules: [
          { action: 'allow' },
          { action: 'disallow', os: { name: 'osx' } },
        ],
      },
      'win32'
    ),
    true
  );
});

test('generateOfflineUuid produces deterministic 32-char v3-formatted hex string', () => {
  const u1 = generateOfflineUuid('AlexBuilder');
  const u2 = generateOfflineUuid('AlexBuilder');
  const u3 = generateOfflineUuid('OtherPlayer');
  assert.equal(u1.length, 32);
  assert.equal(u1, u2);
  assert.notEqual(u1, u3);
});

test('ElectronLauncherBackend persists settings, scans/toggles mods, and lists directories', () => {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'agretium-electron-test-'));
  const userData = path.join(tempRoot, 'userData');
  const mcPath = path.join(tempRoot, 'minecraft');
  fs.mkdirSync(path.join(mcPath, 'mods'), { recursive: true });

  const backend = new ElectronLauncherBackend(userData);
  const settings = {
    version: '1.8.9',
    account: 'AlexBuilder',
    optifine: true,
    beta: false,
    ram_mb: 3072,
    mc_path: mcPath,
    java_path: '',
    resolution: '1280x720',
    new_gc: true,
    minimize_on_launch: true,
  };
  backend.saveSettings(settings);
  assert.deepEqual(backend.loadSettings(), settings);

  fs.writeFileSync(path.join(mcPath, 'mods', 'argentum-1.0.2.jar'), 'stub');
  fs.writeFileSync(path.join(mcPath, 'mods', 'custom-pvp.jar'), 'stub');

  const modsInitial = scanModJars(mcPath);
  assert.equal(modsInitial.length, 2);
  assert.equal(modsInitial[0].isCoreArgentum, true);
  assert.equal(modsInitial[1].fileName, 'custom-pvp.jar');

  const toggled = backend.toggleModJar(mcPath, 'custom-pvp.jar', false);
  assert.equal(toggled.find((m) => m.baseName === 'custom-pvp.jar')?.enabled, false);

  const preflight = backend.checkOrnithePreflight(mcPath, '', true, true);
  assert.equal(preflight.needsDownload, true);
  assert.equal(preflight.checkedAt, 'electron');

  const listing = backend.listDirectory(tempRoot, mcPath);
  assert.equal(listing.currentPath, tempRoot);
  assert.ok(listing.entries.some((e) => e.name === 'minecraft'));

  fs.rmSync(tempRoot, { recursive: true, force: true });
});

test('normalizeJavaHomeInput and resolveJavaBin handle bin and executable paths', () => {
  assert.equal(normalizeJavaHomeInput('C:\\Program Files\\Java\\jdk-25\\bin'), 'C:\\Program Files\\Java\\jdk-25');
  assert.equal(
    normalizeJavaHomeInput('/opt/jdk-25/bin/java'),
    '/opt/jdk-25'
  );
  assert.equal(resolveJavaBin('/opt/jdk-25/bin', 'linux'), '/opt/jdk-25/bin/java');
});

test('buildJavaCompatFlags enables Java 25 compatibility flags and skips Java 8', () => {
  assert.deepEqual(buildJavaCompatFlags(8), []);
  const j25 = buildJavaCompatFlags(25);
  assert.ok(j25.includes('--add-opens=java.base/java.lang=ALL-UNNAMED'));
  assert.ok(j25.includes('--add-opens=java.base/java.io=ALL-UNNAMED'));
  assert.ok(j25.includes('--add-opens=java.desktop/sun.awt=ALL-UNNAMED'));
  assert.ok(j25.includes('--enable-native-access=ALL-UNNAMED'));
  assert.ok(j25.includes('--sun-misc-unsafe-memory-access=allow'));
});

test('checkOrnithePreflight flags missing library JARs even when version JSONs exist', () => {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'agretium-preflight-test-'));
  const backend = new ElectronLauncherBackend(path.join(tempRoot, 'userData'));
  const mcPath = path.join(tempRoot, 'minecraft');

  fs.mkdirSync(path.join(mcPath, 'versions', '1.8.9', 'natives'), { recursive: true });
  fs.mkdirSync(path.join(mcPath, 'versions', '1.8.9-ornithe'), { recursive: true });
  fs.mkdirSync(path.join(mcPath, 'assets', 'indexes'), { recursive: true });
  fs.writeFileSync(path.join(mcPath, 'versions', '1.8.9', '1.8.9.jar'), 'jar');
  fs.writeFileSync(path.join(mcPath, 'versions', '1.8.9', 'natives', 'lwjgl64.dll'), 'dll');
  fs.writeFileSync(
    path.join(mcPath, 'versions', '1.8.9', '1.8.9.json'),
    JSON.stringify({
      libraries: [
        { downloads: { artifact: { path: 'com/google/guava/guava/17.0/guava-17.0.jar' } } },
      ],
    })
  );
  fs.writeFileSync(path.join(mcPath, 'assets', 'indexes', '1.8.json'), '{}');

  const pf = backend.checkOrnithePreflight(mcPath, '', false, false);
  assert.equal(pf.jarOk, false);
  assert.equal(pf.needsDownload, true);

  fs.rmSync(tempRoot, { recursive: true, force: true });
});
