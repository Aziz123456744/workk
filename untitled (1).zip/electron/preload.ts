import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  platform: process.platform,
  invoke: <T = unknown>(channel: string, args?: Record<string, unknown>): Promise<T> => {
    return ipcRenderer.invoke(channel, args);
  },
  onUnexpectedExit: (
    callback: (payload: { code: number | null; message: string }) => void
  ): (() => void) => {
    const handler = (_event: Electron.IpcRendererEvent, payload: { code: number | null; message: string }) => {
      callback(payload);
    };
    ipcRenderer.on('minecraft_unexpected_exit', handler);
    return () => {
      ipcRenderer.removeListener('minecraft_unexpected_exit', handler);
    };
  },
});
