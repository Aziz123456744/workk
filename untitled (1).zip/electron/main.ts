import { app, BrowserWindow, dialog, ipcMain, shell } from 'electron';
import fs from 'node:fs';
import path from 'node:path';
import {
  ElectronLauncherBackend,
  type LauncherSettings,
  type OrnitheConfig,
} from './launcherCore';

// Enable hardware GPU rasterization & zero-copy compositing for crisp 60fps launcher rendering
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('ignore-gpu-blocklist');

let mainWindow: BrowserWindow | null = null;
let backend: ElectronLauncherBackend | null = null;

function getBackend(): ElectronLauncherBackend {
  if (!backend) {
    backend = new ElectronLauncherBackend(app.getPath('userData'));
  }
  return backend;
}

function createMainWindow(): void {
  const iconPath = app.isPackaged
    ? path.join(process.resourcesPath, 'icon.png')
    : path.join(process.cwd(), 'build', 'icon.png');

  mainWindow = new BrowserWindow({
    width: 1220,
    height: 780,
    minWidth: 960,
    minHeight: 640,
    title: 'Agretium 1.8.9 Launcher',
    backgroundColor: '#121316',
    frame: false,
    show: false,
    hasShadow: true,
    autoHideMenuBar: true,
    icon: fs.existsSync(iconPath) ? iconPath : undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      v8CacheOptions: 'code',
    },
  });

  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
  });

  if (!app.isPackaged && process.env.ELECTRON_START_URL) {
    void mainWindow.loadURL(process.env.ELECTRON_START_URL);
  } else if (!app.isPackaged) {
    const devDist = path.join(__dirname, '..', 'dist', 'index.html');
    if (fs.existsSync(devDist)) {
      void mainWindow.loadFile(devDist);
    } else {
      void mainWindow.loadURL('http://localhost:3000');
    }
  } else {
    void mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function registerIpcHandlers(): void {
  ipcMain.handle('window_minimize', () => {
    mainWindow?.minimize();
  });
  ipcMain.handle('window_toggle_maximize', () => {
    if (!mainWindow) return false;
    if (mainWindow.isMaximized()) {
      mainWindow.unmaximize();
      return false;
    }
    mainWindow.maximize();
    return true;
  });
  ipcMain.handle('window_close', () => {
    mainWindow?.close();
  });
  ipcMain.handle('get_system_info', () => getBackend().getSystemInfo());
  ipcMain.handle('get_default_paths', () => getBackend().getDefaultPaths());
  ipcMain.handle('load_settings', () => getBackend().loadSettings());
  ipcMain.handle('save_settings', (_event, args: { settings: LauncherSettings }) => {
    getBackend().saveSettings(args.settings);
    return { ok: true };
  });
  ipcMain.handle('load_extras', () => getBackend().loadExtras());
  ipcMain.handle('save_extras', (_event, args: { extras: unknown }) => {
    getBackend().saveExtras(args.extras);
    return { ok: true };
  });
  ipcMain.handle('load_launch_history', () => getBackend().loadLaunchHistory());

  const showOpenDialogSafe = (options: Electron.OpenDialogOptions) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      return dialog.showOpenDialog(mainWindow, options);
    }
    return dialog.showOpenDialog(options);
  };

  ipcMain.handle('pick_folder', async () => {
    const result = await showOpenDialogSafe({
      properties: ['openDirectory'],
    });
    if (result.canceled || result.filePaths.length === 0) return null;
    return result.filePaths[0];
  });

  ipcMain.handle(
    'list_directory',
    (_event, args: { dirPath?: string | null; mcPath?: string | null }) => {
      return getBackend().listDirectory(args?.dirPath, args?.mcPath);
    }
  );

  ipcMain.handle('list_mod_jars', (_event, args: { mcPath: string }) => {
    return getBackend().listModJars(args.mcPath);
  });

  ipcMain.handle('add_mod_jars', async (_event, args: { mcPath: string }) => {
    const result = await showOpenDialogSafe({
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Minecraft Mod JAR', extensions: ['jar'] }],
    });
    if (result.canceled || result.filePaths.length === 0) {
      return getBackend().listModJars(args.mcPath);
    }
    return getBackend().copyModJars(args.mcPath, result.filePaths);
  });

  ipcMain.handle(
    'toggle_mod_jar',
    (_event, args: { mcPath: string; fileName: string; enabled: boolean }) => {
      return getBackend().toggleModJar(args.mcPath, args.fileName, args.enabled);
    }
  );

  ipcMain.handle('delete_mod_jar', (_event, args: { mcPath: string; fileName: string }) => {
    return getBackend().deleteModJar(args.mcPath, args.fileName);
  });

  ipcMain.handle('open_mods_folder', async (_event, args: { mcPath: string }) => {
    const modsDir = path.join(args.mcPath, 'mods');
    fs.mkdirSync(modsDir, { recursive: true });
    await shell.openPath(modsDir);
  });

  ipcMain.handle(
    'check_ornithe_preflight',
    (
      _event,
      args: {
        mcPath: string;
        javaPath: string;
        ornitheEnabled: boolean;
        agretiumEnabled: boolean;
      }
    ) => {
      return getBackend().checkOrnithePreflight(
        args.mcPath,
        args.javaPath,
        args.ornitheEnabled,
        args.agretiumEnabled
      );
    }
  );

  ipcMain.handle(
    'download_ornithe_and_mods',
    (
      _event,
      args: {
        mcPath: string;
        ornithe: OrnitheConfig;
        includeArgentum: boolean;
      }
    ) => {
      return getBackend().downloadOrnitheAndMods(
        args.mcPath,
        args.ornithe,
        args.includeArgentum
      );
    }
  );

  ipcMain.handle('get_download_status', () => getBackend().getDownloadStatus());

  ipcMain.handle('reset_version_cache', (_event, args: { mcPath: string }) => {
    return getBackend().resetVersionCache(args.mcPath);
  });

  ipcMain.handle(
    'launch_minecraft',
    async (
      _event,
      args: {
        settings: LauncherSettings;
        ornithe?: OrnitheConfig | null;
        serverAddress?: string | null;
        enabledMods?: string[] | null;
      }
    ) => {
      return getBackend().launchMinecraft(
        args.settings,
        args.ornithe,
        args.serverAddress,
        args.enabledMods,
        () => {
          mainWindow?.minimize();
        },
        (code, message) => {
          if (mainWindow && !mainWindow.isDestroyed()) {
            if (mainWindow.isMinimized()) mainWindow.restore();
            mainWindow.show();
            mainWindow.focus();
            mainWindow.webContents.send('minecraft_unexpected_exit', { code, message });
          }
        }
      );
    }
  );

  ipcMain.handle('get_jvm_status', () => getBackend().getJvmStatus());
  ipcMain.handle('trigger_jvm_gc', () => getBackend().triggerJvmGc());
  ipcMain.handle('stop_jvm_session', () => getBackend().stopJvmSession());
}

app.whenReady().then(() => {
  registerIpcHandlers();
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
