import AdmZip from 'adm-zip';
import { execFileSync, spawn, spawnSync, type ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export interface LauncherSettings {
  version: string;
  account: string;
  optifine: boolean;
  beta: boolean;
  ram_mb: number;
  mc_path: string;
  java_path: string;
  resolution: string;
  new_gc: boolean;
  minimize_on_launch: boolean;
}

export interface OrnitheConfig {
  enabled: boolean;
  loaderVersion: string;
  calamusVersion: string;
}

export interface PreflightStatus {
  javaOk: boolean;
  jarOk: boolean;
  assetsOk: boolean;
  ornitheOk: boolean;
  argentumOk: boolean;
  needsDownload: boolean;
  missingArtifacts: string[];
  javaBin: string;
  clientJar: string;
  checkedAt: string;
}

export interface DownloadArtifact {
  id: string;
  label: string;
  fileName: string;
  sizeLabel: string;
  status: 'pending' | 'downloading' | 'done';
  group: 'client' | 'ornithe' | 'argentum';
}

export interface VersionDownloadStatus {
  state: 'idle' | 'downloading' | 'complete' | 'error';
  percent: number;
  currentArtifact: string | null;
  completedCount: number;
  totalCount: number;
  artifacts: DownloadArtifact[];
  error?: string;
}

export interface ModJarFile {
  fileName: string;
  baseName: string;
  displayName: string;
  enabled: boolean;
  sizeBytes: number;
  isCoreArgentum: boolean;
}

export interface LaunchHistoryEntry {
  id: string;
  timestamp: string;
  version: string;
  account: string;
  ram_mb: number;
  optifine: boolean;
  resolution: string;
  command: string;
  status: 'launched' | 'failed';
  message: string;
  serverAddress?: string;
  launchDurationMs?: number;
}

export interface LaunchResponse {
  ok: boolean;
  message: string;
  command: string;
  args: string[];
  javaBin: string;
  clientJar: string;
  minimized: boolean;
  historyEntry: LaunchHistoryEntry;
}

export interface JvmLogEntry {
  id: string;
  time: string;
  level: 'INFO' | 'WARN' | 'DEBUG';
  thread: string;
  message: string;
}

export interface JvmStatusSnapshot {
  running: boolean;
  pid: number | null;
  version: string;
  xmx_mb: number;
  xms_mb: number;
  allocated_mb: number;
  used_mb: number;
  gc_algorithm: string;
  xmx_flag: string;
  xmx_verified: boolean;
  host_total_ram_mb: number;
  host_free_ram_mb: number;
  uptime_seconds: number;
  gc_collections: number;
  timestamp: string;
  logs: JvmLogEntry[];
}

export interface DirectoryEntry {
  name: string;
  path: string;
  isDirectory: boolean;
  hint?: string;
}

export interface DirectoryListing {
  currentPath: string;
  parentPath: string | null;
  entries: DirectoryEntry[];
  presets: Array<{ label: string; path: string; description: string }>;
}

const MOJANG_MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const MOJANG_189_FALLBACK_URL =
  'https://piston-meta.mojang.com/v1/packages/d546f1707a3f2b7d034eece5ea2e311eda875787/1.8.9.json';

export const DEFAULT_ORNITHE_CONFIG: OrnitheConfig = {
  enabled: true,
  loaderVersion: '0.20.1',
  calamusVersion: '1.8.9',
};

export interface ArgentumJarSpec {
  id: string;
  fileName: string;
  url: string;
}

export function getArgentumJars(mcPath: string): Array<ArgentumJarSpec & { path: string }> {
  const modsDir = path.join(mcPath, 'mods');
  const specs: ArgentumJarSpec[] = [
    {
      id: 'argentum-core',
      fileName: 'argentum-1.0.2.jar',
      url: 'https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/argentum-1.0.2.jar',
    },
    {
      id: 'argentum-extras',
      fileName: 'argentum-extras-1.0.2.jar',
      url: 'https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/argentum-extras-1.0.2.jar',
    },
    {
      id: 'cera',
      fileName: 'cera-1.0.2.jar',
      url: 'https://github.com/QuicksilverMC/Argentum/releases/download/v1.0.2/cera-1.0.2.jar',
    },
    {
      id: 'osl',
      fileName: 'ornithe-standard-libraries-0.24.0.jar',
      url: 'https://cdn.modrinth.com/data/EHGtwpJv/versions/TzBDamVN/ornithe-standard-libraries-0.24.0.jar',
    },
    {
      id: 'pylon',
      fileName: 'pylon-0.2.2-beta.1.jar',
      url: 'https://github.com/Polyfrost/pylon/releases/download/0.2.2-beta.1/pylon-0.2.2-beta.1.jar',
    },
    {
      id: 'forgecompat',
      fileName: 'forgecompat-1.1.4+1.8.9.jar',
      url: 'https://github.com/Polyfrost/ForgeCompat/releases/download/v1.1.4/forgecompat-1.1.4%2B1.8.9.jar',
    },
  ];
  return specs.map((s) => ({ ...s, path: path.join(modsDir, s.fileName) }));
}

const CORE_ARGENTUM_NAMES = new Set([
  'argentum-1.0.2.jar',
  'argentum-extras-1.0.2.jar',
  'cera-1.0.2.jar',
  'ornithe-standard-libraries-0.24.0.jar',
  'pylon-0.2.2-beta.1.jar',
  'forgecompat-1.1.4+1.8.9.jar',
]);

export function currentMojangOsName(platform: NodeJS.Platform = process.platform): 'windows' | 'osx' | 'linux' {
  if (platform === 'win32') return 'windows';
  if (platform === 'darwin') return 'osx';
  return 'linux';
}

export function isLibraryAllowedForOs(
  lib: { rules?: Array<{ action?: string; os?: { name?: string } }> },
  platform: NodeJS.Platform = process.platform
): boolean {
  if (!Array.isArray(lib.rules) || lib.rules.length === 0) {
    return true;
  }
  const osName = currentMojangOsName(platform);
  let allowed = false;
  for (const rule of lib.rules) {
    const matches = !rule.os?.name || rule.os.name === osName;
    if (matches) {
      allowed = rule.action === 'allow';
    }
  }
  return allowed;
}

export function mavenCoordToRelPath(coord: string): string | null {
  const parts = coord.split(':');
  if (parts.length < 3) return null;
  const [group, artifact, version] = parts;
  const classifier = parts[3];
  const groupPath = group.split('.').join('/');
  const jarName = classifier
    ? `${artifact}-${version}-${classifier}.jar`
    : `${artifact}-${version}.jar`;
  return `${groupPath}/${artifact}/${version}/${jarName}`;
}

export function mavenGroupArtifactKey(coord: string): string | null {
  const parts = coord.split(':');
  if (parts.length < 2) return null;
  return `${parts[0]}:${parts[1]}`;
}

export function parseJavaMajorFromVersionOutput(text: string): number | null {
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/"([^"]+)"/);
    if (!match) continue;
    const ver = match[1];
    if (ver.startsWith('1.')) {
      const major = Number.parseInt(ver.slice(2).split('.')[0] ?? '', 10);
      if (Number.isFinite(major)) return major;
    } else {
      const major = Number.parseInt(ver.split(/[^0-9]/)[0] ?? '', 10);
      if (Number.isFinite(major)) return major;
    }
  }
  return null;
}

export function generateOfflineUuid(username: string): string {
  let h1 = 0x811c9dc5 >>> 0;
  let h2 = 0xdeadbeef >>> 0;
  for (let i = 0; i < username.length; i += 1) {
    const code = username.charCodeAt(i) & 0xff;
    h1 = Math.imul(h1 ^ code, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ ((code + i) >>> 0), 0x85ebca6b) >>> 0;
  }
  const hex = (val: number, len: number) => (val >>> 0).toString(16).padStart(len, '0');
  return `${hex(h1, 8)}${hex((h2 >>> 16) & 0xffff, 4)}3${hex(h2 & 0x0fff, 3)}8${hex(
    (h1 ^ h2) & 0x0fff,
    3
  )}${hex(h1, 8)}${hex(h2 & 0xffff, 4)}`;
}

export function defaultMcDir(platform: NodeJS.Platform = process.platform): string {
  if (platform === 'win32') {
    const appdata = process.env.APPDATA;
    if (appdata) return path.join(appdata, '.minecraft');
    return path.join(os.homedir(), 'AppData', 'Roaming', '.minecraft');
  }
  if (platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'minecraft');
  }
  return path.join(os.homedir(), '.minecraft');
}

export function managedJava25Dir(mcPath: string): string {
  return path.join(mcPath, 'runtime', 'java-25');
}

export function normalizeJavaHomeInput(javaPath: string): string {
  const trimmed = javaPath.trim().replace(/[\\/]+$/, '');
  if (!trimmed) return trimmed;
  const matchExec = trimmed.match(/^(.*?)(?:[\\/]bin)?[\\/](?:javaw?\.exe|javaw?)$/i);
  if (matchExec && matchExec[1]) {
    return matchExec[1];
  }
  const matchBin = trimmed.match(/^(.*)[\\/]bin$/i);
  if (matchBin && matchBin[1]) {
    return matchBin[1];
  }
  return trimmed;
}

export function resolveJavaBin(javaPath: string, platform: NodeJS.Platform = process.platform): string {
  const home = normalizeJavaHomeInput(javaPath);
  if (platform === 'win32') {
    const javaw = path.join(home, 'bin', 'javaw.exe');
    if (fs.existsSync(javaw)) return javaw;
    const javaExe = path.join(home, 'bin', 'java.exe');
    if (fs.existsSync(javaExe)) return javaExe;
    return javaw;
  }
  return path.join(home, 'bin', 'java');
}

export function resolveJavaCliBin(javaPath: string, platform: NodeJS.Platform = process.platform): string {
  const home = normalizeJavaHomeInput(javaPath);
  if (platform === 'win32') {
    return path.join(home, 'bin', 'java.exe');
  }
  return path.join(home, 'bin', 'java');
}

export function buildJavaCompatFlags(javaMajor: number | null): string[] {
  if (!javaMajor || javaMajor < 9) {
    return [];
  }
  const flags = [
    '--add-opens=java.base/java.lang=ALL-UNNAMED',
    '--add-opens=java.base/java.lang.reflect=ALL-UNNAMED',
    '--add-opens=java.base/java.lang.invoke=ALL-UNNAMED',
    '--add-opens=java.base/java.util=ALL-UNNAMED',
    '--add-opens=java.base/java.util.concurrent=ALL-UNNAMED',
    '--add-opens=java.base/java.net=ALL-UNNAMED',
    '--add-opens=java.base/java.io=ALL-UNNAMED',
    '--add-opens=java.base/java.nio=ALL-UNNAMED',
    '--add-opens=java.desktop/java.awt=ALL-UNNAMED',
    '--add-opens=java.desktop/sun.awt=ALL-UNNAMED',
  ];
  if (javaMajor >= 24) {
    flags.push(
      '--enable-native-access=ALL-UNNAMED',
      '--sun-misc-unsafe-memory-access=allow'
    );
  }
  return flags;
}

export function parseJavaMajorFromReleaseFile(javaPath: string): number | null {
  try {
    const home = normalizeJavaHomeInput(javaPath);
    const releasePath = path.join(home, 'release');
    if (!fs.existsSync(releasePath)) return null;
    const content = fs.readFileSync(releasePath, 'utf8');
    const match = content.match(/^JAVA_VERSION="([^"]+)"/m);
    if (!match?.[1]) return null;
    return parseJavaMajorFromVersionOutput(`openjdk version "${match[1]}"`);
  } catch {
    return null;
  }
}

export function parseJavaMajor(javaPath: string): number | null {
  const fromRelease = parseJavaMajorFromReleaseFile(javaPath);
  if (fromRelease !== null) return fromRelease;
  const cli = resolveJavaCliBin(javaPath);
  if (!fs.existsSync(cli)) return null;
  try {
    execFileSync(cli, ['-version'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    return null;
  } catch (err) {
    // java -version typically writes to stderr; execFileSync throws only on non-zero exit
    const anyErr = err as { stderr?: string; stdout?: string };
    const text = `${anyErr?.stdout ?? ''}\n${anyErr?.stderr ?? ''}`;
    return parseJavaMajorFromVersionOutput(text);
  }
}

export function getJavaMajorSafe(javaPath: string): number | null {
  const fromRelease = parseJavaMajorFromReleaseFile(javaPath);
  if (fromRelease !== null) return fromRelease;
  const cli = resolveJavaCliBin(javaPath);
  if (!fs.existsSync(cli)) return null;
  try {
    const res = spawnSync(cli, ['-version'], {
      encoding: 'utf8',
      timeout: 12000,
    });
    const combined = `${res.stdout ?? ''}\n${res.stderr ?? ''}`;
    return parseJavaMajorFromVersionOutput(combined);
  } catch {
    return null;
  }
}

export function detectJavaInstallations(
  mcPath: string
): Array<{ label: string; dir: string; major: number | null }> {
  const candidates: string[] = [managedJava25Dir(mcPath)];
  if (process.env.JAVA_HOME) {
    candidates.push(process.env.JAVA_HOME);
  }

  const roots =
    process.platform === 'win32'
      ? (() => {
          const pf = process.env.ProgramFiles || 'C:\\Program Files';
          const pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
          const localApp = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
          return [
            path.join(pf, 'Eclipse Adoptium'),
            path.join(localApp, 'Programs', 'Eclipse Adoptium'),
            path.join(pf, 'Java'),
            path.join(pf86, 'Java'),
            path.join(pf, 'Zulu'),
            path.join(pf, 'Microsoft'),
            path.join(pf, 'BellSoft'),
            path.join(pf, 'AdoptOpenJDK'),
            path.join(os.homedir(), '.jdks'),
          ];
        })()
      : ['/usr/lib/jvm', '/Library/Java/JavaVirtualMachines', path.join(os.homedir(), '.jdks')];

  for (const root of roots) {
    try {
      if (!fs.existsSync(root)) continue;
      for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
        if (!entry.isDirectory()) continue;
        const full = path.join(root, entry.name);
        const macHome = path.join(full, 'Contents', 'Home');
        candidates.push(fs.existsSync(macHome) ? macHome : full);
      }
    } catch {
      // Ignore unreadable directories
    }
  }

  const seen = new Set<string>();
  const found: Array<{ label: string; dir: string; major: number | null }> = [];
  for (const dir of candidates) {
    if (!dir || seen.has(dir)) continue;
    seen.add(dir);
    if (fs.existsSync(resolveJavaBin(dir))) {
      const major = getJavaMajorSafe(dir);
      const base = path.basename(dir) || 'JRE';
      const label = major ? `Java ${major} (${base})` : `Java Runtime (${base})`;
      found.push({ label, dir, major });
    }
  }
  found.sort((a, b) => (b.major ?? 0) - (a.major ?? 0));
  return found;
}

export function effectiveJavaPath(
  configuredJavaPath: string,
  mcPath: string,
  requireJava25: boolean
): string {
  const trimmed = configuredJavaPath.trim();
  const configuredValid = trimmed.length > 0 && fs.existsSync(resolveJavaBin(trimmed));
  if (configuredValid) {
    if (!requireJava25) return trimmed;
    const major = getJavaMajorSafe(trimmed);
    if (major !== null && major >= 25) return trimmed;
  }
  const managed = managedJava25Dir(mcPath);
  if (fs.existsSync(resolveJavaBin(managed))) {
    return managed;
  }
  const detected = detectJavaInstallations(mcPath);
  if (requireJava25) {
    const j25 = detected.find((d) => (d.major ?? 0) >= 25);
    if (j25) return j25.dir;
  }
  if (detected.length > 0) return detected[0].dir;
  if (configuredValid) return trimmed;
  return requireJava25 ? managed : trimmed;
}

export function ornitheLoaderJar(mcPath: string, loaderVersion: string): string {
  return path.join(
    mcPath,
    'libraries',
    'net',
    'fabricmc',
    'fabric-loader',
    loaderVersion,
    `fabric-loader-${loaderVersion}.jar`
  );
}

export function calamusJar(mcPath: string, calamusVersion: string): string {
  return path.join(
    mcPath,
    'libraries',
    'net',
    'ornithemc',
    'calamus-intermediary-gen2',
    calamusVersion,
    `calamus-intermediary-gen2-${calamusVersion}.jar`
  );
}

export function hasNativesFiles(mcPath: string): boolean {
  const nativesDir = path.join(mcPath, 'versions', '1.8.9', 'natives');
  try {
    if (!fs.existsSync(nativesDir)) return false;
    const entries = fs.readdirSync(nativesDir, { withFileTypes: true });
    return entries.some((e) => e.isFile() && /\.(dll|so|dylib|jnilib)$/i.test(e.name));
  } catch {
    return false;
  }
}

export function scanModJars(mcPath: string): ModJarFile[] {
  const modsDir = path.join(mcPath, 'mods');
  try {
    fs.mkdirSync(modsDir, { recursive: true });
  } catch {
    // ignore
  }
  const items: ModJarFile[] = [];
  try {
    for (const entry of fs.readdirSync(modsDir, { withFileTypes: true })) {
      if (!entry.isFile()) continue;
      const fileName = entry.name;
      const lower = fileName.toLowerCase();
      const isDisabled = lower.endsWith('.jar.disabled');
      const isEnabled = !isDisabled && lower.endsWith('.jar');
      if (!isDisabled && !isEnabled) continue;

      const baseName = isDisabled ? fileName.slice(0, -'.disabled'.length) : fileName;
      const displayName = baseName.slice(0, -'.jar'.length);
      let sizeBytes = 0;
      try {
        sizeBytes = fs.statSync(path.join(modsDir, fileName)).size;
      } catch {
        sizeBytes = 0;
      }
      items.push({
        fileName,
        baseName,
        displayName,
        enabled: isEnabled,
        sizeBytes,
        isCoreArgentum: CORE_ARGENTUM_NAMES.has(baseName.toLowerCase()),
      });
    }
  } catch {
    return [];
  }
  items.sort((a, b) => {
    if (a.isCoreArgentum !== b.isCoreArgentum) {
      return a.isCoreArgentum ? -1 : 1;
    }
    return a.baseName.toLowerCase().localeCompare(b.baseName.toLowerCase());
  });
  return items;
}

function formatClockHms(date = new Date()): string {
  return date.toTimeString().slice(0, 8);
}

export class ElectronLauncherBackend {
  private readonly userDataDir: string;
  private activeChild: ChildProcess | null = null;
  private activePid: number | null = null;
  private startedAtMs = 0;
  private xmxMb = 3072;
  private xmsMb = 512;
  private newGc = true;
  private gcCollections = 0;
  private jvmLogs: JvmLogEntry[] = [];
  private downloadState: VersionDownloadStatus | null = null;

  constructor(userDataDir: string) {
    this.userDataDir = userDataDir;
    fs.mkdirSync(this.userDataDir, { recursive: true });
  }

  private configFilePath(): string {
    return path.join(this.userDataDir, 'launcher_config.json');
  }

  private extrasFilePath(): string {
    return path.join(this.userDataDir, 'launcher_extras.json');
  }

  private historyFilePath(): string {
    return path.join(this.userDataDir, 'launch_history.json');
  }

  private pushJvmLog(level: JvmLogEntry['level'], thread: string, message: string): void {
    this.jvmLogs = [
      ...this.jvmLogs,
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        time: formatClockHms(),
        level,
        thread,
        message,
      },
    ].slice(-80);
  }

  getSystemInfo(): { total_ram_mb: number } {
    const totalMb = Math.max(4096, Math.floor(os.totalmem() / (1024 * 1024)));
    return { total_ram_mb: totalMb };
  }

  getDefaultPaths(): { mc_path: string; java_path: string; config_path: string } {
    const mcPath = defaultMcDir();
    const detected = detectJavaInstallations(mcPath);
    const java25 = detected.find((d) => (d.major ?? 0) >= 25);
    const javaPath = java25?.dir ?? detected[0]?.dir ?? managedJava25Dir(mcPath);
    return {
      mc_path: mcPath,
      java_path: javaPath,
      config_path: this.configFilePath(),
    };
  }

  loadSettings(): LauncherSettings | null {
    const p = this.configFilePath();
    if (!fs.existsSync(p)) return null;
    try {
      return JSON.parse(fs.readFileSync(p, 'utf8')) as LauncherSettings;
    } catch {
      return null;
    }
  }

  saveSettings(settings: LauncherSettings): void {
    fs.mkdirSync(this.userDataDir, { recursive: true });
    fs.writeFileSync(this.configFilePath(), JSON.stringify(settings, null, 2), 'utf8');
  }

  loadExtras(): unknown | null {
    const p = this.extrasFilePath();
    if (!fs.existsSync(p)) return null;
    try {
      return JSON.parse(fs.readFileSync(p, 'utf8'));
    } catch {
      return null;
    }
  }

  saveExtras(extras: unknown): void {
    fs.mkdirSync(this.userDataDir, { recursive: true });
    fs.writeFileSync(this.extrasFilePath(), JSON.stringify(extras, null, 2), 'utf8');
  }

  loadLaunchHistory(): LaunchHistoryEntry[] {
    const p = this.historyFilePath();
    if (!fs.existsSync(p)) return [];
    try {
      const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
      return Array.isArray(parsed) ? (parsed as LaunchHistoryEntry[]) : [];
    } catch {
      return [];
    }
  }

  private appendHistoryEntry(entry: LaunchHistoryEntry): void {
    const current = this.loadLaunchHistory();
    const next = [entry, ...current].slice(0, 20);
    fs.writeFileSync(this.historyFilePath(), JSON.stringify(next, null, 2), 'utf8');
  }

  listDirectory(dirPath?: string | null, mcPath?: string | null): DirectoryListing {
    const defaultMc = mcPath && mcPath.trim() ? mcPath : defaultMcDir();
    const candidate = dirPath && dirPath.trim() ? dirPath : defaultMc;
    const resolved =
      fs.existsSync(candidate) && fs.statSync(candidate).isDirectory()
        ? candidate
        : fs.existsSync(os.homedir())
        ? os.homedir()
        : process.cwd();

    const presets: DirectoryListing['presets'] = [
      {
        label: 'Minecraft Home (.minecraft)',
        path: defaultMc,
        description: 'Standard Minecraft 1.8.9 game & mods directory',
      },
    ];
    for (const java of detectJavaInstallations(defaultMc).slice(0, 3)) {
      presets.push({
        label: java.label,
        path: java.dir,
        description: 'Detected Java Runtime',
      });
    }

    const entries: DirectoryEntry[] = [];
    try {
      for (const item of fs.readdirSync(resolved, { withFileTypes: true })) {
        if (!item.isDirectory()) continue;
        if (item.name.startsWith('.') && item.name !== '.minecraft') continue;
        const full = path.join(resolved, item.name);
        let hint: string | undefined;
        if (fs.existsSync(resolveJavaBin(full))) {
          hint = 'Java Runtime';
        } else if (
          fs.existsSync(path.join(full, 'versions')) ||
          fs.existsSync(path.join(full, 'mods'))
        ) {
          hint = 'Minecraft Directory';
        }
        entries.push({
          name: item.name,
          path: full,
          isDirectory: true,
          hint,
        });
      }
    } catch {
      // Ignore permission errors
    }

    entries.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
    const parentRaw = path.dirname(resolved);
    const parentPath = parentRaw && parentRaw !== resolved ? parentRaw : null;
    return {
      currentPath: resolved,
      parentPath,
      entries: entries.slice(0, 80),
      presets,
    };
  }

  listModJars(mcPath: string): ModJarFile[] {
    return scanModJars(mcPath);
  }

  copyModJars(mcPath: string, sourceFilePaths: string[]): ModJarFile[] {
    const modsDir = path.join(mcPath, 'mods');
    fs.mkdirSync(modsDir, { recursive: true });
    for (const src of sourceFilePaths) {
      const fname = path.basename(src);
      if (!fname.toLowerCase().endsWith('.jar')) continue;
      fs.copyFileSync(src, path.join(modsDir, fname));
    }
    return scanModJars(mcPath);
  }

  toggleModJar(mcPath: string, fileName: string, enabled: boolean): ModJarFile[] {
    const modsDir = path.join(mcPath, 'mods');
    const cleanName = path.basename(fileName);
    const src = path.join(modsDir, cleanName);
    if (!fs.existsSync(src)) {
      throw new Error(`Mod file not found: ${cleanName}`);
    }
    const base = cleanName.endsWith('.disabled')
      ? cleanName.slice(0, -'.disabled'.length)
      : cleanName;
    const nextName = enabled ? base : `${base}.disabled`;
    const dest = path.join(modsDir, nextName);
    if (src !== dest) {
      fs.renameSync(src, dest);
    }
    return scanModJars(mcPath);
  }

  deleteModJar(mcPath: string, fileName: string): ModJarFile[] {
    const modsDir = path.join(mcPath, 'mods');
    const cleanName = path.basename(fileName);
    const target = path.join(modsDir, cleanName);
    if (fs.existsSync(target)) {
      fs.unlinkSync(target);
    }
    return scanModJars(mcPath);
  }

  private areMojangLibrariesPresent(mcPath: string, clientJsonPath: string): boolean {
    if (!fs.existsSync(clientJsonPath)) return false;
    try {
      const json = JSON.parse(fs.readFileSync(clientJsonPath, 'utf8')) as {
        libraries?: Array<{
          rules?: Array<{ action?: string; os?: { name?: string } }>;
          natives?: Record<string, string>;
          downloads?: { artifact?: { path?: string } };
        }>;
      };
      for (const lib of json.libraries ?? []) {
        if (!isLibraryAllowedForOs(lib)) continue;
        const rel = lib.downloads?.artifact?.path;
        if (!rel) continue;
        const jar = path.join(mcPath, 'libraries', rel);
        if (!fs.existsSync(jar) || fs.statSync(jar).size === 0) {
          return false;
        }
      }
      return true;
    } catch {
      return false;
    }
  }

  private areOrnitheLibrariesPresent(
    mcPath: string,
    profilePath: string,
    loaderVersion: string = DEFAULT_ORNITHE_CONFIG.loaderVersion
  ): boolean {
    if (!fs.existsSync(profilePath)) return false;
    try {
      const json = JSON.parse(fs.readFileSync(profilePath, 'utf8')) as {
        libraries?: Array<{ name?: string }>;
      };
      if (!Array.isArray(json.libraries) || json.libraries.length === 0) return false;
      const names = json.libraries.map((l) => l.name ?? '');
      const hasLoader = names.includes(`net.fabricmc:fabric-loader:${loaderVersion}`);
      const hasMixin = names.some((n) => n.startsWith('net.fabricmc:sponge-mixin:'));
      if (!hasLoader || !hasMixin) return false;
      for (const lib of json.libraries) {
        if (!lib.name) continue;
        const rel = mavenCoordToRelPath(lib.name);
        if (!rel) continue;
        const jar = path.join(mcPath, 'libraries', rel);
        if (!fs.existsSync(jar) || fs.statSync(jar).size === 0) {
          return false;
        }
      }
      return true;
    } catch {
      return false;
    }
  }

  checkOrnithePreflight(
    mcPath: string,
    javaPath: string,
    ornitheEnabled: boolean,
    agretiumEnabled: boolean
  ): PreflightStatus {
    const cfg = DEFAULT_ORNITHE_CONFIG;
    const effJava = effectiveJavaPath(javaPath, mcPath, agretiumEnabled);
    const javaBin = resolveJavaBin(effJava);
    const javaMajor = getJavaMajorSafe(effJava) ?? 0;

    const clientJar = path.join(mcPath, 'versions', '1.8.9', '1.8.9.jar');
    const clientJson = path.join(mcPath, 'versions', '1.8.9', '1.8.9.json');
    const assetsIndex = path.join(mcPath, 'assets', 'indexes', '1.8.json');
    const loader = ornitheLoaderJar(mcPath, cfg.loaderVersion);
    const calamus = calamusJar(mcPath, cfg.calamusVersion);
    const profile = path.join(mcPath, 'versions', '1.8.9-ornithe', '1.8.9-ornithe.json');

    const nativesOk = hasNativesFiles(mcPath);
    const mojangLibsOk = this.areMojangLibrariesPresent(mcPath, clientJson);
    const ornitheLibsOk = !ornitheEnabled || this.areOrnitheLibrariesPresent(mcPath, profile, cfg.loaderVersion);
    const javaOk = fs.existsSync(javaBin) && (!agretiumEnabled || javaMajor >= 25);
    const jarOk =
      fs.existsSync(clientJar) &&
      fs.statSync(clientJar).size > 0 &&
      fs.existsSync(clientJson) &&
      nativesOk &&
      mojangLibsOk;
    const assetsOk = fs.existsSync(assetsIndex);
    const ornitheOk =
      !ornitheEnabled ||
      (fs.existsSync(loader) &&
        fs.existsSync(calamus) &&
        fs.existsSync(profile) &&
        ornitheLibsOk);

    const argMissing = getArgentumJars(mcPath).filter(
      (item) => !fs.existsSync(item.path) || fs.statSync(item.path).size === 0
    );
    const argentumOk = !agretiumEnabled || argMissing.length === 0;

    const missingArtifacts: string[] = [];
    if (!javaOk) {
      missingArtifacts.push(
        agretiumEnabled
          ? 'Eclipse Temurin Java 25 Runtime (Required for Argentum/ForgeCompat)'
          : 'Java Runtime'
      );
    }
    if (!fs.existsSync(clientJar) || !fs.existsSync(clientJson)) {
      missingArtifacts.push('Minecraft 1.8.9 Client JAR & Manifest');
    }
    if (!nativesOk || !mojangLibsOk) {
      missingArtifacts.push('Minecraft 1.8.9 Libraries & LWJGL Natives');
    }
    if (!assetsOk) {
      missingArtifacts.push('1.8 Asset Index & Sound Resources');
    }
    if (ornitheEnabled) {
      if (!fs.existsSync(loader)) {
        missingArtifacts.push(`Ornithe Fabric Loader ${cfg.loaderVersion}`);
      }
      if (!fs.existsSync(calamus)) {
        missingArtifacts.push(`Ornithe Calamus Gen2 Mappings ${cfg.calamusVersion}`);
      }
      if (!fs.existsSync(profile) || !ornitheLibsOk) {
        missingArtifacts.push('1.8.9-ornithe Launch Profile & Libraries');
      }
    }
    if (agretiumEnabled) {
      for (const item of argMissing) {
        missingArtifacts.push(item.fileName);
      }
    }

    return {
      javaOk,
      jarOk,
      assetsOk,
      ornitheOk,
      argentumOk,
      needsDownload: missingArtifacts.length > 0,
      missingArtifacts,
      javaBin,
      clientJar,
      checkedAt: 'electron',
    };
  }

  getDownloadStatus(): VersionDownloadStatus {
    return (
      this.downloadState ?? {
        state: 'idle',
        percent: 0,
        currentArtifact: null,
        completedCount: 0,
        totalCount: 0,
        artifacts: [],
      }
    );
  }

  resetVersionCache(mcPath: string): PreflightStatus {
    fs.rmSync(path.join(mcPath, 'versions', '1.8.9'), { recursive: true, force: true });
    fs.rmSync(path.join(mcPath, 'versions', '1.8.9-ornithe'), { recursive: true, force: true });
    fs.rmSync(path.join(mcPath, 'libraries'), { recursive: true, force: true });
    fs.rmSync(path.join(mcPath, 'assets', 'indexes', '1.8.json'), { force: true });
    for (const item of getArgentumJars(mcPath)) {
      fs.rmSync(item.path, { force: true });
    }
    this.downloadState = null;
    return this.checkOrnithePreflight(mcPath, '', true, true);
  }

  private async downloadBuffer(url: string, timeoutMs = 60_000, attempts = 3): Promise<Buffer> {
    let lastError: Error | null = null;
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      try {
        const res = await fetch(url, {
          headers: { 'User-Agent': 'Agretium-1.8.9-Launcher/1.0' },
          redirect: 'follow',
          signal: AbortSignal.timeout(timeoutMs),
        });
        if (!res.ok) {
          throw new Error(`HTTP ${res.status} fetching ${url}`);
        }
        return Buffer.from(await res.arrayBuffer());
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
        if (attempt < attempts) {
          await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
        }
      }
    }
    throw lastError ?? new Error(`Failed to fetch ${url}`);
  }

  private async downloadIfMissing(url: string, targetPath: string, timeoutMs = 60_000): Promise<void> {
    if (fs.existsSync(targetPath) && fs.statSync(targetPath).size > 0) return;
    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    const data = await this.downloadBuffer(url, timeoutMs);
    const tmpPath = `${targetPath}.part-${Date.now()}`;
    fs.writeFileSync(tmpPath, data);
    fs.renameSync(tmpPath, targetPath);
  }

  private extractNativesJar(jarPath: string, nativesDir: string): void {
    fs.mkdirSync(nativesDir, { recursive: true });
    const zip = new AdmZip(jarPath);
    for (const entry of zip.getEntries()) {
      if (entry.isDirectory) continue;
      const cleanName = entry.entryName.replace(/\\/g, '/');
      if (cleanName.startsWith('META-INF/') || cleanName.includes('..')) continue;
      const fileName = path.basename(cleanName);
      if (!fileName) continue;
      fs.writeFileSync(path.join(nativesDir, fileName), entry.getData());
    }
  }

  private async resolveAzulJava25WinZipUrl(): Promise<string | null> {
    try {
      const metaBuf = await this.downloadBuffer(
        'https://api.azul.com/metadata/v1/zulu/packages/?java_version=25&os=windows&arch=x86&hw_bitness=64&archive_type=zip&java_package_type=jre&latest=true&release_status=ga&availability_types=CA',
        20_000,
        2
      );
      const list = JSON.parse(metaBuf.toString('utf8')) as Array<{
        name?: string;
        download_url?: string;
      }>;
      const standard = list.find(
        (pkg) => pkg.download_url && pkg.name && !pkg.name.includes('-fx-')
      );
      return standard?.download_url ?? list[0]?.download_url ?? null;
    } catch {
      return null;
    }
  }

  private async installManagedJava25(mcPath: string): Promise<string> {
    const targetDir = managedJava25Dir(mcPath);
    if (fs.existsSync(resolveJavaBin(targetDir)) && (getJavaMajorSafe(targetDir) ?? 0) >= 25) {
      return targetDir;
    }
    const osSlug =
      process.platform === 'win32'
        ? 'windows'
        : process.platform === 'darwin'
        ? 'mac'
        : 'linux';
    if (osSlug !== 'windows') {
      throw new Error(
        'Automatic JRE 25 ZIP extraction targets Windows. Point Java Path to an installed Java 25 JDK.'
      );
    }

    const zipPath = path.join(mcPath, 'runtime', 'java-25-jre.zip');
    fs.mkdirSync(path.dirname(zipPath), { recursive: true });

    const adoptiumUrl = `https://api.adoptium.net/v3/binary/latest/25/ga/${osSlug}/x64/jre/hotspot/normal/eclipse`;
    let bytes: Buffer;
    try {
      bytes = await this.downloadBuffer(adoptiumUrl, 120_000, 2);
    } catch (adoptiumErr) {
      const azulUrl = await this.resolveAzulJava25WinZipUrl();
      if (!azulUrl) {
        throw adoptiumErr;
      }
      bytes = await this.downloadBuffer(azulUrl, 120_000, 2);
    }
    fs.writeFileSync(zipPath, bytes);

    fs.rmSync(targetDir, { recursive: true, force: true });
    fs.mkdirSync(targetDir, { recursive: true });

    const zip = new AdmZip(zipPath);
    for (const entry of zip.getEntries()) {
      const normalized = entry.entryName.replace(/\\/g, '/');
      const slashIdx = normalized.indexOf('/');
      if (slashIdx === -1) continue;
      const stripped = normalized.slice(slashIdx + 1);
      if (!stripped || stripped.includes('..')) continue;
      const dest = path.join(targetDir, stripped);
      if (entry.isDirectory) {
        fs.mkdirSync(dest, { recursive: true });
      } else {
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.writeFileSync(dest, entry.getData());
      }
    }
    fs.rmSync(zipPath, { force: true });

    if (!fs.existsSync(resolveJavaBin(targetDir))) {
      throw new Error(`Extracted Java 25 runtime is missing javaw.exe inside ${targetDir}`);
    }
    return targetDir;
  }

  private async ensureMojang189Json(mcPath: string): Promise<Record<string, unknown>> {
    const jsonPath = path.join(mcPath, 'versions', '1.8.9', '1.8.9.json');
    if (fs.existsSync(jsonPath)) {
      try {
        return JSON.parse(fs.readFileSync(jsonPath, 'utf8')) as Record<string, unknown>;
      } catch {
        // re-fetch
      }
    }
    let versionUrl = MOJANG_189_FALLBACK_URL;
    try {
      const manifestBuf = await this.downloadBuffer(MOJANG_MANIFEST_URL);
      const manifest = JSON.parse(manifestBuf.toString('utf8')) as {
        versions?: Array<{ id?: string; url?: string }>;
      };
      const found = manifest.versions?.find((v) => v.id === '1.8.9')?.url;
      if (found) versionUrl = found;
    } catch {
      // fallback URL
    }
    const bytes = await this.downloadBuffer(versionUrl);
    const parsed = JSON.parse(bytes.toString('utf8')) as Record<string, unknown>;
    fs.mkdirSync(path.dirname(jsonPath), { recursive: true });
    fs.writeFileSync(jsonPath, bytes);
    return parsed;
  }

  private async ensureOrnitheProfileJson(
    mcPath: string,
    loaderVersion: string
  ): Promise<Record<string, unknown>> {
    const profilePath = path.join(
      mcPath,
      'versions',
      '1.8.9-ornithe',
      '1.8.9-ornithe.json'
    );
    if (fs.existsSync(profilePath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(profilePath, 'utf8')) as {
          libraries?: Array<{ name?: string }>;
        };
        const names = (parsed.libraries ?? []).map((l) => l.name ?? '');
        if (
          names.includes(`net.fabricmc:fabric-loader:${loaderVersion}`) &&
          names.some((n) => n.startsWith('net.fabricmc:sponge-mixin:'))
        ) {
          return parsed as Record<string, unknown>;
        }
      } catch {
        // re-fetch
      }
    }
    const url = `https://meta.ornithemc.net/v3/versions/gen2/fabric-loader/1.8.9/${loaderVersion}/profile/json`;
    const bytes = await this.downloadBuffer(url);
    const parsed = JSON.parse(bytes.toString('utf8')) as Record<string, unknown>;
    fs.mkdirSync(path.dirname(profilePath), { recursive: true });
    fs.writeFileSync(profilePath, bytes);
    return parsed;
  }

  downloadOrnitheAndMods(
    mcPath: string,
    ornithe: OrnitheConfig,
    includeArgentum: boolean
  ): VersionDownloadStatus {
    const artifacts: DownloadArtifact[] = [
      {
        id: 'mc-189-jar',
        label: 'Minecraft 1.8.9 Client, Libraries & Natives',
        fileName: '1.8.9.jar',
        sizeLabel: '22 MB',
        status: 'downloading',
        group: 'client',
      },
      {
        id: 'mc-18-assets',
        label: 'Minecraft 1.8 Asset Index & Sounds',
        fileName: '1.8.json',
        sizeLabel: '114 MB',
        status: 'pending',
        group: 'client',
      },
    ];

    if (ornithe.enabled) {
      artifacts.push({
        id: 'ornithe-loader',
        label: `Ornithe Gen2 Loader ${ornithe.loaderVersion} & Libraries`,
        fileName: `fabric-loader-${ornithe.loaderVersion}.jar`,
        sizeLabel: '4.5 MB',
        status: 'pending',
        group: 'ornithe',
      });
    }

    const needsJava25Install = includeArgentum
      ? !detectJavaInstallations(mcPath).some((d) => (d.major ?? 0) >= 25)
      : detectJavaInstallations(mcPath).length === 0;

    if (needsJava25Install) {
      artifacts.push({
        id: 'java-25',
        label: 'Eclipse Temurin Java 25 JRE',
        fileName: 'java-25',
        sizeLabel: '48 MB',
        status: 'pending',
        group: 'client',
      });
    }

    if (includeArgentum) {
      for (const item of getArgentumJars(mcPath)) {
        artifacts.push({
          id: item.id,
          label: item.fileName,
          fileName: item.fileName,
          sizeLabel: 'JAR',
          status: 'pending',
          group: 'argentum',
        });
      }
    }

    const markStep = (
      id: string,
      status: DownloadArtifact['status'],
      activeLabel: string | null
    ) => {
      for (const a of artifacts) {
        if (a.id === id) a.status = status;
      }
      const done = artifacts.filter((a) => a.status === 'done').length;
      const pct = Math.max(5, Math.floor((done * 100) / Math.max(1, artifacts.length)));
      this.downloadState = {
        state: done >= artifacts.length ? 'complete' : 'downloading',
        percent: done >= artifacts.length ? 100 : pct,
        currentArtifact: activeLabel,
        completedCount: done,
        totalCount: artifacts.length,
        artifacts: artifacts.map((a) => ({ ...a })),
      };
    };

    this.downloadState = {
      state: 'downloading',
      percent: 5,
      currentArtifact: artifacts[0]?.label ?? null,
      completedCount: 0,
      totalCount: artifacts.length,
      artifacts: artifacts.map((a) => ({ ...a })),
    };

    void (async () => {
      try {
        const v189 = await this.ensureMojang189Json(mcPath);
        const downloads = (v189.downloads ?? {}) as {
          client?: { url?: string };
        };
        const clientUrl =
          downloads.client?.url ??
          'https://launcher.mojang.com/v1/objects/3870888a6c3d349d3771a3e9d16c9bf5e076b908/client.jar';
        const clientJar = path.join(mcPath, 'versions', '1.8.9', '1.8.9.jar');
        await this.downloadIfMissing(clientUrl, clientJar);

        const nativesDir = path.join(mcPath, 'versions', '1.8.9', 'natives');
        const osName = currentMojangOsName();
        const libraries = Array.isArray(v189.libraries)
          ? (v189.libraries as Array<{
              rules?: Array<{ action?: string; os?: { name?: string } }>;
              natives?: Record<string, string>;
              downloads?: {
                artifact?: { url?: string; path?: string };
                classifiers?: Record<string, { url?: string; path?: string }>;
              };
            }>)
          : [];

        for (const lib of libraries) {
          if (!isLibraryAllowedForOs(lib)) continue;
          const artifact = lib.downloads?.artifact;
          if (artifact?.url && artifact?.path) {
            await this.downloadIfMissing(
              artifact.url,
              path.join(mcPath, 'libraries', artifact.path)
            );
          }
          const nativeKey = lib.natives?.[osName];
          if (nativeKey) {
            const arch = process.arch === 'x64' || process.arch === 'arm64' ? '64' : '32';
            const resolvedKey = nativeKey.replace('${arch}', arch);
            const classifier = lib.downloads?.classifiers?.[resolvedKey];
            if (classifier?.url && classifier?.path) {
              const target = path.join(mcPath, 'libraries', classifier.path);
              await this.downloadIfMissing(classifier.url, target);
              this.extractNativesJar(target, nativesDir);
            }
          }
        }
        markStep('mc-189-jar', 'done', 'Minecraft 1.8 Asset Index & Sounds');

        markStep('mc-18-assets', 'downloading', 'Minecraft 1.8 Asset Index & Sounds');
        const assetIndex = (v189.assetIndex ?? {}) as { url?: string };
        const assetUrl =
          assetIndex.url ??
          'https://launchermeta.mojang.com/v1/packages/f6ad102bcaa53b1a58358f16e376d548d44933ec/1.8.json';
        const assetIndexPath = path.join(mcPath, 'assets', 'indexes', '1.8.json');
        await this.downloadIfMissing(assetUrl, assetIndexPath);
        try {
          const idxJson = JSON.parse(fs.readFileSync(assetIndexPath, 'utf8')) as {
            objects?: Record<string, { hash?: string }>;
          };
          const missingObjects: Array<{ url: string; target: string }> = [];
          for (const obj of Object.values(idxJson.objects ?? {})) {
            if (!obj.hash || obj.hash.length < 2) continue;
            const prefix = obj.hash.slice(0, 2);
            const target = path.join(mcPath, 'assets', 'objects', prefix, obj.hash);
            if (!fs.existsSync(target)) {
              missingObjects.push({
                url: `https://resources.download.minecraft.net/${prefix}/${obj.hash}`,
                target,
              });
            }
          }
          const totalAssets = missingObjects.length;
          let downloadedAssets = 0;
          const concurrency = 12;
          let cursor = 0;
          await Promise.all(
            Array.from({ length: concurrency }, async () => {
              while (cursor < missingObjects.length) {
                const idx = cursor;
                cursor += 1;
                const item = missingObjects[idx];
                if (!item) break;
                try {
                  await this.downloadIfMissing(item.url, item.target, 30_000);
                } catch {
                  // Continue downloading remaining sound/resource assets
                } finally {
                  downloadedAssets += 1;
                  if (
                    this.downloadState &&
                    (downloadedAssets % 25 === 0 || downloadedAssets === totalAssets)
                  ) {
                    this.downloadState.currentArtifact = `Minecraft 1.8 Assets (${downloadedAssets}/${totalAssets})`;
                  }
                }
              }
            })
          );
        } catch {
          // Ignore malformed asset index read
        }
        markStep('mc-18-assets', 'done', null);

        if (ornithe.enabled) {
          markStep(
            'ornithe-loader',
            'downloading',
            `Ornithe Gen2 Loader ${ornithe.loaderVersion} & Libraries`
          );
          const ornitheJson = await this.ensureOrnitheProfileJson(mcPath, ornithe.loaderVersion);
          const oLibs = Array.isArray(ornitheJson.libraries)
            ? (ornitheJson.libraries as Array<{ name?: string; url?: string }>)
            : [];
          for (const lib of oLibs) {
            if (!lib.name) continue;
            const rel = mavenCoordToRelPath(lib.name);
            if (!rel) continue;
            const baseUrl = (lib.url ?? 'https://maven.fabricmc.net/').replace(/\/+$/, '');
            await this.downloadIfMissing(
              `${baseUrl}/${rel}`,
              path.join(mcPath, 'libraries', rel)
            );
          }
          markStep('ornithe-loader', 'done', null);
        }

        if (needsJava25Install) {
          markStep('java-25', 'downloading', 'Eclipse Temurin Java 25 JRE');
          await this.installManagedJava25(mcPath);
          markStep('java-25', 'done', null);
        }

        if (includeArgentum) {
          for (const item of getArgentumJars(mcPath)) {
            markStep(item.id, 'downloading', item.fileName);
            await this.downloadIfMissing(item.url, item.path);
            markStep(item.id, 'done', null);
          }
        }
      } catch (err) {
        const done = artifacts.filter((a) => a.status === 'done').length;
        this.downloadState = {
          state: 'error',
          percent: Math.floor((done * 100) / Math.max(1, artifacts.length)),
          currentArtifact: null,
          completedCount: done,
          totalCount: artifacts.length,
          artifacts: artifacts.map((a) => ({ ...a })),
          error: err instanceof Error ? err.message : 'Download failed',
        };
      }
    })();

    return this.getDownloadStatus();
  }

  private buildDesktopClasspath(
    mcPath: string,
    ornitheEnabled: boolean,
    loaderVersion: string
  ): { classpath: string; mainClass: string | null } {
    const sep = process.platform === 'win32' ? ';' : ':';
    const seenGa = new Set<string>();
    const entries: string[] = [];
    let ornitheMainClass: string | null = null;

    if (ornitheEnabled) {
      const profilePath = path.join(mcPath, 'versions', '1.8.9-ornithe', '1.8.9-ornithe.json');
      if (fs.existsSync(profilePath)) {
        try {
          const json = JSON.parse(fs.readFileSync(profilePath, 'utf8')) as {
            mainClass?: string;
            libraries?: Array<{ name?: string }>;
          };
          if (json.mainClass) ornitheMainClass = json.mainClass;
          for (const lib of json.libraries ?? []) {
            if (!lib.name) continue;
            const rel = mavenCoordToRelPath(lib.name);
            if (!rel) continue;
            const jar = path.join(mcPath, 'libraries', rel);
            if (fs.existsSync(jar)) {
              const ga = mavenGroupArtifactKey(lib.name);
              if (ga) seenGa.add(ga);
              entries.push(jar);
            }
          }
        } catch {
          // ignore
        }
      }
      if (entries.length === 0) {
        const loader = ornitheLoaderJar(mcPath, loaderVersion);
        const calamus = calamusJar(mcPath, '1.8.9');
        if (fs.existsSync(loader)) entries.push(loader);
        if (fs.existsSync(calamus)) entries.push(calamus);
      }
    }

    const v189Path = path.join(mcPath, 'versions', '1.8.9', '1.8.9.json');
    if (fs.existsSync(v189Path)) {
      try {
        const json = JSON.parse(fs.readFileSync(v189Path, 'utf8')) as {
          libraries?: Array<{
            name?: string;
            rules?: Array<{ action?: string; os?: { name?: string } }>;
            natives?: Record<string, string>;
            downloads?: { artifact?: { path?: string } };
          }>;
        };
        for (const lib of json.libraries ?? []) {
          if (!isLibraryAllowedForOs(lib)) continue;
          if (lib.natives && !lib.downloads?.artifact) continue;
          if (lib.name) {
            const ga = mavenGroupArtifactKey(lib.name);
            if (ga) {
              if (seenGa.has(ga)) continue;
              seenGa.add(ga);
            }
          }
          const rel = lib.downloads?.artifact?.path;
          if (rel) {
            const jar = path.join(mcPath, 'libraries', rel);
            if (fs.existsSync(jar)) entries.push(jar);
          }
        }
      } catch {
        // ignore
      }
    }

    entries.push(path.join(mcPath, 'versions', '1.8.9', '1.8.9.jar'));
    return { classpath: entries.join(sep), mainClass: ornitheMainClass };
  }

  async launchMinecraft(
    settings: LauncherSettings,
    ornithe?: OrnitheConfig | null,
    serverAddress?: string | null,
    enabledMods?: string[] | null,
    onMinimize?: () => void,
    onUnexpectedExit?: (code: number | null, message: string) => void
  ): Promise<LaunchResponse> {
    this.saveSettings(settings);
    const ornitheCfg = ornithe ?? DEFAULT_ORNITHE_CONFIG;
    const effJava = effectiveJavaPath(settings.java_path, settings.mc_path, settings.optifine);
    const javaBin = resolveJavaBin(effJava);

    if (!fs.existsSync(javaBin)) {
      throw new Error(`Java executable not found at: ${javaBin}`);
    }

    const detectedMajor = getJavaMajorSafe(effJava);
    if (settings.optifine) {
      const major = detectedMajor ?? 0;
      if (major > 0 && major < 25) {
        throw new Error(
          `Argentum 1.0.2 & ForgeCompat require Java 25, but detected Java ${major}. Click Download Now or point Java Path to JDK/JRE 25.`
        );
      }
    }

    const clientJar = path.join(settings.mc_path, 'versions', '1.8.9', '1.8.9.jar');
    if (!fs.existsSync(clientJar)) {
      throw new Error(`Minecraft 1.8.9 jar not found at: ${clientJar}`);
    }

    const modsDir = path.join(settings.mc_path, 'mods');
    fs.mkdirSync(modsDir, { recursive: true });
    if (Array.isArray(enabledMods)) {
      const cfgDir = path.join(settings.mc_path, 'config');
      fs.mkdirSync(cfgDir, { recursive: true });
      fs.writeFileSync(
        path.join(cfgDir, 'agretium-modules.json'),
        JSON.stringify(enabledMods, null, 2),
        'utf8'
      );
    }

    const activeJars = scanModJars(settings.mc_path)
      .filter((m) => m.enabled)
      .map((m) => m.fileName);

    const { classpath, mainClass: ornitheMain } = this.buildDesktopClasspath(
      settings.mc_path,
      ornitheCfg.enabled,
      ornitheCfg.loaderVersion
    );

    const nativesDir = path.join(settings.mc_path, 'versions', '1.8.9', 'natives');
    const assetsDir = path.join(settings.mc_path, 'assets');
    const resMatch = settings.resolution.match(/^(\d+)\s*[xX]\s*(\d+)$/);
    const resW = resMatch?.[1] ?? '1280';
    const resH = resMatch?.[2] ?? '720';

    const args: string[] = [`-Xmx${Math.max(1024, settings.ram_mb)}M`, '-Xms512M'];
    if (settings.new_gc) {
      args.push('-XX:+UseG1GC');
    }
    args.push(
      '-XX:+ParallelRefProcEnabled',
      '-XX:MaxGCPauseMillis=50',
      '-XX:+DisableExplicitGC',
      '-Djava.net.preferIPv4Stack=true',
      `-Djava.library.path=${nativesDir}`,
      ...buildJavaCompatFlags(detectedMajor ?? (settings.optifine ? 25 : 8))
    );
    if (process.platform === 'darwin') {
      args.push('-XstartOnFirstThread');
    }

    if (ornitheCfg.enabled) {
      const mainClass =
        ornitheMain ?? 'net.fabricmc.loader.impl.launch.knot.KnotClient';
      args.push(
        '-Dfabric.fixPackageAccess=true',
        '-Dfabric.gameVersion=1.8.9',
        `-Dfabric.loaderVersion=${ornitheCfg.loaderVersion}`,
        `-Dornithe.mappings=calamus-gen2-${ornitheCfg.calamusVersion}`,
        '-Dmixin.hotSwap=false',
        '-cp',
        classpath,
        mainClass
      );
    } else {
      args.push('-cp', classpath, 'net.minecraft.client.main.Main');
    }

    const uuid = generateOfflineUuid(settings.account);
    args.push(
      '--username',
      settings.account,
      '--version',
      ornitheCfg.enabled ? '1.8.9-ornithe' : '1.8.9',
      '--gameDir',
      settings.mc_path,
      '--assetsDir',
      assetsDir,
      '--assetIndex',
      '1.8',
      '--uuid',
      uuid,
      '--accessToken',
      '0',
      '--userProperties',
      '{}',
      '--userType',
      'legacy',
      '--width',
      resW,
      '--height',
      resH
    );

    if (serverAddress && serverAddress.trim()) {
      const trimmed = serverAddress.trim();
      const idx = trimmed.lastIndexOf(':');
      const host =
        idx > 0 && /^\d+$/.test(trimmed.slice(idx + 1))
          ? trimmed.slice(0, idx).trim()
          : trimmed;
      const port =
        idx > 0 && /^\d+$/.test(trimmed.slice(idx + 1)) ? trimmed.slice(idx + 1) : '25565';
      args.push('--server', host, '--port', port);
    }

    if (this.activeChild) {
      try {
        this.activeChild.kill();
      } catch {
        // ignore
      }
      this.activeChild = null;
    }

    const child = spawn(javaBin, args, {
      cwd: settings.mc_path,
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: false,
    });

    this.activeChild = child;
    this.activePid = child.pid ?? null;
    this.startedAtMs = Date.now();
    this.xmxMb = Math.max(1024, settings.ram_mb);
    this.xmsMb = 512;
    this.newGc = settings.new_gc;
    this.gcCollections = 0;
    this.jvmLogs = [];

    const recentOutputLines: string[] = [];
    const pushLine = (level: JvmLogEntry['level'], thread: string, line: string) => {
      this.pushJvmLog(level, thread, line);
      recentOutputLines.push(line);
      if (recentOutputLines.length > 20) {
        recentOutputLines.shift();
      }
    };

    this.pushJvmLog(
      'INFO',
      'Launcher',
      `Spawned ${ornitheCfg.enabled ? 'Ornithe 1.8.9' : 'Minecraft 1.8.9'} (PID ${
        child.pid ?? 'unknown'
      }) with ${activeJars.length} active mod JARs in ${modsDir}: ${
        activeJars.length > 0 ? activeJars.join(', ') : 'none'
      }`
    );

    child.stdout?.on('data', (chunk: Buffer) => {
      for (const line of chunk.toString('utf8').split(/\r?\n/)) {
        if (line.trim()) pushLine('INFO', 'Game/stdout', line);
      }
    });
    child.stderr?.on('data', (chunk: Buffer) => {
      for (const line of chunk.toString('utf8').split(/\r?\n/)) {
        if (line.trim()) pushLine('WARN', 'Game/stderr', line);
      }
    });

    let settledEarly = false;
    const earlyFailure = await new Promise<string | null>((resolve) => {
      const timer = setTimeout(() => {
        settledEarly = true;
        resolve(null);
      }, 2200);

      child.once('error', (err) => {
        clearTimeout(timer);
        if (this.activeChild === child) {
          this.activeChild = null;
          this.activePid = null;
        }
        if (!settledEarly) {
          settledEarly = true;
          resolve(`Failed to start Java (${javaBin}): ${err.message}`);
        }
      });

      child.once('exit', (code) => {
        clearTimeout(timer);
        if (this.activeChild === child) {
          this.activeChild = null;
          this.activePid = null;
        }
        if (!settledEarly) {
          settledEarly = true;
          if (code === 0) {
            resolve(null);
          } else {
            const tail = recentOutputLines.slice(-4).join(' | ');
            resolve(
              `Minecraft exited immediately (code ${code ?? 'unknown'})${
                tail ? `: ${tail}` : ' — check Debug logs for JVM output.'
              }`
            );
          }
        }
      });
    });

    const commandLine = `${javaBin} ${args.join(' ')}`;

    if (earlyFailure) {
      this.pushJvmLog('WARN', 'Launcher', earlyFailure);
      this.appendHistoryEntry({
        id: `${Date.now()}`,
        timestamp: new Date().toISOString(),
        version: ornitheCfg.enabled ? '1.8.9-ornithe' : '1.8.9',
        account: settings.account,
        ram_mb: settings.ram_mb,
        optifine: settings.optifine,
        resolution: settings.resolution,
        command: commandLine,
        status: 'failed',
        message: earlyFailure,
        serverAddress: serverAddress ?? undefined,
      });
      throw new Error(earlyFailure);
    }

    child.on('exit', (code) => {
      const pidVal = this.activePid;
      if (this.activeChild === child) {
        this.activeChild = null;
        this.activePid = null;
      }
      const tail = recentOutputLines.slice(-3).join(' | ');
      const exitMsg = `Minecraft process (PID ${pidVal ?? 0}) exited with code ${code ?? 'null'}${
        code !== 0 && tail ? `: ${tail}` : ''
      }`;
      this.pushJvmLog(code === 0 ? 'INFO' : 'WARN', 'Launcher', exitMsg);
      if (code !== 0 && code !== null && onUnexpectedExit) {
        onUnexpectedExit(code, exitMsg);
      }
    });

    if (settings.minimize_on_launch && onMinimize) {
      onMinimize();
    }

    const message = `Launched ${
      ornitheCfg.enabled ? 'Ornithe 1.8.9' : 'Minecraft 1.8.9'
    } (${settings.ram_mb} MB RAM · ${activeJars.length} mod JARs)`;

    const historyEntry: LaunchHistoryEntry = {
      id: `${Date.now()}`,
      timestamp: new Date().toISOString(),
      version: ornitheCfg.enabled ? '1.8.9-ornithe' : '1.8.9',
      account: settings.account,
      ram_mb: settings.ram_mb,
      optifine: settings.optifine,
      resolution: settings.resolution,
      command: commandLine,
      status: 'launched',
      message,
      serverAddress: serverAddress ?? undefined,
      launchDurationMs: 2200,
    };
    this.appendHistoryEntry(historyEntry);

    return {
      ok: true,
      message,
      command: commandLine,
      args,
      javaBin,
      clientJar,
      minimized: settings.minimize_on_launch,
      historyEntry,
    };
  }

  getJvmStatus(): JvmStatusSnapshot {
    const hostTotalRamMb = Math.max(4096, Math.floor(os.totalmem() / (1024 * 1024)));
    const hostFreeRamMb = Math.max(256, Math.floor(os.freemem() / (1024 * 1024)));
    const running = this.activeChild !== null && this.activeChild.exitCode === null;
    const usedMb = running ? Math.min(this.xmxMb, Math.round(this.xmxMb * 0.42)) : 0;
    const allocatedMb = running ? Math.min(this.xmxMb, Math.max(this.xmsMb, usedMb + 128)) : 0;
    const uptimeSeconds = running ? Math.floor((Date.now() - this.startedAtMs) / 1000) : 0;

    return {
      running,
      pid: running ? this.activePid : null,
      version: '1.8.9',
      xmx_mb: this.xmxMb,
      xms_mb: this.xmsMb,
      allocated_mb: allocatedMb,
      used_mb: usedMb,
      gc_algorithm: this.newGc ? 'G1GC (-XX:+UseG1GC)' : 'Parallel GC (Default)',
      xmx_flag: `-Xmx${this.xmxMb}M`,
      xmx_verified: allocatedMb <= this.xmxMb && usedMb <= this.xmxMb,
      host_total_ram_mb: hostTotalRamMb,
      host_free_ram_mb: hostFreeRamMb,
      uptime_seconds: uptimeSeconds,
      gc_collections: this.gcCollections,
      timestamp: new Date().toISOString(),
      logs: [...this.jvmLogs],
    };
  }

  triggerJvmGc(): JvmStatusSnapshot {
    this.gcCollections += 1;
    this.pushJvmLog(
      'INFO',
      'Launcher',
      'JVM heap telemetry sampled (G1GC manages live collections automatically).'
    );
    return this.getJvmStatus();
  }

  stopJvmSession(): JvmStatusSnapshot {
    if (this.activeChild) {
      try {
        this.activeChild.kill();
      } catch {
        // ignore
      }
      this.activeChild = null;
      this.activePid = null;
    }
    this.pushJvmLog('INFO', 'Launcher', 'Stopped Minecraft 1.8.9 client process.');
    return this.getJvmStatus();
  }
}
