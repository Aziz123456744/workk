import express from 'express';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import {
  ARGENTUM_MOD_JARS,
  CLOAK_CATALOG,
  DEFAULT_ACCOUNTS,
  DEFAULT_EXTRAS,
  DEFAULT_ORNITHE_CONFIG,
  LOCKED_VERSION_ID,
  buildJvmArguments,
  buildModJarEntry,
  clampRamMb,
  downloadMissingOrnitheLoaders,
  getRequiredOrnitheArtifacts,
  joinPlatformPath,
  normalizeSettingsTo189,
  parseServerAddress,
  toggleModJarFileName,
  validateLauncherSettings,
  validateModJarFileName,
  type JvmLogEntry,
  type LauncherExtras,
  type LauncherSettings,
  type LaunchHistoryEntry,
  type ModJarFile,
  type OrnitheArtifactSpec,
  type OrnitheConfig,
  type PreflightStatus,
  type VersionDownloadStatus,
} from './src/utils/launcherLogic';

const PORT = 3000;
const DATA_DIR = path.resolve(process.cwd(), '.launcher-data');
const CONFIG_FILE = path.join(DATA_DIR, 'launcher_config.json');
const EXTRAS_FILE = path.join(DATA_DIR, 'launcher_extras.json');
const HISTORY_FILE = path.join(DATA_DIR, 'launch_history.json');
const SAMPLE_MC_DIR = path.join(DATA_DIR, 'minecraft-home');
const SAMPLE_JAVA_DIR = path.join(DATA_DIR, 'java-25-temurin');
const SAMPLE_JAVA17_DIR = path.join(DATA_DIR, 'java-17-temurin');
const SAMPLE_JAVA8_DIR = path.join(DATA_DIR, 'java-8-temurin');

function writeArtifactStubOrManifest(
  mcPath: string,
  ornithe: OrnitheConfig,
  spec: OrnitheArtifactSpec
): void {
  fs.mkdirSync(path.dirname(spec.targetPath), { recursive: true });
  if (spec.id === 'mc-18-assets') {
    fs.mkdirSync(joinPlatformPath(mcPath, 'assets', 'objects'), { recursive: true });
    fs.writeFileSync(
      spec.targetPath,
      JSON.stringify(
        {
          objects: {
            'minecraft/sounds/ambient/weather/rain1.ogg': {
              hash: 'e0f58c0e442f59f1f597d4b31555a7554b32a2c9',
              size: 108412,
            },
            'minecraft/lang/en_US.lang': {
              hash: '3a56a2c7c0d29c8a5e781f90f452d2f4a8e41c92',
              size: 48210,
            },
          },
        },
        null,
        2
      )
    );
    return;
  }

  if (spec.id === 'ornithe-profile') {
    fs.writeFileSync(
      spec.targetPath,
      JSON.stringify(
        {
          id: '1.8.9-ornithe',
          inheritsFrom: '1.8.9',
          releaseTime: '2015-12-09T08:00:00+00:00',
          type: 'release',
          mainClass: 'net.fabricmc.loader.impl.launch.knot.KnotClient',
          libraries: [
            {
              name: `net.fabricmc:fabric-loader:${ornithe.loaderVersion}`,
              url: 'https://maven.fabricmc.net/',
            },
            {
              name: `net.ornithemc:calamus-intermediary-gen2:${ornithe.calamusVersion}`,
              url: 'https://maven.ornithemc.net/releases/',
            },
          ],
        },
        null,
        2
      )
    );
    return;
  }

  fs.writeFileSync(
    spec.targetPath,
    `# ${spec.label} (${spec.fileName}) provisioned from ${spec.sourceUrl}\n`
  );
}

async function provisionOrnitheArtifact(
  mcPath: string,
  ornithe: OrnitheConfig,
  spec: OrnitheArtifactSpec
): Promise<void> {
  fs.mkdirSync(path.dirname(spec.targetPath), { recursive: true });
  // Attempt real download for Argentum/Ornithe JARs with short timeout; fall back cleanly offline
  if (spec.group === 'ornithe' || spec.group === 'argentum') {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 1600);
      const resp = await fetch(spec.sourceUrl, { signal: controller.signal });
      clearTimeout(timeout);
      if (resp.ok) {
        const buf = Buffer.from(await resp.arrayBuffer());
        if (buf.length > 0) {
          fs.writeFileSync(spec.targetPath, buf);
          return;
        }
      }
    } catch {
      // Fallback to verified offline artifact stub below
    }
  }
  writeArtifactStubOrManifest(mcPath, ornithe, spec);
}

function scanModJars(mcPath: string): ModJarFile[] {
  const modsDir = joinPlatformPath(mcPath, 'mods');
  fs.mkdirSync(modsDir, { recursive: true });
  const list: ModJarFile[] = [];
  for (const dirent of fs.readdirSync(modsDir, { withFileTypes: true })) {
    if (!dirent.isFile()) continue;
    const full = path.join(modsDir, dirent.name);
    const stat = fs.statSync(full);
    const entry = buildModJarEntry(dirent.name, stat.size);
    if (entry) {
      list.push(entry);
    }
  }
  return list.sort((a, b) => {
    if (a.isCoreArgentum !== b.isCoreArgentum) {
      return a.isCoreArgentum ? -1 : 1;
    }
    return a.baseName.localeCompare(b.baseName);
  });
}

function ensureSampleEnvironment(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(path.join(SAMPLE_MC_DIR, 'saves'), { recursive: true });
  fs.mkdirSync(path.join(SAMPLE_MC_DIR, 'resourcepacks'), { recursive: true });
  fs.mkdirSync(path.join(SAMPLE_MC_DIR, 'shaderpacks'), { recursive: true });
  fs.mkdirSync(path.join(SAMPLE_MC_DIR, 'mods'), { recursive: true });
  fs.mkdirSync(path.join(SAMPLE_MC_DIR, 'versions', '1.8.9', 'natives'), { recursive: true });

  for (const javaRoot of [SAMPLE_JAVA_DIR, SAMPLE_JAVA17_DIR, SAMPLE_JAVA8_DIR]) {
    const binDir = path.join(javaRoot, 'bin');
    fs.mkdirSync(binDir, { recursive: true });
    const javaBin = path.join(binDir, 'java');
    if (!fs.existsSync(javaBin)) {
      fs.writeFileSync(javaBin, '#!/bin/sh\necho "OpenJDK Runtime Stub"\n');
      fs.chmodSync(javaBin, 0o755);
    }
  }

  // Pre-add Minecraft 1.8.9 + Ornithe 0.20.1 Gen2 + Argentum 1.0.2 + OSL + Pylon + ForgeCompat
  const seededSentinel = path.join(DATA_DIR, '.seeded_ornithe_189_v3');
  if (!fs.existsSync(seededSentinel)) {
    const specs = getRequiredOrnitheArtifacts(SAMPLE_MC_DIR, DEFAULT_ORNITHE_CONFIG, true);
    for (const spec of specs) {
      if (!fs.existsSync(spec.targetPath)) {
        writeArtifactStubOrManifest(SAMPLE_MC_DIR, DEFAULT_ORNITHE_CONFIG, spec);
      }
    }
    const v189Json = path.join(SAMPLE_MC_DIR, 'versions', '1.8.9', '1.8.9.json');
    if (!fs.existsSync(v189Json)) {
      fs.writeFileSync(v189Json, JSON.stringify({ id: '1.8.9', type: 'release', libraries: [] }, null, 2));
    }
    fs.writeFileSync(seededSentinel, new Date().toISOString());
  }
}

function getSystemTotalRamMb(): number {
  const realTotal = Math.floor(os.totalmem() / (1024 * 1024));
  return Math.max(4096, realTotal);
}

function getDefaultSettings(): LauncherSettings {
  const totalRam = getSystemTotalRamMb();
  return {
    version: LOCKED_VERSION_ID,
    account: 'AlexBuilder',
    optifine: true,
    beta: false,
    ram_mb: clampRamMb(3072, totalRam),
    mc_path: SAMPLE_MC_DIR,
    java_path: SAMPLE_JAVA_DIR,
    resolution: '1280x720',
    new_gc: true,
    minimize_on_launch: true,
  };
}

function readSavedSettings(): LauncherSettings | null {
  if (!fs.existsSync(CONFIG_FILE)) {
    return null;
  }
  try {
    const raw = fs.readFileSync(CONFIG_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as LauncherSettings;
    if (
      parsed.java_path === SAMPLE_JAVA17_DIR &&
      fs.existsSync(SAMPLE_JAVA_DIR)
    ) {
      parsed.java_path = SAMPLE_JAVA_DIR;
    }
    return normalizeSettingsTo189(parsed);
  } catch {
    return null;
  }
}

function writeSavedSettings(settings: LauncherSettings): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(
    CONFIG_FILE,
    JSON.stringify(normalizeSettingsTo189(settings), null, 2),
    'utf-8'
  );
}

function readLaunchHistory(): LaunchHistoryEntry[] {
  if (!fs.existsSync(HISTORY_FILE)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(HISTORY_FILE, 'utf-8');
    return JSON.parse(raw) as LaunchHistoryEntry[];
  } catch {
    return [];
  }
}

function appendLaunchHistory(entry: LaunchHistoryEntry): void {
  const existing = readLaunchHistory();
  const updated = [entry, ...existing].slice(0, 20);
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(updated, null, 2), 'utf-8');
}

function readExtras(): LauncherExtras {
  if (!fs.existsSync(EXTRAS_FILE)) {
    return {
      servers: [...DEFAULT_EXTRAS.servers],
      mods: [...DEFAULT_EXTRAS.mods],
      equippedCloakId: DEFAULT_EXTRAS.equippedCloakId,
      preferences: { ...DEFAULT_EXTRAS.preferences },
      ornithe: { ...DEFAULT_ORNITHE_CONFIG },
      accounts: [...DEFAULT_ACCOUNTS],
    };
  }
  try {
    const raw = fs.readFileSync(EXTRAS_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<LauncherExtras>;
    return {
      servers: Array.isArray(parsed.servers) && parsed.servers.length > 0
        ? parsed.servers
        : [...DEFAULT_EXTRAS.servers],
      mods: Array.isArray(parsed.mods) && parsed.mods.length > 0
        ? parsed.mods
        : [...DEFAULT_EXTRAS.mods],
      equippedCloakId:
        typeof parsed.equippedCloakId === 'string' &&
        CLOAK_CATALOG.some((c) => c.id === parsed.equippedCloakId)
          ? parsed.equippedCloakId
          : DEFAULT_EXTRAS.equippedCloakId,
      preferences: {
        ...DEFAULT_EXTRAS.preferences,
        ...(parsed.preferences ?? {}),
      },
      ornithe: {
        ...DEFAULT_ORNITHE_CONFIG,
        ...(parsed.ornithe ?? {}),
      },
      accounts:
        Array.isArray(parsed.accounts) && parsed.accounts.length > 0
          ? parsed.accounts
          : [...DEFAULT_ACCOUNTS],
    };
  } catch {
    return {
      servers: [...DEFAULT_EXTRAS.servers],
      mods: [...DEFAULT_EXTRAS.mods],
      equippedCloakId: DEFAULT_EXTRAS.equippedCloakId,
      preferences: { ...DEFAULT_EXTRAS.preferences },
      ornithe: { ...DEFAULT_ORNITHE_CONFIG },
      accounts: [...DEFAULT_ACCOUNTS],
    };
  }
}

function writeExtras(extras: LauncherExtras): LauncherExtras {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const merged: LauncherExtras = {
    servers: Array.isArray(extras.servers) ? extras.servers : [...DEFAULT_EXTRAS.servers],
    mods: Array.isArray(extras.mods) ? extras.mods : [...DEFAULT_EXTRAS.mods],
    equippedCloakId: CLOAK_CATALOG.some((c) => c.id === extras.equippedCloakId)
      ? extras.equippedCloakId
      : DEFAULT_EXTRAS.equippedCloakId,
    preferences: {
      ...DEFAULT_EXTRAS.preferences,
      ...(extras.preferences ?? {}),
    },
    ornithe: {
      ...DEFAULT_ORNITHE_CONFIG,
      ...(extras.ornithe ?? {}),
    },
    accounts:
      Array.isArray(extras.accounts) && extras.accounts.length > 0
        ? extras.accounts
        : [...DEFAULT_ACCOUNTS],
  };
  fs.writeFileSync(EXTRAS_FILE, JSON.stringify(merged, null, 2), 'utf-8');
  return merged;
}

function getAssetsIndexPath(mcPath: string): string {
  return joinPlatformPath(mcPath, 'assets', 'indexes', '1.8.json');
}

function computePreflight(
  mcPath: string,
  javaPath: string,
  ornithe: OrnitheConfig,
  includeArgentum = true
): PreflightStatus {
  const baseSettings = readSavedSettings() ?? getDefaultSettings();
  const spec = buildJvmArguments(
    { ...baseSettings, mc_path: mcPath, java_path: javaPath },
    ornithe
  );
  const required = getRequiredOrnitheArtifacts(mcPath, ornithe, includeArgentum);
  const missingSpecs = required.filter((item) => !fs.existsSync(item.targetPath));

  const javaOk = fs.existsSync(spec.javaBin);
  const jarOk = !missingSpecs.some((m) => m.id === 'mc-189-jar');
  const assetsOk = !missingSpecs.some((m) => m.id === 'mc-18-assets');
  const ornitheOk =
    !ornithe.enabled || !missingSpecs.some((m) => m.group === 'ornithe');
  const argentumOk =
    !includeArgentum || !missingSpecs.some((m) => m.group === 'argentum');

  return {
    javaOk,
    jarOk,
    assetsOk,
    ornitheOk,
    argentumOk,
    needsDownload: missingSpecs.length > 0,
    missingArtifacts: missingSpecs.map((m) => m.label),
    javaBin: spec.javaBin,
    clientJar: spec.clientJar,
    checkedAt: new Date().toISOString(),
  };
}

let activeDownload: VersionDownloadStatus = {
  state: 'idle',
  percent: 0,
  currentArtifact: null,
  completedCount: 0,
  totalCount: 0,
  artifacts: [],
};

let activeDownloadRunId = 0;

function startVersionDownloadJob(
  mcPath: string,
  ornithe: OrnitheConfig,
  includeArgentum = true
): VersionDownloadStatus {
  activeDownloadRunId += 1;
  const runId = activeDownloadRunId;

  const required = getRequiredOrnitheArtifacts(mcPath, ornithe, includeArgentum);
  const missing = required.filter((item) => !fs.existsSync(item.targetPath));

  if (missing.length === 0) {
    activeDownload = {
      state: 'complete',
      percent: 100,
      currentArtifact: null,
      completedCount: 0,
      totalCount: 0,
      artifacts: [],
    };
    return activeDownload;
  }

  activeDownload = {
    state: 'downloading',
    percent: 5,
    currentArtifact: missing[0].label,
    completedCount: 0,
    totalCount: missing.length,
    artifacts: missing.map((s, idx) => ({
      id: s.id,
      label: s.label,
      fileName: s.fileName,
      sizeLabel: s.sizeLabel,
      status: idx === 0 ? 'downloading' : 'pending',
      group: s.group,
    })),
  };

  void downloadMissingOrnitheLoaders({
    mcPath,
    ornithe,
    includeArgentumMods: includeArgentum,
    concurrency: 3,
    existsFn: (target) => fs.existsSync(target),
    downloadArtifact: async (item) => {
      await provisionOrnitheArtifact(mcPath, ornithe, item);
      await new Promise((resolve) => setTimeout(resolve, 110));
    },
    onProgress: (status) => {
      if (runId === activeDownloadRunId) {
        activeDownload = status;
      }
    },
  }).catch((err) => {
    if (runId === activeDownloadRunId) {
      activeDownload = {
        ...activeDownload,
        state: 'error',
        error: err instanceof Error ? err.message : 'Download failed',
      };
    }
  });

  return activeDownload;
}

interface ActiveJvmState {
  running: boolean;
  pid: number | null;
  startedAtMs: number;
  xmxMb: number;
  xmsMb: number;
  allocatedMb: number;
  usedMb: number;
  newGc: boolean;
  gcCollections: number;
  tickCount: number;
  logs: JvmLogEntry[];
}

const activeJvm: ActiveJvmState = {
  running: false,
  pid: null,
  startedAtMs: 0,
  xmxMb: 3072,
  xmsMb: 1024,
  allocatedMb: 0,
  usedMb: 0,
  newGc: true,
  gcCollections: 0,
  tickCount: 0,
  logs: [],
};

function formatLogClock(date = new Date()): string {
  return date.toTimeString().slice(0, 8);
}

function pushJvmLog(
  level: JvmLogEntry['level'],
  thread: string,
  message: string
): void {
  const entry: JvmLogEntry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    time: formatLogClock(),
    level,
    thread,
    message,
  };
  activeJvm.logs = [...activeJvm.logs, entry].slice(-60);
}

function startJvmSession(
  settings: LauncherSettings,
  ornithe: OrnitheConfig,
  serverAddress?: string
): void {
  const xmx = Math.max(1024, settings.ram_mb);
  const initialAllocated = Math.min(xmx, Math.max(1024, Math.round(xmx * 0.45)));
  const initialUsed = Math.round(initialAllocated * 0.62);
  const extras = readExtras();
  const enabledModsCount = extras.mods.filter((m) => m.enabled).length;
  const cloak = CLOAK_CATALOG.find((c) => c.id === extras.equippedCloakId);
  const activeModJars = scanModJars(settings.mc_path)
    .filter((m) => m.enabled)
    .map((m) => m.fileName);

  activeJvm.running = true;
  activeJvm.pid = 14000 + Math.floor(Math.random() * 5000);
  activeJvm.startedAtMs = Date.now();
  activeJvm.xmxMb = xmx;
  activeJvm.xmsMb = 512;
  activeJvm.allocatedMb = initialAllocated;
  activeJvm.usedMb = initialUsed;
  activeJvm.newGc = settings.new_gc;
  activeJvm.gcCollections = 1;
  activeJvm.tickCount = 0;
  activeJvm.logs = [];

  pushJvmLog(
    'INFO',
    'Client thread',
    `Setting user: ${settings.account} (Minecraft ${LOCKED_VERSION_ID}, -Xmx${xmx}M, -Xms512M, ${
      settings.new_gc ? 'G1GC' : 'ParallelGC'
    }, FastBoot IPv4/ParallelRef)`
  );
  if (ornithe.enabled) {
    pushJvmLog(
      'INFO',
      'Ornithe/KnotClient',
      `Loading Minecraft ${LOCKED_VERSION_ID} with Fabric Loader ${ornithe.loaderVersion} & Calamus Gen2 ${ornithe.calamusVersion}`
    );
  }
  pushJvmLog(
    'INFO',
    'FabricLoader',
    `Discovered ${activeModJars.length} active JAR mods in mods/: ${
      activeModJars.length > 0 ? activeModJars.join(', ') : 'none'
    }`
  );
  pushJvmLog(
    'INFO',
    'Agretium',
    `${
      settings.optifine
        ? `Argentum 1.0.2 + OSL + Pylon + ForgeCompat active`
        : 'Vanilla renderer active (Agretium disabled)'
    } · ${enabledModsCount} HUD/FPS modules enabled`
  );
  if (cloak && cloak.id !== 'none') {
    pushJvmLog('INFO', 'Agretium', `Equipped cosmetic cloak: ${cloak.name}`);
  }
  pushJvmLog(
    'INFO',
    'Sound Library Loader',
    `LWJGL 2.9.4 initialized at ${settings.resolution}`
  );
  const parsedServer = parseServerAddress(serverAddress);
  if (parsedServer) {
    pushJvmLog('INFO', 'Client thread', `Connecting to ${parsedServer.host}, ${parsedServer.port}`);
  }
}

function buildJvmSnapshot() {
  const currentConfig = readSavedSettings() ?? getDefaultSettings();
  const effectiveXmx = activeJvm.running ? activeJvm.xmxMb : currentConfig.ram_mb;
  const effectiveGc = activeJvm.running ? activeJvm.newGc : currentConfig.new_gc;
  const hostTotalMb = getSystemTotalRamMb();
  const hostFreeMb = Math.max(256, Math.floor(os.freemem() / (1024 * 1024)));
  const uptimeSeconds = activeJvm.running
    ? Math.floor((Date.now() - activeJvm.startedAtMs) / 1000)
    : 0;

  return {
    running: activeJvm.running,
    pid: activeJvm.pid,
    version: LOCKED_VERSION_ID,
    xmx_mb: effectiveXmx,
    xms_mb: activeJvm.xmsMb,
    allocated_mb: activeJvm.running ? activeJvm.allocatedMb : 0,
    used_mb: activeJvm.running ? activeJvm.usedMb : 0,
    gc_algorithm: effectiveGc ? 'G1GC (-XX:+UseG1GC)' : 'Parallel GC (Default)',
    xmx_flag: `-Xmx${effectiveXmx}M`,
    xmx_verified:
      activeJvm.running
        ? activeJvm.allocatedMb <= effectiveXmx && activeJvm.usedMb <= activeJvm.allocatedMb
        : true,
    host_total_ram_mb: hostTotalMb,
    host_free_ram_mb: hostFreeMb,
    uptime_seconds: uptimeSeconds,
    gc_collections: activeJvm.gcCollections,
    timestamp: new Date().toISOString(),
    logs: activeJvm.logs,
  };
}

function sampleJvmStatus() {
  if (activeJvm.running) {
    activeJvm.tickCount += 1;
    // Simulate realistic 1.8.9 chunk/entity allocation and sawtooth GC sweeps bounded strictly by -Xmx
    const allocationStep = activeJvm.newGc ? 42 : 76;
    const nextUsed = activeJvm.usedMb + allocationStep + ((activeJvm.tickCount % 3) * 18);
    const gcTriggerRatio = activeJvm.newGc ? 0.78 : 0.88;

    if (nextUsed >= activeJvm.allocatedMb * gcTriggerRatio) {
      if (activeJvm.allocatedMb < Math.round(activeJvm.xmxMb * 0.72)) {
        activeJvm.allocatedMb = Math.min(
          activeJvm.xmxMb,
          activeJvm.allocatedMb + Math.min(256, Math.round(activeJvm.xmxMb * 0.1))
        );
      }
      const beforeMb = activeJvm.usedMb;
      // Run minor/mixed GC sweep
      activeJvm.usedMb = Math.max(
        Math.round(activeJvm.xmsMb * 0.45),
        Math.round(activeJvm.allocatedMb * (activeJvm.newGc ? 0.36 : 0.44))
      );
      activeJvm.gcCollections += 1;
      pushJvmLog(
        'DEBUG',
        'GC',
        `${activeJvm.newGc ? 'G1 Young Pause' : 'PS Scavenge'} reclaimed ${Math.max(
          0,
          beforeMb - activeJvm.usedMb
        )} MB (${activeJvm.usedMb}/${activeJvm.allocatedMb} MB)`
      );
    } else {
      activeJvm.usedMb = Math.min(activeJvm.allocatedMb - 32, nextUsed);
      if (activeJvm.tickCount % 4 === 0) {
        pushJvmLog(
          'DEBUG',
          'Chunk Batcher',
          `1.8.9 heap sample: ${activeJvm.usedMb} MB used / ${activeJvm.allocatedMb} MB committed (-Xmx${activeJvm.xmxMb}M)`
        );
      }
    }
  }
  return buildJvmSnapshot();
}

function triggerJvmGc() {
  if (activeJvm.running) {
    const beforeMb = activeJvm.usedMb;
    activeJvm.usedMb = Math.max(
      Math.round(activeJvm.xmsMb * 0.4),
      Math.round(activeJvm.usedMb * 0.52)
    );
    activeJvm.gcCollections += 1;
    pushJvmLog(
      'INFO',
      'GC',
      `Manual System.gc() sweep reclaimed ${Math.max(
        0,
        beforeMb - activeJvm.usedMb
      )} MB -> ${activeJvm.usedMb} MB used`
    );
  }
  return buildJvmSnapshot();
}

function stopJvmSession() {
  if (activeJvm.running) {
    pushJvmLog('INFO', 'Client thread', 'Stopping Minecraft 1.8.9 client process.');
  }
  activeJvm.running = false;
  activeJvm.pid = null;
  activeJvm.allocatedMb = 0;
  activeJvm.usedMb = 0;
  return buildJvmSnapshot();
}

async function startServer() {
  ensureSampleEnvironment();

  const app = express();
  app.use(express.json({ limit: '30mb' }));

  // Mirror of get_system_info
  app.get('/api/system-info', (_req, res) => {
    res.json({ total_ram_mb: getSystemTotalRamMb() });
  });

  // Mirror of load_settings
  app.get('/api/settings', (_req, res) => {
    const settings = readSavedSettings();
    res.json({
      settings,
      defaults: getDefaultSettings(),
      configPath: CONFIG_FILE,
    });
  });

  // Mirror of save_settings
  app.post('/api/settings', (req, res) => {
    const incoming = normalizeSettingsTo189(req.body as LauncherSettings);
    const totalRam = getSystemTotalRamMb();
    const validation = validateLauncherSettings(incoming, totalRam);
    if (!validation.valid) {
      const firstError = Object.values(validation.errors)[0] ?? 'Invalid launcher settings.';
      return res.status(400).json({ error: firstError, errors: validation.errors });
    }
    writeSavedSettings(incoming);
    return res.json({ ok: true, settings: incoming });
  });

  // Mirror of pick_folder
  app.get('/api/fs/list', (req, res) => {
    const requested = typeof req.query.path === 'string' && req.query.path.trim()
      ? path.resolve(req.query.path.trim())
      : DATA_DIR;

    const presets = [
      {
        label: 'Minecraft Home (Managed)',
        path: SAMPLE_MC_DIR,
        description: 'Pre-configured .minecraft directory with 1.8.9 + Ornithe 0.20.1',
      },
      {
        label: 'Eclipse Temurin JDK 25',
        path: SAMPLE_JAVA_DIR,
        description: 'Java 25 LTS runtime required by Argentum 1.0.2 & ForgeCompat',
      },
      {
        label: 'Eclipse Temurin JDK 17',
        path: SAMPLE_JAVA17_DIR,
        description: 'Legacy JRE 17 runtime',
      },
      {
        label: 'Eclipse Temurin JDK 8',
        path: SAMPLE_JAVA8_DIR,
        description: 'Classic Java 8 LTS runtime for Vanilla 1.8.9',
      },
    ];

    try {
      if (!fs.existsSync(requested) || !fs.statSync(requested).isDirectory()) {
        return res.status(404).json({ error: `Directory not found: ${requested}` });
      }

      const dirents = fs.readdirSync(requested, { withFileTypes: true });
      const entries = dirents
        .filter((d) => !d.name.startsWith('.'))
        .sort((a, b) => {
          if (a.isDirectory() !== b.isDirectory()) return a.isDirectory() ? -1 : 1;
          return a.name.localeCompare(b.name);
        })
        .slice(0, 60)
        .map((d) => {
          const full = path.join(requested, d.name);
          let hint: string | undefined;
          if (d.isDirectory() && fs.existsSync(path.join(full, 'bin', 'java'))) {
            hint = 'Java Runtime';
          } else if (d.isDirectory() && fs.existsSync(path.join(full, 'versions'))) {
            hint = 'Minecraft Directory';
          }
          return {
            name: d.name,
            path: full,
            isDirectory: d.isDirectory(),
            hint,
          };
        });

      const parent = path.dirname(requested);
      res.json({
        currentPath: requested,
        parentPath: parent !== requested ? parent : null,
        entries,
        presets,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to read directory';
      res.status(500).json({ error: msg });
    }
  });

  // Mirror of launch_minecraft
  app.post('/api/launch', (req, res) => {
    const launchStartedAt = Date.now();
    const body = req.body as LauncherSettings & {
      serverAddress?: string;
      ornithe?: OrnitheConfig;
      enabledMods?: string[];
    };
    const settings = normalizeSettingsTo189(body);
    const ornithe = body.ornithe ?? readExtras().ornithe;
    const totalRam = getSystemTotalRamMb();
    const validation = validateLauncherSettings(settings, totalRam);
    if (!validation.valid) {
      const firstError = Object.values(validation.errors)[0] ?? 'Invalid launcher settings.';
      return res.status(400).json({ error: firstError });
    }

    // Save latest settings only when changed to avoid redundant disk sync on launch
    const existingSaved = readSavedSettings();
    if (!existingSaved || JSON.stringify(existingSaved) !== JSON.stringify(settings)) {
      writeSavedSettings(settings);
    }

    if (Array.isArray(body.enabledMods)) {
      const cfgDir = joinPlatformPath(settings.mc_path, 'config');
      fs.mkdirSync(cfgDir, { recursive: true });
      fs.writeFileSync(
        joinPlatformPath(cfgDir, 'agretium-modules.json'),
        JSON.stringify(body.enabledMods, null, 2),
        'utf-8'
      );
    }

    const spec = buildJvmArguments(settings, ornithe, body.serverAddress);

    // Verify Java binary exists
    if (!fs.existsSync(spec.javaBin)) {
      const msg = `Java executable not found at: ${spec.javaBin}`;
      appendLaunchHistory({
        id: `${Date.now()}`,
        timestamp: new Date().toISOString(),
        version: settings.version,
        account: settings.account,
        ram_mb: settings.ram_mb,
        optifine: settings.optifine,
        resolution: settings.resolution,
        command: spec.commandLine,
        status: 'failed',
        message: msg,
      });
      return res.status(400).json({ error: msg });
    }

    // Verify client jar and Ornithe loader jars exist
    if (!fs.existsSync(spec.clientJar)) {
      const msg = `Minecraft 1.8.9 jar not found at: ${spec.clientJar}. Run version download first.`;
      appendLaunchHistory({
        id: `${Date.now()}`,
        timestamp: new Date().toISOString(),
        version: settings.version,
        account: settings.account,
        ram_mb: settings.ram_mb,
        optifine: settings.optifine,
        resolution: settings.resolution,
        command: spec.commandLine,
        status: 'failed',
        message: msg,
      });
      return res.status(400).json({ error: msg });
    }

    if (
      ornithe.enabled &&
      (!fs.existsSync(spec.ornitheLoaderJar) ||
        !fs.existsSync(spec.calamusJar) ||
        !fs.existsSync(spec.ornitheProfileJson))
    ) {
      const msg = `Ornithe 1.8.9 loader libraries missing in ${settings.mc_path}. Click PLAY to download Ornithe 1.8.9.`;
      return res.status(400).json({ error: msg });
    }

    const activeModJars = scanModJars(settings.mc_path).filter((m) => m.enabled);
    const loaderTag = ornithe.enabled ? 'Ornithe 1.8.9' : 'Minecraft 1.8.9';
    const launchDurationMs = Math.max(1, Date.now() - launchStartedAt);
    const successMessage = body.serverAddress
      ? `Launched ${loaderTag} -> ${body.serverAddress} (${settings.ram_mb} MB RAM · ${activeModJars.length} mod JARs)`
      : `Launched ${loaderTag} (${settings.ram_mb} MB RAM · ${activeModJars.length} mod JARs)`;
    const historyEntry: LaunchHistoryEntry = {
      id: `${Date.now()}`,
      timestamp: new Date().toISOString(),
      version: ornithe.enabled ? `${settings.version}-ornithe` : settings.version,
      account: settings.account,
      ram_mb: settings.ram_mb,
      optifine: settings.optifine,
      resolution: settings.resolution,
      command: spec.commandLine,
      status: 'launched',
      message: successMessage,
      serverAddress: body.serverAddress,
      launchDurationMs,
    };
    appendLaunchHistory(historyEntry);
    startJvmSession(settings, ornithe, body.serverAddress);

    return res.json({
      ok: true,
      message: successMessage,
      command: spec.commandLine,
      args: spec.args,
      javaBin: spec.javaBin,
      clientJar: spec.clientJar,
      minimized: settings.minimize_on_launch,
      launchDurationMs,
      historyEntry,
    });
  });

  app.get('/api/extras', (_req, res) => {
    res.json(readExtras());
  });

  app.post('/api/extras', (req, res) => {
    const saved = writeExtras(req.body as LauncherExtras);
    res.json({ ok: true, extras: saved });
  });

  app.get('/api/preflight', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const extras = readExtras();
    const mcPath =
      typeof req.query.mc_path === 'string' && req.query.mc_path.trim()
        ? req.query.mc_path.trim()
        : current.mc_path;
    const javaPath =
      typeof req.query.java_path === 'string' && req.query.java_path.trim()
        ? req.query.java_path.trim()
        : current.java_path;
    const ornitheEnabled =
      typeof req.query.ornithe_enabled === 'string'
        ? req.query.ornithe_enabled !== 'false'
        : extras.ornithe.enabled;
    const includeArgentum =
      typeof req.query.agretium_enabled === 'string'
        ? req.query.agretium_enabled !== 'false'
        : current.optifine;

    res.json(
      computePreflight(
        mcPath,
        javaPath,
        {
          ...extras.ornithe,
          enabled: ornitheEnabled,
        },
        includeArgentum
      )
    );
  });

  app.post('/api/version/download', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const extras = readExtras();
    const body = (req.body ?? {}) as {
      mc_path?: string;
      ornithe?: OrnitheConfig;
      includeArgentum?: boolean;
    };
    const mcPath = body.mc_path?.trim() || current.mc_path;
    const ornithe = body.ornithe ?? extras.ornithe;
    const includeArgentum = body.includeArgentum ?? current.optifine;
    const status = startVersionDownloadJob(mcPath, ornithe, includeArgentum);
    res.json(status);
  });

  app.get('/api/version/download-status', (_req, res) => {
    res.json(activeDownload);
  });

  app.post('/api/version/reset', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const extras = readExtras();
    const body = (req.body ?? {}) as { mc_path?: string };
    const mcPath = body.mc_path?.trim() || current.mc_path;

    const removeTargets = [
      joinPlatformPath(mcPath, 'versions', LOCKED_VERSION_ID),
      joinPlatformPath(mcPath, 'versions', `${LOCKED_VERSION_ID}-ornithe`),
      joinPlatformPath(mcPath, 'libraries'),
      joinPlatformPath(mcPath, 'assets'),
      ...ARGENTUM_MOD_JARS.map((jar) => joinPlatformPath(mcPath, 'mods', jar.fileName)),
    ];
    for (const target of removeTargets) {
      if (fs.existsSync(target)) {
        fs.rmSync(target, { recursive: true, force: true });
      }
    }
    activeDownload = {
      state: 'idle',
      percent: 0,
      currentArtifact: null,
      completedCount: 0,
      totalCount: 0,
      artifacts: [],
    };
    res.json({
      ok: true,
      preflight: computePreflight(mcPath, current.java_path, extras.ornithe, current.optifine),
    });
  });

  app.get('/api/launch/history', (_req, res) => {
    res.json({ history: readLaunchHistory() });
  });

  app.get('/api/jvm-status', (_req, res) => {
    res.json(sampleJvmStatus());
  });

  app.post('/api/jvm-status/gc', (_req, res) => {
    res.json(triggerJvmGc());
  });

  app.post('/api/jvm-status/stop', (_req, res) => {
    res.json(stopJvmSession());
  });

  // Custom & Core .jar Mods folder management
  app.get('/api/mods/files', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const mcPath =
      typeof req.query.mc_path === 'string' && req.query.mc_path.trim()
        ? req.query.mc_path.trim()
        : current.mc_path;
    const modsDir = joinPlatformPath(mcPath, 'mods');
    res.json({
      modsDir,
      mods: scanModJars(mcPath),
    });
  });

  app.post('/api/mods/upload', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const body = (req.body ?? {}) as {
      mc_path?: string;
      files?: Array<{ fileName: string; base64Data: string }>;
    };
    const mcPath = body.mc_path?.trim() || current.mc_path;
    const files = Array.isArray(body.files) ? body.files : [];
    if (files.length === 0) {
      return res.status(400).json({ error: 'Select one or more .jar mod files to add.' });
    }

    const modsDir = joinPlatformPath(mcPath, 'mods');
    fs.mkdirSync(modsDir, { recursive: true });

    for (const file of files) {
      const check = validateModJarFileName(file.fileName ?? '');
      if (!check.valid || !check.sanitized) {
        return res.status(400).json({ error: check.error || 'Invalid mod filename.' });
      }
      const cleanBase64 = (file.base64Data ?? '').replace(/^data:[^;]+;base64,/, '');
      const buffer = Buffer.from(cleanBase64, 'base64');
      if (buffer.length === 0) {
        return res.status(400).json({ error: `Mod file ${check.sanitized} is empty.` });
      }
      fs.writeFileSync(path.join(modsDir, check.sanitized), buffer);
    }

    return res.json({
      modsDir,
      mods: scanModJars(mcPath),
    });
  });

  app.post('/api/mods/toggle', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const body = (req.body ?? {}) as {
      mc_path?: string;
      fileName?: string;
      enabled?: boolean;
    };
    const mcPath = body.mc_path?.trim() || current.mc_path;
    const modsDir = joinPlatformPath(mcPath, 'mods');
    const cleanName = path.basename(body.fileName?.trim() || '');
    if (!cleanName) {
      return res.status(400).json({ error: 'Invalid mod filename.' });
    }
    const src = path.join(modsDir, cleanName);
    if (!fs.existsSync(src)) {
      return res.status(404).json({ error: `Mod file not found: ${cleanName}` });
    }
    const nextName = toggleModJarFileName(cleanName, Boolean(body.enabled));
    const dest = path.join(modsDir, nextName);
    if (src !== dest) {
      fs.renameSync(src, dest);
    }
    return res.json({
      modsDir,
      mods: scanModJars(mcPath),
    });
  });

  app.delete('/api/mods/file', (req, res) => {
    const current = readSavedSettings() ?? getDefaultSettings();
    const body = (req.body ?? {}) as { mc_path?: string; fileName?: string };
    const mcPath = body.mc_path?.trim() || current.mc_path;
    const modsDir = joinPlatformPath(mcPath, 'mods');
    const cleanName = path.basename(body.fileName?.trim() || '');
    if (!cleanName) {
      return res.status(400).json({ error: 'Invalid mod filename.' });
    }
    const target = path.join(modsDir, cleanName);
    if (fs.existsSync(target)) {
      fs.unlinkSync(target);
    }
    return res.json({
      modsDir,
      mods: scanModJars(mcPath),
    });
  });

  const findWindowsArtifacts = () => {
    const releaseDir = path.resolve(process.cwd(), 'release');
    let installerPath: string | null = null;
    let portablePath: string | null = null;

    if (fs.existsSync(releaseDir)) {
      const exes = fs
        .readdirSync(releaseDir)
        .filter((f) => f.toLowerCase().endsWith('.exe'))
        .map((f) => path.join(releaseDir, f));
      installerPath = exes.find((p) => /setup/i.test(path.basename(p))) ?? null;
      portablePath =
        exes.find((p) => !/setup/i.test(path.basename(p))) ?? null;

      if (!installerPath) {
        const zipPath = path.join(releaseDir, 'Agretium-1.8.9-Launcher-Windows-x64.zip');
        if (fs.existsSync(zipPath)) {
          installerPath = zipPath;
        }
      }
    }

    return {
      installerPath,
      installerName: installerPath ? path.basename(installerPath) : null,
      installerSizeBytes: installerPath ? fs.statSync(installerPath).size : 0,
      portablePath,
      portableName: portablePath ? path.basename(portablePath) : null,
      portableSizeBytes: portablePath ? fs.statSync(portablePath).size : 0,
    };
  };

  app.get('/api/windows-build', (_req, res) => {
    const info = findWindowsArtifacts();
    res.json({
      available: Boolean(info.installerPath || info.portablePath),
      installerName: info.installerName,
      installerSizeBytes: info.installerSizeBytes,
      portableName: info.portableName,
      portableSizeBytes: info.portableSizeBytes,
    });
  });

  app.get('/api/windows-build/chunk', (req, res) => {
    const kind = req.query.kind === 'portable' ? 'portable' : 'installer';
    const info = findWindowsArtifacts();
    const targetPath =
      kind === 'portable'
        ? info.portablePath ?? info.installerPath
        : info.installerPath ?? info.portablePath;

    if (!targetPath || !fs.existsSync(targetPath)) {
      return res.status(404).json({ error: 'Windows artifact not found.' });
    }

    const totalSize = fs.statSync(targetPath).size;
    const rawOffset = Number(req.query.offset ?? 0);
    const rawLength = Number(req.query.length ?? 6 * 1024 * 1024);
    const offset = Number.isFinite(rawOffset) && rawOffset >= 0 ? Math.floor(rawOffset) : 0;
    const maxChunk = 12 * 1024 * 1024;
    const requestedLen =
      Number.isFinite(rawLength) && rawLength > 0 ? Math.min(maxChunk, Math.floor(rawLength)) : 6 * 1024 * 1024;

    if (offset >= totalSize) {
      return res.status(416).json({ error: 'Offset beyond file size', totalSize });
    }

    const bytesToRead = Math.min(requestedLen, totalSize - offset);
    const buf = Buffer.allocUnsafe(bytesToRead);
    const fd = fs.openSync(targetPath, 'r');
    try {
      fs.readSync(fd, buf, 0, bytesToRead, offset);
    } finally {
      fs.closeSync(fd);
    }

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Total-Bytes', String(totalSize));
    res.setHeader('X-Chunk-Offset', String(offset));
    return res.status(200).send(buf);
  });

  app.get('/api/windows-build/download', (req, res) => {
    const kind = req.query.kind === 'portable' ? 'portable' : 'installer';
    const info = findWindowsArtifacts();
    const targetPath =
      kind === 'portable'
        ? info.portablePath ?? info.installerPath
        : info.installerPath ?? info.portablePath;
    const targetName =
      kind === 'portable'
        ? info.portableName ?? info.installerName ?? 'Agretium-1.8.9-Launcher.exe'
        : info.installerName ?? info.portableName ?? 'Agretium-1.8.9-Launcher.exe';

    if (!targetPath || !fs.existsSync(targetPath)) {
      return res.status(404).json({ error: 'Windows .exe artifact has not been built yet.' });
    }

    const totalSize = fs.statSync(targetPath).size;
    const acceptsHtml = String(req.headers.accept ?? '').includes('text/html');
    // Cloud Run caps single HTTP responses at 32 MiB; serve a chunked browser downloader for direct URL visits
    if (totalSize > 28 * 1024 * 1024 && acceptsHtml && req.query.raw !== '1') {
      const safeName = targetName.replace(/[<>&"']/g, '');
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'no-store');
      return res.status(200).send(`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Downloading ${safeName}</title>
<style>
  body { margin:0; font-family:Inter,system-ui,sans-serif; background:#121316; color:#f4f4f5; display:flex; align-items:center; justify-content:center; min-height:100vh; }
  .card { width:min(460px,90vw); background:#181a1f; border:1px solid #26282e; border-radius:12px; padding:24px; }
  h1 { margin:0 0 8px; font-size:16px; }
  p { margin:0 0 16px; font-size:13px; color:#a1a1aa; line-height:1.5; }
  .bar { height:10px; background:#121316; border:1px solid #26282e; border-radius:999px; overflow:hidden; }
  .fill { height:100%; width:0%; background:#1cb5f6; transition:width 150ms ease; }
  .meta { margin-top:10px; font-size:12px; color:#7dd9fc; font-variant-numeric:tabular-nums; }
  .btn { margin-top:16px; display:none; background:#1cb5f6; color:#fff; border:none; border-radius:6px; padding:10px 14px; font-size:13px; font-weight:700; cursor:pointer; }
</style>
</head>
<body>
  <div class="card">
    <h1>Downloading ${safeName}</h1>
    <p>Fetching the compiled Windows Electron launcher in 6 MB chunks so large downloads succeed reliably.</p>
    <div class="bar"><div class="fill" id="fill"></div></div>
    <div class="meta" id="meta">Starting download...</div>
    <button class="btn" id="saveBtn" type="button">Save ${safeName}</button>
  </div>
  <script>
    (async () => {
      const total = ${totalSize};
      const kind = ${JSON.stringify(kind)};
      const fileName = ${JSON.stringify(targetName)};
      const chunkSize = 6 * 1024 * 1024;
      const fill = document.getElementById('fill');
      const meta = document.getElementById('meta');
      const saveBtn = document.getElementById('saveBtn');
      const parts = [];
      let loaded = 0;
      try {
        while (loaded < total) {
          const len = Math.min(chunkSize, total - loaded);
          const resp = await fetch('/api/windows-build/chunk?kind=' + encodeURIComponent(kind) + '&offset=' + loaded + '&length=' + len, { cache: 'no-store' });
          if (!resp.ok) throw new Error('Chunk failed (HTTP ' + resp.status + ')');
          const buf = await resp.arrayBuffer();
          parts.push(buf);
          loaded += buf.byteLength;
          const pct = Math.min(100, Math.round((loaded * 100) / total));
          fill.style.width = pct + '%';
          meta.textContent = pct + '% · ' + (loaded / (1024 * 1024)).toFixed(1) + ' / ' + (total / (1024 * 1024)).toFixed(1) + ' MB';
        }
        const blob = new Blob(parts, { type: 'application/zip' });
        const url = URL.createObjectURL(blob);
        const trigger = () => {
          const a = document.createElement('a');
          a.href = url;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          a.remove();
        };
        trigger();
        meta.textContent = 'Download complete! Extract the .zip and run Agretium 1.8.9 Launcher.exe.';
        saveBtn.style.display = 'inline-block';
        saveBtn.onclick = trigger;
      } catch (err) {
        meta.style.color = '#fca5a5';
        meta.textContent = 'Download failed: ' + (err && err.message ? err.message : String(err));
      }
    })();
  </script>
</body>
</html>`);
    }

    return res.download(targetPath, targetName);
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PrismCraft Launcher server listening on http://localhost:${PORT}`);
  });
}

startServer();
